// Real-asset loader: photo textures, ez-tree trees, scanned rocks, HDRI skies (all CC0 / MIT / CC BY; credits in the Field kit)
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';

const TEX = {
  grass: 't_grass.jpg', dirt: 't_dirt.jpg', dirtN: 't_dirt_n.jpg', rock: 't_rock.jpg', rockN: 't_rock_n.jpg', trail: 't_trail.jpg',
  clump: 'g_clump.webp',
  l_oak: 'l_oak.webp', l_pine: 'l_pine.webp', l_ash: 'l_ash.webp', l_aspen: 'l_aspen.webp',
};
for (const b of ['oak', 'pine', 'birch', 'willow']) for (const m of ['color', 'normal', 'roughness']) TEX[`b_${b}_${m}`] = `b_${b}_${m}.jpg`;
const LINEAR = /(_n|normal|roughness)\b|_n\.|normal\.|roughness\./;

export async function loadAssets(renderer, onProgress = () => {}, { skies = true, aniso = 8 } = {}) {
  const base = 'assets/';
  const jobs = [];
  const out = { tex: {}, trees: null, rocks: [], sky: {}, ok: true };
  let done = 0; const total = Object.keys(TEX).length + 2 + 3 + (skies ? 4 : 0);
  const tick = () => onProgress(++done / total);
  const maxAniso = renderer.capabilities.getMaxAnisotropy();
  const tl = new THREE.TextureLoader();
  for (const [k, f] of Object.entries(TEX)) jobs.push(tl.loadAsync(base + f).then(t => {
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = Math.min(aniso, maxAniso);
    t.colorSpace = LINEAR.test(f) ? THREE.NoColorSpace : THREE.SRGBColorSpace;
    out.tex[k] = t; tick();
  }));
  jobs.push((async () => {
    const [meta, buf] = await Promise.all([fetch(base + 'trees.json').then(r => r.json()), fetch(base + 'trees.wasm').then(r => r.arrayBuffer())]);
    out.trees = { meta, buf }; tick(); tick();
  })());
  const gl = new GLTFLoader();
  for (let i = 1; i <= 3; i++) jobs.push(fetch(base + `rock${i}.glb.wasm`).then(r => r.arrayBuffer()).then(b => gl.parseAsync(b, base)).then(g => { let mesh = null; g.scene.traverse(o => { if (o.isMesh && !mesh) mesh = o; }); out.rocks[i - 1] = mesh; tick(); }));
  if (skies) {
    const rl = new RGBELoader(); rl.setDataType(THREE.HalfFloatType);
    for (const k of ['day', 'gold', 'dawn', 'night']) jobs.push(fetch(base + `sky_${k}.wasm`).then(r => r.arrayBuffer()).then(b => {
      const d = rl.parse(b);
      const t = new THREE.DataTexture(d.data, d.width, d.height, THREE.RGBAFormat, d.type);
      t.colorSpace = THREE.LinearSRGBColorSpace; t.minFilter = THREE.LinearFilter; t.magFilter = THREE.LinearFilter; t.generateMipmaps = false;
      t.wrapS = THREE.RepeatWrapping; t.flipY = false; t.mapping = THREE.EquirectangularReflectionMapping; t.needsUpdate = true;
      out.sky[k] = t; tick();
    }));
  }
  await Promise.all(jobs);
  return out;
}

// sun position inside each photo sky (measured offline), its exposure trim, and which sun elevations it covers
export const SKY_META = {
  day: { sunU: 0.5996, exp: 1.0, env: 0.9, hor: [0.322, 0.327, 0.36] },
  gold: { sunU: 0.5996, exp: 1.15, env: 1.2, hor: [0.753, 0.836, 0.858] },
  dawn: { sunU: 0.626, exp: 0.42, env: 0.45, hor: [3.738, 2.88, 2.394] },
  night: { sunU: 0.3408, exp: 1.6, env: 2.2, hor: [0.44, 0.327, 0.203] },
};
