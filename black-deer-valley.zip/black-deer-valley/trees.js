// Forest: ez-tree trees (MIT, Daniel Greenheck) at three detail levels + baked billboard impostors far away.
// Every tree is a world "prop" (chop / collide); this module only decides how each one is drawn.
import * as THREE from 'three';

export function createForest(scene, renderer, A, U, { LITE, QUALITY }) {
  const meta = A.trees.meta, buf = A.trees.buf, T = A.tex;
  const geo = (m) => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(buf, m.pos, m.n * 3), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(new Int8Array(buf, m.nrm, m.n * 4), 4, true));
    g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(buf, m.uv, m.n * 2), 2));
    g.setIndex(new THREE.BufferAttribute(m.idx32 ? new Uint32Array(buf, m.idx, m.tris * 3) : new Uint16Array(buf, m.idx, m.tris * 3), 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    return g;
  };

  const barkMats = {}, leafMats = {}, depthMats = {};
  function barkMat(type, scale) {
    const k = type + scale.y; if (barkMats[k]) return barkMats[k];
    const m = new THREE.MeshStandardMaterial({ map: T[`b_${type}_color`], normalMap: T[`b_${type}_normal`], roughnessMap: T[`b_${type}_roughness`], roughness: 1, metalness: 0 });
    m.normalScale.set(1.2, 1.2);
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { uTime: U.time, uWind: U.wind, uWet: U.wet, uSnow: U.snow, uRep: { value: new THREE.Vector2(scale.x, 1 / scale.y) } });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime, uWind; uniform vec2 uRep;')
        .replace('#include <uv_vertex>', '#include <uv_vertex>\n#ifdef USE_MAP\n vMapUv = uv * uRep;\n#endif\n#ifdef USE_NORMALMAP\n vNormalMapUv = uv * uRep;\n#endif\n#ifdef USE_ROUGHNESSMAP\n vRoughnessMapUv = uv * uRep;\n#endif')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          { float ph = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.21; float sw = max(position.y - 2.0, 0.0);
            transformed.x += sw * sw * 0.0022 * uWind * sin(uTime * 1.1 + ph); transformed.z += sw * sw * 0.0016 * uWind * sin(uTime * 1.4 + ph * 1.3); }`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float uWet, uSnow;')
        .replace('#include <map_fragment>', '#include <map_fragment>\n diffuseColor.rgb *= 1.0 - 0.3 * uWet;')
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(roughnessFactor, 0.4, uWet * 0.7);');
    };
    m.userData.env = 0.5;
    return barkMats[k] = m;
  }
  function leafMat(type, cy, deciduous) {
    const k = type + cy.toFixed(1); if (leafMats[k]) return leafMats[k];
    const m = new THREE.MeshStandardMaterial({ map: T[`l_${type}`], alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.75, metalness: 0, alphaToCoverage: !!QUALITY.a2c });
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { uTime: U.time, uWind: U.wind, uSunV: U.sunV, uSunCol: U.sunCol, uDay: U.day, uSnow: U.snow, uAutumn: U.autumn, uWet: U.wet, uCy: { value: cy }, uDec: { value: deciduous ? 1 : 0 } });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime, uWind, uCy; varying float vUp;')
        .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\n objectNormal = normalize(mix(objectNormal, normalize(position - vec3(0.0, uCy, 0.0)), 0.65));')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          { float ph = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.21; float sw = max(position.y - 2.0, 0.0);
            transformed.x += sw * sw * 0.0022 * uWind * sin(uTime * 1.1 + ph); transformed.z += sw * sw * 0.0016 * uWind * sin(uTime * 1.4 + ph * 1.3);
            transformed += normal.xyz * 0.05 * uWind * sin(uTime * 4.2 + position.x * 2.0 + position.y * 1.7 + ph); }
          vUp = objectNormal.y;`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 uSunV, uSunCol; uniform float uDay, uSnow, uAutumn, uWet, uDec; varying float vUp;')
        .replace('#include <map_fragment>', `#include <map_fragment>
          { float lum = dot(diffuseColor.rgb, vec3(0.3, 0.59, 0.11));
            vec3 aut = mix(vec3(0.85, 0.32, 0.06), vec3(0.92, 0.66, 0.12), fract(vMapUv.x * 3.7 + vMapUv.y * 2.3)) * lum * 2.2;
            diffuseColor.rgb = mix(diffuseColor.rgb, aut, uAutumn * uDec * 0.9);
            diffuseColor.rgb *= 0.98;
            ${QUALITY.painted ? 'diffuseColor.rgb = mix(vec3(0.17, 0.33, 0.12), vec3(0.5, 0.68, 0.23), smoothstep(0.05, 0.55, dot(texture2D(map, vMapUv, 2.0).rgb, vec3(0.33)) * 1.6 + vUp * 0.25));' : ''}
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.7, 0.73, 0.78), uSnow * 0.6 * smoothstep(0.0, 0.7, vUp)); }`)
        .replace('#include <normal_fragment_begin>', 'float faceDirection = 1.0; vec3 normal = normalize(vNormal); vec3 nonPerturbedNormal = normal;')
        .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
          { float back = pow(max(dot(normalize(-vViewPosition), uSunV), 0.0), 4.0);
            totalEmissiveRadiance += uSunCol * back * 0.55 * diffuseColor.rgb * uDay + diffuseColor.rgb * (0.025 + 0.11 * uDay)
              + diffuseColor.rgb * vec3(0.55, 0.7, 0.45) * 0.16 * uDay * (1.0 - smoothstep(-0.7, 0.25, vUp)); } // skylight through the canopy from below`);
    };
    m.userData.env = 0.35;
    const d = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: T[`l_${type}`], alphaTest: 0.5 });
    depthMats[k] = d;
    return leafMats[k] = m;
  }

  // ---- variants ----
  const V = meta.variants.map(v => {
    const lods = v.lods.map(L => ({ b: geo(L.b), l: geo(L.l) }));
    return { ...v, lods, items: [], meshes: [] };
  });
  const byKind = { pine: [], hard: [], shrub: [] };
  V.forEach((v, i) => byKind[v.kind].push(i));

  function add(item) {
    const list = byKind[item.kind === 'berry' ? 'shrub' : item.kind] || byKind.hard;
    const vi = list[(item.vi ?? 0) % list.length];
    item.tv = vi; V[vi].items.push(item);
  }

  // ---- build instanced meshes (one per variant x lod x part) ----
  function build() {
    for (const v of V) {
      const n = Math.max(1, v.items.length);
      const deciduous = v.kind !== 'pine';
      v.meshes = v.lods.slice(1, 3).map((L, li) => { // near: mid-detail tree, farther: low-detail tree, beyond: baked card
        const bm = new THREE.InstancedMesh(L.b, barkMat(v.bark, v.barkScale), n);
        const lm = new THREE.InstancedMesh(L.l, leafMat(v.leaf, v.h * 0.62, deciduous), n);
        lm.customDepthMaterial = depthMats[v.leaf + (v.h * 0.62).toFixed(1)];
        for (const m of [bm, lm]) { m.count = 0; m.frustumCulled = false; m.castShadow = li === 0; m.receiveShadow = true; scene.add(m); }
        return { bm, lm };
      });
    }
    bakeImpostors();
  }

  // ---- impostors: each variant's mid tree rendered once into an atlas, drawn as camera-facing cards ----
  const CELL_W = 256, CELL_H = 512, NV = V.length;
  let atlas = null, imp = null;
  function bakeImpostors() {
    atlas = new THREE.WebGLRenderTarget(CELL_W * NV, CELL_H, { generateMipmaps: true, minFilter: THREE.LinearMipmapLinearFilter, magFilter: THREE.LinearFilter });
    const sc = new THREE.Scene(); sc.add(new THREE.AmbientLight(0xffffff, 0.75)); const dl = new THREE.DirectionalLight(0xffffff, 1.6); dl.position.set(0.3, 1, 1); sc.add(dl);
    const cam = new THREE.OrthographicCamera(-1, 1, 1, -1, -100, 100);
    const prevT = renderer.getRenderTarget(), prevClear = renderer.getClearColor(new THREE.Color()), prevA = renderer.getClearAlpha(), prevAuto = renderer.autoClear, prevTM = renderer.toneMapping;
    renderer.setRenderTarget(atlas); renderer.setClearColor(0x000000, 0); renderer.clear(); renderer.autoClear = false; renderer.toneMapping = THREE.NoToneMapping;
    V.forEach((v, i) => {
      const L = v.lods[1];
      const bm = new THREE.Mesh(L.b, new THREE.MeshLambertMaterial({ map: T[`b_${v.bark}_color`] }));
      const lm = new THREE.Mesh(L.l, new THREE.MeshLambertMaterial({ map: T[`l_${v.leaf}`], alphaTest: 0.5, side: THREE.DoubleSide }));
      const g = new THREE.Group(); g.add(bm, lm); sc.add(g);
      const half = Math.max(v.w * 0.55, v.h * 0.26);
      v.impW = half * 2; v.impH = half * 4; // cell is 1:2
      cam.left = -half; cam.right = half; cam.bottom = 0; cam.top = half * 4; cam.position.set(0, 0, 50); cam.lookAt(0, 0, 0); cam.updateProjectionMatrix();
      atlas.viewport.set(i * CELL_W, 0, CELL_W, CELL_H); atlas.scissor.set(i * CELL_W, 0, CELL_W, CELL_H); atlas.scissorTest = true;
      renderer.setRenderTarget(atlas); renderer.render(sc, cam);
      sc.remove(g); bm.material.dispose(); lm.material.dispose();
    });
    atlas.scissorTest = false; atlas.viewport.set(0, 0, CELL_W * NV, CELL_H);
    renderer.setRenderTarget(prevT); renderer.setClearColor(prevClear, prevA); renderer.autoClear = prevAuto; renderer.toneMapping = prevTM;
    // card geometry
    const total = V.reduce((t, v) => t + v.items.length, 0);
    const g = new THREE.InstancedBufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute([-0.5, 0, 0, 0.5, 0, 0, 0.5, 1, 0, -0.5, 1, 0], 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 1], 2)); g.setIndex([0, 1, 2, 0, 2, 3]);
    const aP = new THREE.InstancedBufferAttribute(new Float32Array(total * 4), 4); aP.setUsage(THREE.DynamicDrawUsage);
    const aV = new THREE.InstancedBufferAttribute(new Float32Array(total * 4), 4); aV.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('aP', aP); g.setAttribute('aV', aV); g.instanceCount = 0; g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    const mat = new THREE.ShaderMaterial({ fog: true, transparent: false, side: THREE.DoubleSide, alphaToCoverage: !!QUALITY.a2c,
      uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { tAtlas: { value: atlas.texture }, uNV: { value: NV } }]),
      vertexShader: `#include <fog_pars_vertex>
        attribute vec4 aP; attribute vec4 aV; uniform float uNV; varying vec2 vUv; varying float vH;
        void main(){ vec3 to = cameraPosition - aP.xyz; vec2 f = normalize(to.xz + 1e-4); vec3 right = vec3(-f.y, 0.0, f.x);
          vec3 wp = aP.xyz + right * position.x * aV.y * aP.w + vec3(0.0, position.y * aV.z * aP.w, 0.0);
          vUv = vec2((aV.x + uv.x) / uNV, uv.y); vH = position.y;
          vec4 mvPosition = viewMatrix * vec4(wp, 1.0); gl_Position = projectionMatrix * mvPosition;
          #include <fog_vertex>
        }`,
      fragmentShader: `#include <fog_pars_fragment>
        uniform sampler2D tAtlas; varying vec2 vUv; varying float vH;
        uniform vec3 uSunCol, uHor, uZen; uniform float uDay, uAutumn, uSnow;
        void main(){ vec4 t = texture2D(tAtlas, vUv); if (t.a < 0.5) discard;
          vec3 c = t.rgb / max(t.a, 0.001);
          float lum = dot(c, vec3(0.3, 0.59, 0.11)); vec3 aut = mix(vec3(0.85, 0.32, 0.06), vec3(0.92, 0.66, 0.12), fract(vUv.x * 9.0)) * lum * 2.0;
          float green = smoothstep(0.0, 0.05, c.g - c.r); c = mix(c, aut, uAutumn * green * 0.85);
          c = mix(c, vec3(0.7, 0.73, 0.78) * lum * 1.6, uSnow * 0.45 * vH);
          vec3 light = mix(uHor, uZen, 0.4) * 0.55 + uSunCol * 0.55 * uDay;
          gl_FragColor = vec4(c * light * (0.75 + 0.25 * vH), 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
          #include <fog_fragment>
        }` });
    mat.uniforms.tAtlas.value = atlas.texture; // merge() clones textures
    Object.assign(mat.uniforms, { uSunCol: U.sunCol, uHor: U.hor, uZen: U.zen, uDay: U.day, uAutumn: U.autumn, uSnow: U.snow });
    imp = new THREE.Mesh(g, mat); imp.frustumCulled = false; scene.add(imp);
  }

  // ---- per-frame: decide each tree's tier (hi / mid / card) from distance ----
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), sv = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0), pv = new THREE.Vector3();
  let acc = 1, lodScale = 1;
  const D0 = QUALITY.treeHi || 26, D1 = QUALITY.treeMid || 70;
  let lastX = 1e9, lastZ = 1e9;
  function update(cam, dt) {
    acc += dt; if (acc < 0.2) return;
    // tiers only change when the camera has moved: skip the rebuild (and the buffer uploads) while standing still or turning
    if (acc < 2 && Math.hypot(cam.x - lastX, cam.z - lastZ) < 2.5) return;
    acc = 0; lastX = cam.x; lastZ = cam.z;
    const cx = cam.x, cz = cam.z, d0 = (D0 * lodScale) ** 2, d1 = (D1 * lodScale) ** 2;
    const aP = imp.geometry.attributes.aP, aV = imp.geometry.attributes.aV; let ni = 0;
    V.forEach((v, vi) => {
      const n = [0, 0];
      for (const it of v.items) {
        if (!it.alive) continue;
        const dx = it.x - cx, dz = it.z - cz, d2 = dx * dx + dz * dz, s = it.s * (v.kind === 'shrub' ? 1 : 0.82);
        if (d2 < d1) { const t = d2 < d0 ? 0 : 1; const M = v.meshes[t]; m4.compose(pv.set(it.x, it.y, it.z), q.setFromAxisAngle(up, it.r), sv.setScalar(s)); M.bm.setMatrixAt(n[t], m4); M.lm.setMatrixAt(n[t], m4); n[t]++; }
        else if (v.kind !== 'shrub') { aP.setXYZW(ni, it.x, it.y, it.z, s); aV.setXYZW(ni, vi, v.impW, v.impH, 0); ni++; }
      }
      v.meshes.forEach((M, t) => { M.bm.count = M.lm.count = n[t]; M.bm.instanceMatrix.needsUpdate = M.lm.instanceMatrix.needsUpdate = true; });
    });
    imp.geometry.instanceCount = ni; aP.needsUpdate = aV.needsUpdate = true;
  }
  function setLodScale(k) { lodScale = k; acc = 1; lastX = 1e9; }
  function refresh() { acc = 1; lastX = 1e9; }
  return { add, build, update, refresh, setLodScale, variants: V, get atlas() { return atlas; } };
}
