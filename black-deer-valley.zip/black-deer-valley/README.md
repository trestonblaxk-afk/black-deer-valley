# Black Deer Valley (v0.6.3)

3D wildlife survival browser game (Three.js r0.160) for iPhone touch and Windows PC. No build step.

## Run it
```
cd black-deer-valley
python -m http.server 8765
```
Open http://localhost:8765 (add `?as=athlete&all` to spawn as the hiker with horses).
Online features (co-op, shared builds, stats) switch off outside Claude and the game runs single-player.

## Layout
- `index.html`, `app.js` – game loop, HUD, post-processing
- `world.js`, `trees.js` – terrain, sky, grass, rocks, trees
- `creatures.js` – animals and the hiker: animation, riding, combat, gear
- `assets.js` – loads textures, rock GLBs, HDR skies
- `audio.js`, `music.js` – ambience and music (tracks plug into `CFG.music.tracks`)
- `config.js` – all tuning numbers
- `data/` – creature meshes (`*.wasm` are binary meshes, renamed so the host serves them; `*.json` are skeletons)
- `assets/` – photo textures, rocks, skies
- `tools/species.mjs` + `tools/pack.mjs` – the code-sculpted creature builder (the current blocky hiker)
- `docs/` – hiker character sheet and the four clean views

## Current job: replace the blocky hiker with a real 3D model
See `TEAM_BRIEF.md`.
