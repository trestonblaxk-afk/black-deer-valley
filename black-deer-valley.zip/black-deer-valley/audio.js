// Procedural sound: ambience beds + one-shot effects + adaptive music, all synthesized (no files)
import { createMusic } from './music.js';
import { CFG } from './config.js';
export function createAudio() {
  let ctx = null, master, amb = {}, on = true, started = false, music = null, musicOn = true, wantMood = 'menu';
  const rnd = Math.random;
  function noiseBuf(sec = 2) { const b = ctx.createBuffer(1, ctx.sampleRate * sec, ctx.sampleRate), d = b.getChannelData(0); let last = 0; for (let i = 0; i < d.length; i++) { const w = rnd() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5 * 0.6 + w * 0.4 * 0.15; } return b; }
  function loopNoise(filterType, freq, q) { const s = ctx.createBufferSource(); s.buffer = noiseBuf(3); s.loop = true; const f = ctx.createBiquadFilter(); f.type = filterType; f.frequency.value = freq; f.Q.value = q; const g = ctx.createGain(); g.gain.value = 0; s.connect(f).connect(g).connect(master); s.start(); return { s, f, g }; }
  function start() {
    if (started) return; started = true;
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
    master = ctx.createGain(); master.gain.value = on ? 0.8 : 0; master.connect(ctx.destination);
    try { music = createMusic(ctx, master); music.volume = musicOn ? 0.85 : 0; } catch (e) { music = null; }
    try { initTracks(); } catch (e) { tracks = null; }
    applyMood(wantMood);
    amb.wind = loopNoise('bandpass', 420, 0.6); amb.leaves = loopNoise('highpass', 3200, 0.4); amb.rain = loopNoise('highpass', 1500, 0.3); amb.water = loopNoise('bandpass', 900, 1.2);
  }
  const t = () => ctx.currentTime;
  // ---- recorded soundtrack: streamed <audio> through WebAudio (iOS needs the gain here), two players per track for seamless loops ----
  let tracks = null, fileBus = null, curTrack = null;
  const M = CFG.music;
  function initTracks() {
    if (!M.on) return; tracks = {}; fileBus = ctx.createGain(); fileBus.gain.value = musicOn ? 0.55 : 0; fileBus.connect(master);
    for (const [mood, file] of Object.entries(M.tracks)) {
      const T = { mood, ok: null, g: ctx.createGain(), els: [], cur: 0, target: 0, playing: false, stopAt: 0 }; T.g.gain.value = 0; T.g.connect(fileBus);
      for (let i = 0; i < 2; i++) { const el = new Audio(); el.preload = i ? 'none' : 'metadata'; el.src = M.dir + file; el.crossOrigin = 'anonymous'; el.setAttribute('playsinline', '');
        el.muted = true; el.play().then(() => { if (!(T.playing && T.cur === i)) { el.pause(); el.currentTime = 0; } el.muted = false; }).catch(() => { el.muted = false; }); // unlock inside the first tap (iOS); keep playing if the mood already wants it
        const eg = ctx.createGain(); eg.gain.value = i ? 0 : 1; try { ctx.createMediaElementSource(el).connect(eg).connect(T.g); } catch (e) { T.ok = false; }
        el.addEventListener('error', () => { T.ok = false; if (curTrack === T) applyMood(wantMood); }); if (!i) el.addEventListener('loadedmetadata', () => { if (T.ok !== false) { const was = T.ok; T.ok = true; if (!was) applyMood(wantMood); } }, { once: true });
        T.els.push({ el, eg }); }
      tracks[mood] = T; }
    setInterval(() => { try { tickTracks(); } catch (e) {} }, 100); // loop timing runs on its own clock, even when the game loop pauses
  }
  const trackFor = k => { if (!tracks) return null; const T = tracks[k] || tracks[M.useFor[k]]; return T && T.ok ? T : null; };
  function applyMood(k) {
    if (!ctx) return; const T = trackFor(k), now = t(), F = M.fade / 3;
    if (tracks) for (const X of Object.values(tracks)) { const on = X === T; X.target = on ? (M.gain[X.mood] ?? 1) : 0; X.g.gain.setTargetAtTime(X.target, now, F);
      if (on && !X.playing) { X.playing = true; const a = X.els[X.cur]; a.eg.gain.setValueAtTime(1, now); a.el.play().catch(() => {}); }
      if (!on && X.playing) X.stopAt = now + M.fade * 1.6; }
    curTrack = T;
    if (music) music.mood = T ? null : (k in M.synthFor ? M.synthFor[k] : k); // the synth score covers whatever has no recording
  }
  function tickTracks() {
    if (!tracks) return; const now = t();
    for (const X of Object.values(tracks)) {
      if (!X.playing) continue;
      if (X.target === 0 && X.stopAt && now > X.stopAt) { for (const p of X.els) p.el.pause(); X.playing = false; X.stopAt = 0; continue; }
      const a = X.els[X.cur], d = a.el.duration;
      if (d && isFinite(d) && a.el.currentTime > d - M.loopXf && !X.swap) { // loop: start the twin from the top and crossfade
        const b = X.els[1 - X.cur]; X.swap = true; b.el.currentTime = 0; b.eg.gain.setValueAtTime(0.0001, now); b.eg.gain.linearRampToValueAtTime(1, now + M.loopXf); a.eg.gain.setValueAtTime(1, now); a.eg.gain.linearRampToValueAtTime(0.0001, now + M.loopXf);
        b.el.play().catch(() => {}); setTimeout(() => { a.el.pause(); a.el.currentTime = 0; X.cur = 1 - X.cur; X.swap = false; }, M.loopXf * 1000 + 60); }
    }
  }
  function env(g, a, peak, d, at = t()) { g.gain.cancelScheduledValues(at); g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), at + a); g.gain.exponentialRampToValueAtTime(0.0001, at + a + d); }
  function osc(type, f0, f1, dur, vol, at = t()) { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(f0, at); o.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), at + dur); o.connect(g).connect(master); env(g, 0.01, vol, dur, at); o.start(at); o.stop(at + dur + 0.05); return o; }
  function burst(freq, q, dur, vol, type = 'bandpass', at = t()) { const s = ctx.createBufferSource(); s.buffer = noiseBuf(Math.max(0.2, dur + 0.1)); const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q; const g = ctx.createGain(); s.connect(f).connect(g).connect(master); env(g, 0.005, vol, dur, at); s.start(at); s.stop(at + dur + 0.1); }
  const FX = {
    hoof: v => { burst(180 + rnd() * 60, 1.2, 0.08, 0.25 * v, 'lowpass'); osc('sine', 120, 60, 0.07, 0.12 * v); },
    step: v => burst(900 + rnd() * 400, 0.8, 0.06, 0.12 * v),
    thunder: v => { const at = t(); burst(70, 0.6, 2.6, 0.9 * v, 'lowpass', at); burst(160, 0.5, 1.4, 0.5 * v, 'lowpass', at + 0.05); burst(900, 0.4, 0.25, 0.25 * v, 'bandpass', at); osc('sine', 55, 30, 2.2, 0.35 * v, at + 0.1); },
    hit: v => { osc('sine', 140, 45, 0.18, 0.5 * v); burst(600, 0.7, 0.12, 0.35 * v); },
    whoosh: v => burst(1400, 0.6, 0.18, 0.18 * v),
    snort: v => { burst(700, 1.5, 0.25, 0.4 * v); burst(300, 2, 0.15, 0.25 * v, 'bandpass', t() + 0.12); },
    bugle: v => { const o = osc('sawtooth', 380, 1400, 0.9, 0.16 * v); o.frequency.exponentialRampToValueAtTime(1900, t() + 0.7); osc('sine', 1700, 900, 1.2, 0.08 * v, t() + 0.4); },
    whinny: v => { for (let i = 0; i < 6; i++) osc('sawtooth', 900 - i * 60, 600 - i * 50, 0.12, 0.08 * v, t() + i * 0.09); },
    howl: v => { const o = ctx.createOscillator(), g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(420, t()); o.frequency.linearRampToValueAtTime(720, t() + 0.6); o.frequency.linearRampToValueAtTime(660, t() + 1.6); o.frequency.linearRampToValueAtTime(380, t() + 2.2); lfo.frequency.value = 5; lg.gain.value = 9; lfo.connect(lg).connect(o.frequency); o.connect(g).connect(master); g.gain.setValueAtTime(0.0001, t()); g.gain.exponentialRampToValueAtTime(0.22 * v, t() + 0.3); g.gain.setValueAtTime(0.22 * v, t() + 1.6); g.gain.exponentialRampToValueAtTime(0.0001, t() + 2.3); o.start(); lfo.start(); o.stop(t() + 2.4); lfo.stop(t() + 2.4); },
    bark: v => { osc('square', 520, 260, 0.08, 0.12 * v); burst(1200, 1, 0.06, 0.15 * v); },
    shutter: v => { burst(4000, 1, 0.03, 0.4 * v, 'highpass'); burst(2500, 1, 0.04, 0.3 * v, 'highpass', t() + 0.07); },
    chop: v => { osc('triangle', 260, 120, 0.12, 0.4 * v); burst(1800, 1.5, 0.08, 0.3 * v); },
    mine: v => { osc('square', 900, 700, 0.06, 0.15 * v); burst(3000, 2, 0.08, 0.25 * v); },
    timber: v => { for (let i = 0; i < 5; i++) burst(200 + i * 60, 1, 0.25, 0.25 * v, 'lowpass', t() + i * 0.12); osc('sine', 90, 40, 0.6, 0.4 * v, t() + 0.7); },
    pick: v => { osc('sine', 880, 1320, 0.08, 0.18 * v); osc('sine', 1320, 1760, 0.08, 0.12 * v, t() + 0.07); },
    eat: v => { for (let i = 0; i < 3; i++) burst(1200 + rnd() * 600, 2, 0.05, 0.15 * v, 'bandpass', t() + i * 0.11); },
    splash: v => { burst(1200, 0.5, 0.3, 0.3 * v, 'highpass'); },
    scan: v => { osc('sine', 600, 1800, 0.35, 0.12 * v); osc('sine', 1800, 1800, 0.15, 0.08 * v, t() + 0.36); },
    unlock: v => { [0, 4, 7, 12].forEach((s, i) => osc('triangle', 523 * Math.pow(2, s / 12), 523 * Math.pow(2, s / 12), 0.25, 0.14 * v, t() + i * 0.09)); },
    craft: v => { osc('triangle', 440, 660, 0.12, 0.15 * v); burst(2000, 1, 0.1, 0.15 * v, 'bandpass', t() + 0.05); },
    ko: v => { osc('sine', 300, 60, 0.6, 0.35 * v); },
    ui: v => osc('sine', 700, 900, 0.04, 0.05 * v),
    chirp: v => { const f = 2600 + rnd() * 1800, n = 2 + (rnd() * 4 | 0); for (let i = 0; i < n; i++) osc('sine', f, f * (0.75 + rnd() * 0.6), 0.06 + rnd() * 0.05, 0.04 * v, t() + i * (0.08 + rnd() * 0.05)); },
    cricket: v => { const f = 4200 + rnd() * 400; for (let i = 0; i < 4; i++) osc('square', f, f, 0.02, 0.012 * v, t() + i * 0.045); },
    whistle: v => { osc('sine', 1700, 2500, 0.2, 0.1 * v); osc('sine', 2500, 1500, 0.34, 0.1 * v, t() + 0.24); },
    nicker: v => { for (let i = 0; i < 6; i++) osc('sawtooth', 210 - i * 9, 170 - i * 9, 0.07, 0.05 * v, t() + i * 0.055); burst(500, 1.2, 0.3, 0.08 * v, 'lowpass'); },
    fire: v => burst(2500 + rnd() * 2000, 4, 0.02, 0.08 * v, 'bandpass'),
  };
  let chirpT = 0, cricketT = 0;
  return {
    start, get started() { return started && !!ctx; },
    setOn(v) { on = v; if (master) master.gain.value = v ? 0.8 : 0; },
    get on() { return on; },
    setMusic(v) { musicOn = v; if (music) music.volume = v ? 0.85 : 0; if (fileBus) fileBus.gain.setTargetAtTime(v ? 0.55 : 0, ctx.currentTime, 0.3); },
    get track() { return curTrack ? { mood: curTrack.mood, time: +curTrack.els[curTrack.cur].el.currentTime.toFixed(2), cur: curTrack.cur } : null; },
    get trackStates() { return tracks ? Object.fromEntries(Object.values(tracks).map(X => [X.mood, X.ok])) : null; },
    get musicOn() { return musicOn; },
    set mood(k) { if (k === wantMood) return; wantMood = k; applyMood(k); },
    play(name, vol = 1) { if (!ctx || !on || vol < 0.02) return; try { FX[name]?.(Math.min(1, vol)); } catch (e) {} },
    // per-frame ambience
    update(dt, s) {
      if (!ctx || !on) return;
      const k = 1 - Math.exp(-3 * dt), set = (a, v) => { a.g.gain.value += (v - a.g.gain.value) * k; };
      set(amb.wind, 0.04 + s.wind * 0.22 + s.rain * 0.05); amb.wind.f.frequency.value = 300 + s.wind * 500;
      set(amb.leaves, (0.01 + s.wind * 0.05) * (1 - s.snow)); set(amb.rain, s.rain * 0.35); set(amb.water, s.water * 0.12);
      chirpT -= dt; cricketT -= dt;
      if (chirpT < 0) { chirpT = 0.6 + rnd() * 3.5; if (s.day > 0.4 && s.rain < 0.5) this.play('chirp', 0.6 + rnd() * 0.4); }
      if (cricketT < 0) { cricketT = 0.3 + rnd() * 0.7; if (s.day < 0.3 && s.snow < 0.5) this.play('cricket', 0.8); }
    },
  };
}
