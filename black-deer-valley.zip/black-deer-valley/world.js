// Valley: terrain, sky + time of day, grass, forest, pond, props, motes
import * as THREE from 'three';
import { SimplifyModifier } from 'three/addons/modifiers/SimplifyModifier.js';
const SIMPLIFY = new SimplifyModifier();
import { createForest } from './trees.js';
import { SKY_META } from './assets.js';

export const TAU = Math.PI * 2;
export const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, u) => a + (b - a) * u;
export const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
let rs = 90210; export const rnd = () => (rs = (rs * 16807) % 2147483647) / 2147483647;

export const POND = { x: 30, z: -26, r: 10, y: 0 };
export const TRAIL = { a: 46, b: 34 };
export const WORLD_R = 150;

// ---- terrain (JS + identical GLSL) ----
function baseH(x, z) {
  const r = Math.hypot(x, z);
  let h = 1.6 * Math.sin(x * 0.021 + 1.3) * Math.cos(z * 0.017 - 0.4) + 0.9 * Math.sin(x * 0.047 + z * 0.031 + 0.7) + 0.35 * Math.sin(x * 0.13 - z * 0.11);
  h *= 0.35 + 0.65 * sstep(25, 80, r);
  h += sstep(105, 200, r) * 18 + 3 * sstep(120, 200, r) * Math.sin(Math.atan2(z, x) * 5 + 1);
  return h;
}
export function terrainH(x, z) {
  const dp = Math.hypot(x - POND.x, z - POND.z);
  return baseH(x, z) - 1.6 * sstep(POND.r + 5, POND.r - 3, dp);
}
POND.y = baseH(POND.x, POND.z) - 0.7;
export const GLSL_TERRAIN = `
float sstp(float a, float b, float x){ float t = clamp((x - a) / (b - a), 0.0, 1.0); return t*t*(3.0-2.0*t); }
float terrainH(vec2 p){
  float r = length(p);
  float h = 1.6*sin(p.x*0.021+1.3)*cos(p.y*0.017-0.4) + 0.9*sin(p.x*0.047+p.y*0.031+0.7) + 0.35*sin(p.x*0.13-p.y*0.11);
  h *= 0.35 + 0.65*sstp(25.0, 80.0, r);
  h += sstp(105.0, 200.0, r)*18.0 + 3.0*sstp(120.0, 200.0, r)*sin(atan(p.y, p.x)*5.0+1.0);
  float dp = length(p - vec2(${POND.x.toFixed(2)}, ${POND.z.toFixed(2)}));
  return h - 1.6*sstp(${(POND.r + 5).toFixed(2)}, ${(POND.r - 3).toFixed(2)}, dp);
}
float trailDist(vec2 p){ float e = length(p / vec2(${TRAIL.a.toFixed(1)}, ${TRAIL.b.toFixed(1)})); return abs(e - 1.0) * ${Math.min(TRAIL.a, TRAIL.b).toFixed(1)}; }
float forestD(vec2 p){ float r = length(p); float a = atan(p.y, p.x); return sstp(50.0, 74.0, r + 9.0*sin(a*3.0+1.0) + 5.0*sin(a*7.0+2.0)); }
float pondD(vec2 p){ return length(p - vec2(${POND.x.toFixed(2)}, ${POND.z.toFixed(2)})); }
`;
export const trailDist = (x, z) => Math.abs(Math.hypot(x / TRAIL.a, z / TRAIL.b) - 1) * Math.min(TRAIL.a, TRAIL.b);
export const forestD = (x, z) => { const r = Math.hypot(x, z), a = Math.atan2(z, x); return sstep(50, 74, r + 9 * Math.sin(a * 3 + 1) + 5 * Math.sin(a * 7 + 2)); };
export const pondD = (x, z) => Math.hypot(x - POND.x, z - POND.z);
export function trailPoint(s, out = new THREE.Vector3()) { out.set(Math.cos(s) * TRAIL.a, 0, Math.sin(s) * TRAIL.b); out.y = terrainH(out.x, out.z); return out; }

// ---- atmosphere: height fog + sun in-scattering, patched into every built-in material ----
// Plain-object uniform values are shared by reference across all cloned material uniforms.
export const FOGU = { sun: { x: 0, y: 1, z: 0, w: 0 }, sunCol: { x: 1, y: 0.8, z: 0.6 }, height: { x: 0.085, y: 0, z: 0.5, w: 1.1 } };
const fogExtra = () => ({ fogSun: { value: FOGU.sun }, fogSunCol: { value: FOGU.sunCol }, fogHeight: { value: FOGU.height } });
for (const k in THREE.ShaderLib) { const u = THREE.ShaderLib[k].uniforms; if (u && u.fogDensity) Object.assign(u, fogExtra()); }
Object.assign(THREE.UniformsLib.fog, fogExtra());
// foliage shimmer fix: alpha-tested leaves and grass lose coverage in smaller mips and flicker/thin out with distance; scale alpha up by mip level
THREE.ShaderChunk.alphatest_fragment = `#ifdef USE_ALPHATEST
  #ifdef USE_MAP
    { vec2 dU = dFdx(vMapUv * 512.0), dV = dFdy(vMapUv * 512.0); float mipL = max(0.0, 0.5 * log2(max(dot(dU, dU), dot(dV, dV)))); diffuseColor.a *= 1.0 + mipL * 0.24; }
  #endif
  #ifdef ALPHA_TO_COVERAGE
  diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
  if ( diffuseColor.a == 0.0 ) discard;
  #else
  if ( diffuseColor.a < alphaTest ) discard;
  #endif
#endif`;
THREE.ShaderChunk.fog_pars_vertex = '#ifdef USE_FOG\n varying float vFogDepth; varying vec3 vFogWorld;\n#endif';
THREE.ShaderChunk.fog_vertex = '#ifdef USE_FOG\n vFogDepth = - mvPosition.z; vFogWorld = transpose(mat3(viewMatrix)) * mvPosition.xyz;\n#endif';
THREE.ShaderChunk.fog_pars_fragment = `#ifdef USE_FOG
  uniform vec3 fogColor; varying float vFogDepth; varying vec3 vFogWorld;
  uniform vec4 fogSun; uniform vec3 fogSunCol; uniform vec4 fogHeight;
  #ifdef FOG_EXP2
    uniform float fogDensity;
  #else
    uniform float fogNear; uniform float fogFar;
  #endif
#endif`;
THREE.ShaderChunk.fog_fragment = `#ifdef USE_FOG
  #ifdef FOG_EXP2
    float fDist = length(vFogWorld); vec3 fDir = vFogWorld / max(fDist, 1e-4);
    float fK = fogHeight.x, fY0 = max(cameraPosition.y - fogHeight.y, 0.0), fDy = vFogWorld.y;
    float fE0 = exp(-fK * fY0), fE1 = exp(-fK * max(fY0 + fDy, 0.0));
    float fInt = abs(fK * fDy) > 1e-3 ? (fE0 - fE1) / (fK * fDy) : fE0;
    float fHm = (fogHeight.z + fogHeight.w) < 1e-3 ? 1.0 : fogHeight.z + fogHeight.w * clamp(fInt, 0.0, 1.0);
    float fD = fogDensity * fHm * fDist;
    float fogFactor = 1.0 - exp(-fD * fD);
    float fCs = max(dot(fDir, fogSun.xyz), 0.0);
    vec3 fCol = fogColor + fogSunCol * (0.5 * pow(fCs, 6.0) + 0.85 * pow(fCs, 48.0)) * fogSun.w;
  #else
    float fogFactor = smoothstep(fogNear, fogFar, vFogDepth); vec3 fCol = fogColor;
  #endif
  gl_FragColor.rgb = mix(gl_FragColor.rgb, fCol, fogFactor);
#endif`;

const NOISE2 = `
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn2(vec2 x){ vec2 i = floor(x), f = fract(x); f = f*f*(3.0-2.0*f);
  return mix(mix(h21(i), h21(i+vec2(1,0)), f.x), mix(h21(i+vec2(0,1)), h21(i+vec2(1,1)), f.x), f.y); }
float fbm2(vec2 p){ return vn2(p)*0.5 + vn2(p*2.03+7.1)*0.27 + vn2(p*4.1+3.3)*0.15 + vn2(p*8.3+1.7)*0.08; }
`;

// painted look: wrapped diffuse lights the shadow side softly (as in hand-painted games); patched once before any material compiles
export function setPaintedLighting(on, wrap = 0.45) {
  if (!on) return; const W = wrap.toFixed(2);
  const src = 'float dotNL = saturate( dot( geometryNormal, directLight.direction ) );', wr = `float dotNLw = saturate( ( dot( geometryNormal, directLight.direction ) + ${W} ) / ${(1 + wrap).toFixed(2)} );`;
  // Lambert: diffuse only, so wrap it directly
  THREE.ShaderChunk.lights_lambert_pars_fragment = THREE.ShaderChunk.lights_lambert_pars_fragment.replace(src, src + '\n' + wr + '\n dotNL = dotNLw;');
  // PBR: wrap the diffuse term only (specular keeps the true N.L, or back faces blow up to infinity under bloom)
  const ph = THREE.ShaderChunk.lights_physical_pars_fragment, dl = 'reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );';
  if (ph.includes(src) && ph.includes(dl)) THREE.ShaderChunk.lights_physical_pars_fragment = ph.replace(src, src + '\n' + wr).replace(dl, 'reflectedLight.directDiffuse += dotNLw * directLight.color * BRDF_Lambert( material.diffuseColor );');
  else console.warn('paint: physical light chunk changed');
}
export function createWorld(scene, renderer, camera, LITE, QUALITY, ASSETS) {
  const PAINT = !!QUALITY.painted;
  const TX = ASSETS.tex;
  const U = { snow: { value: 0 }, autumn: { value: 0 }, wet: { value: 0 }, rain: { value: 0 }, cloud: { value: 0.35 }, time: { value: 0 }, wind: { value: 0.45 }, focus: { value: new THREE.Vector2() }, sunV: { value: new THREE.Vector3() }, sunCol: { value: new THREE.Color() }, day: { value: 1 }, zen: { value: new THREE.Color() }, hor: { value: new THREE.Color() } };
  const env = { hour: 17.6, mist: 0.09, wind: 0.45, cloud: 0.35, rain: 0, snow: 0, autumn: 0 };

  // ---- lights ----
  const hemi = new THREE.HemisphereLight(0xffd6a6, 0x4f5a2c, 0.8); scene.add(hemi);
  const key = new THREE.DirectionalLight(0xffc080, 3.2);
  key.castShadow = true; key.shadow.mapSize.set(QUALITY.shadow, QUALITY.shadow);
  Object.assign(key.shadow.camera, { left: -26, right: 26, top: 26, bottom: -26, near: 1, far: 160 });
  key.shadow.bias = -0.0005; key.shadow.normalBias = 0.04;
  scene.add(key, key.target);
  const fill = new THREE.DirectionalLight(0x9fb8e0, 0.35); scene.add(fill, fill.target);
  scene.fog = new THREE.FogExp2(0xe2a46c, 0.012);
  const sunDir = new THREE.Vector3();

  const ENVS = {};
  if (ASSETS.sky.day) { const pm = new THREE.PMREMGenerator(renderer); for (const k of ['day', 'gold', 'dawn', 'night']) ENVS[k] = pm.fromEquirectangular(ASSETS.sky[k]).texture; pm.dispose(); }
  // ---- sky: gradient + Mie halo + lit cumulus with self-shadowing + cirrus + milky way; alpha = open sky (god-ray mask) ----
  const skyU = { uTime: U.time, uWind: U.wind, uCloud: { value: 0.45 }, uSun: { value: sunDir }, uZen: { value: new THREE.Color() }, uHor: { value: new THREE.Color() }, uSunCol: { value: new THREE.Color() }, uDay: { value: 1 }, uNight: { value: 0 }, uFlash: { value: 0 },
    tA: { value: ASSETS.sky.day || null }, tB: { value: ASSETS.sky.day || null }, uMixAB: { value: 0 }, uRotA: { value: 0 }, uRotB: { value: 0 }, uExpA: { value: 1 }, uExpB: { value: 1 }, uPhoto: { value: ASSETS.sky.day && !PAINT ? 1 : 0 }, uClear: { value: 0 } };
  const sky = new THREE.Mesh(new THREE.SphereGeometry(480, 64, 32), new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false, uniforms: skyU,
    vertexShader: 'varying vec3 vW; void main(){ vW = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
    fragmentShader: `uniform vec3 uSun, uZen, uHor, uSunCol; uniform float uDay, uNight, uTime, uCloud, uWind, uFlash, uMixAB, uRotA, uRotB, uExpA, uExpB, uPhoto, uClear; uniform sampler2D tA, tB; varying vec3 vW;
      ${NOISE2}
      vec3 eq(sampler2D t, vec3 d, float rot){ vec2 uv = vec2(atan(d.z, d.x) / 6.2831853 + 0.5 - rot, 0.5 - asin(clamp(d.y, -1.0, 1.0)) / 3.14159265); return min(texture2D(t, uv).rgb, vec3(24.0)); }
      float cloudD(vec2 p, vec2 off){ return fbm2(p * 1.1 + off) * 0.72 + fbm2(p * 3.7 + off * 1.7 + 4.0) * 0.28; }
      void main(){ vec3 d = normalize(vW); float h = d.y;
        vec3 c = mix(uHor, uZen, smoothstep(0.0, 1.0, pow(max(h, 0.0), 0.5)));
        c = mix(c, uHor * 0.82, smoothstep(0.0, -0.14, h));
        float s = max(dot(d, uSun), 0.0), lowSun = 1.0 - smoothstep(0.04, 0.45, uSun.y);
        vec2 dz = normalize(d.xz + 1e-5), sz = normalize(uSun.xz + 1e-5);
        float az = max(dot(dz, sz), 0.0);
        c += uSunCol * (pow(s, 5.0) * 0.26 + pow(s, 32.0) * 0.42 + pow(s, 320.0) * 0.8) * uDay;
        c += uSunCol * pow(az, 3.0) * exp(-max(h, 0.0) * 6.0) * 0.42 * lowSun * uDay;
        c = mix(c, c * vec3(0.84, 0.92, 1.1), (1.0 - az) * lowSun * 0.55 * uDay);
        c = mix(c, c * vec3(1.1, 1.0, 0.84) + uSunCol * 0.05, exp(-max(h, 0.0) * 8.0) * uClear * 0.55); // dusty golden horizon
        // moon + night glow + milky way
        float m = max(dot(d, -uSun), 0.0);
        c += vec3(0.85, 0.9, 1.0) * smoothstep(0.99955, 0.9998, m) * 3.2 * uNight + vec3(0.25, 0.32, 0.5) * pow(m, 12.0) * 0.22 * uNight;
        float band = exp(-pow(dot(d, normalize(vec3(0.35, 0.25, 0.9))), 2.0) * 14.0);
        c += vec3(0.32, 0.34, 0.45) * band * (0.35 + 0.65 * fbm2(d.xz * 9.0 + d.y * 4.0)) * 0.12 * uNight * smoothstep(0.0, 0.25, h) * (1.0 - uCloud);
        float occ = 0.0;
        if (h > -0.03) {
          vec2 cu = d.xz / (max(h, 0.0) + 0.09) * 0.8, off = vec2(uTime * 0.006 * (0.6 + uWind), uTime * 0.0022);
          float dens = cloudD(cu, off);
          float cov = max(smoothstep(0.66 - uCloud * 0.4 - uClear * 0.07, 0.92 - uCloud * 0.28 - uClear * 0.06, dens), smoothstep(0.86, 1.0, uCloud) * 0.9);
          float dl = cloudD(cu + sz * 0.16, off);
          float shade = clamp(1.0 - (dl - dens) * 3.2 - 0.12 * uCloud, 0.22, 1.0);
          float edge = clamp((1.0 - cov) * cov * 4.0, 0.0, 1.0);
          float fadeH = smoothstep(-0.03, 0.1, h);
          vec3 litc = mix(uHor, vec3(1.0, 0.97, 0.93), 0.55 * uDay) * mix(0.16, 1.0, uDay);
          vec3 cc = litc * vec3(1.0 + 0.04 * uClear, 1.0, 1.0 - 0.07 * uClear) * mix(0.42, 1.06, shade) + uSunCol * (pow(s, 4.0) * 0.55 + edge * pow(s, 6.0) * 1.6 + lowSun * shade * 0.35) * uDay;
          cc *= 1.0 - 0.5 * smoothstep(0.55, 1.0, uCloud) * (1.0 - 0.6 * shade);
          cc = mix(cc, uHor * 0.9, smoothstep(0.22, 0.0, h) * 0.65);
          cc = mix(cc, vec3(0.06, 0.075, 0.12), uNight * 0.85);
          cc += vec3(0.75, 0.8, 1.0) * uFlash * 1.6 * (0.4 + shade);
          vec2 ci = d.xz / (max(h, 0.0) + 0.25) * 0.35 + off * 0.5;
          float cir = smoothstep(0.55, 0.88, fbm2(vec2(ci.x * 0.6, ci.y * 3.0))) * 0.32 * (1.0 - uCloud * 0.7) * fadeH * (1.0 - uNight * 0.7);
          c = mix(c, litc * 1.04 + uSunCol * pow(s, 3.0) * 0.45 * uDay, cir);
          c = mix(c, cc, cov * 0.95 * fadeH);
          occ = cov * fadeH;
        }
        float disc = smoothstep(0.99962, 0.99986, s) * (1.0 - occ);
        c += vec3(1.0, 0.92, 0.8) * disc * 12.0 * uDay;
        // photographed sky (CC0 HDRIs), rotated so its sun sits where our sun is; storms fall back to the drawn overcast
        if (uPhoto > 0.0) {
          vec3 ph = mix(eq(tA, d, uRotA) * uExpA, eq(tB, d, uRotB) * uExpB, uMixAB);
          ph = mix(uHor * 0.92, ph, smoothstep(-0.005, 0.07, h));
          // clear bright days: deepen the photo's washed-out blue toward a clean western sky, and let the drawn gradient show through
          float pl = dot(ph, vec3(0.3, 0.59, 0.11)); vec3 blue = mix(vec3(pl), ph, 1.35) * vec3(0.84, 0.96, 1.18);
          ph = mix(ph, mix(blue, uZen * (0.85 + pl * 0.6), 0.35 * smoothstep(0.08, 0.7, h)), uClear * smoothstep(0.0, 0.25, h) * (1.0 - smoothstep(0.62, 0.9, pl)));
          float wph = uPhoto * (1.0 - smoothstep(0.5, 0.9, uCloud)) * (1.0 - 0.55 * uClear);
          c = mix(c, ph, wph); occ *= 1.0 - wph;
        }
        c += vec3(0.6, 0.65, 0.8) * uFlash * 0.25;
        gl_FragColor = vec4(c, mix(1.0, occ * 0.92, smoothstep(-0.02, 0.03, h))); // alpha < 1 = open sky (god-ray source mask)
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }` }));
  sky.renderOrder = -2; scene.add(sky);
  const starG = new THREE.BufferGeometry(), sp = [], sSize = [];
  for (let i = 0; i < 2600; i++) { const u = rnd() * 2 - 1, a = rnd() * TAU, y = Math.abs(u) * 0.95 + 0.05, r = Math.sqrt(1 - y * y); sp.push(Math.cos(a) * r * 440, y * 440, Math.sin(a) * r * 440); sSize.push(rnd()); }
  starG.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3)); starG.setAttribute('aS', new THREE.Float32BufferAttribute(sSize, 1));
  const starM = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, fog: false, uniforms: { uOp: { value: 0 }, uTime: U.time },
    vertexShader: 'attribute float aS; uniform float uTime; varying float vB; void main(){ vB = (0.35 + 0.65 * aS * aS) * (0.75 + 0.25 * sin(uTime * (1.5 + aS * 3.0) + aS * 40.0)); vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = 1.0 + aS * aS * 2.2; }',
    fragmentShader: 'uniform float uOp; varying float vB; void main(){ float d = length(gl_PointCoord - 0.5); gl_FragColor = vec4(vec3(0.88, 0.92, 1.0) * vB, smoothstep(0.5, 0.1, d) * uOp); }' });
  const stars = new THREE.Points(starG, starM); stars.renderOrder = -1; scene.add(stars);

  // ---- far ranges: layered ridges with aerial perspective (depth beyond the valley rim) ----
  const ridgeMats = [], ridgeMurk = { value: 0 };
  function ridge(R, h0, amp, seed, aerial) {
    const N = 360, P = [], I = [];
    for (let i = 0; i <= N; i++) { const a = i / N * TAU, n = 0.5 + 0.28 * Math.sin(a * 3 + seed) + 0.14 * Math.sin(a * 7.3 + seed * 2.1) + 0.06 * Math.sin(a * 17.9 + seed * 3.7) + 0.02 * Math.sin(a * 61.3 + seed);
      const y = h0 + amp * n; P.push(Math.cos(a) * R, y, Math.sin(a) * R, Math.cos(a) * R, -40, Math.sin(a) * R); if (i < N) { const k = i * 2; I.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); } }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setIndex(I);
    const m = new THREE.ShaderMaterial({ fog: false, side: THREE.DoubleSide, transparent: true, uniforms: { uHor: skyU.uHor, uZen: skyU.uZen, uSunCol: skyU.uSunCol, uSun: skyU.uSun, uDay: skyU.uDay, uAer: { value: aerial }, uSnow: U.snow, uTop: { value: h0 + amp }, uMurk: ridgeMurk },
      vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fragmentShader: `uniform vec3 uHor, uZen, uSunCol, uSun; uniform float uDay, uAer, uSnow, uTop, uMurk; varying vec3 vP;` + NOISE2 + `
        void main(){ float hy = clamp(vP.y / uTop, 0.0, 1.0); vec2 dir = normalize(vP.xz);
          float ang = atan(vP.z, vP.x); float gully = fbm2(vP.xz * 0.025 + vec2(vP.y * 0.035, -vP.y * 0.02)) * 0.7 + fbm2(vec2(ang * 22.0, vP.y * 0.09)) * 0.3; vec3 rock = mix(vec3(0.1, 0.13, 0.1), vec3(0.27, 0.28, 0.25), gully) * (0.15 + 0.85 * uDay);
          rock = mix(rock, vec3(0.05, 0.08, 0.05) * (0.2 + 0.8 * uDay) * (0.8 + 0.4 * fbm2(vP.xz * 0.08)), smoothstep(0.95, 0.4, hy)); // forested hills, bare only at the very top
          float cap = smoothstep(0.7, 0.9, hy + 0.1 * fbm2(vP.xz * 0.05)) * (0.35 + 0.65 * uSnow);
          rock = mix(rock, vec3(0.7, 0.72, 0.78) * (0.25 + 0.75 * uDay), cap);
          rock += uSunCol * pow(max(dot(dir, normalize(uSun.xz + 1e-5)), 0.0), 3.0) * 0.18 * uDay * hy;
          vec3 haze = mix(uHor, uZen, 0.22) * vec3(0.9, 0.96, 1.06);
          vec3 c = mix(rock, mix(haze, uHor, uMurk), clamp(mix(uAer, 1.0, uMurk) + (1.0 - hy) * 0.3, 0.0, 1.0));
          gl_FragColor = vec4(c, 1.0 - smoothstep(0.55, 1.0, uMurk) * 0.98); // storms and thick fog swallow the far ranges
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }` });
    const mesh = new THREE.Mesh(g, m); mesh.renderOrder = -1; mesh.frustumCulled = false; scene.add(mesh); ridgeMats.push(m); return mesh;
  }
  ridge(440, 24, 98, 2.3, 0.74); ridge(320, 8, 40, 5.1, 0.5); // taller far range so blue peaks clear the treeline, like the target renders


  // ---- ground ----
  const AO_W = 360, tAO = { value: null }; // contact shadows baked from every tree, rock, log and stump (filled once they are placed)
  const SEG = LITE ? 180 : 260, SIZE = 440;
  const gGeo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG); gGeo.rotateX(-Math.PI / 2);
  { const P = gGeo.attributes.position; for (let i = 0; i < P.count; i++) P.setY(i, terrainH(P.getX(i), P.getZ(i))); gGeo.computeVertexNormals(); }
  const gMat = new THREE.MeshStandardMaterial({ roughness: 1, color: 0xffffff });
  gMat.userData.env = 0.35;
  gMat.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;').replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWP = (modelMatrix * vec4(transformed, 1.0)).xyz; vWN = normalize(objectNormal);');
    Object.assign(sh.uniforms, { uSnow: U.snow, uWet: U.wet, uRain: U.rain, uTime: U.time, uWind: U.wind, uCloud: U.cloud, uZen: U.zen, uHor: U.hor, uDay: U.day,
      tAO, tGrass: { value: TX.grass }, tDirt: { value: TX.dirt }, tDirtN: { value: TX.dirtN }, tRock: { value: TX.rock }, tRockN: { value: TX.rockN }, tTrail: { value: TX.trail } });
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN; uniform float uSnow, uWet, uRain, uTime, uWind, uCloud, uDay; uniform vec3 uZen, uHor; uniform sampler2D tAO, tGrass, tDirt, tDirtN, tRock, tRockN, tTrail; float gPud, gRock, gTrail, gForest, gSnowAmt; vec3 gNts;' + NOISE2 + GLSL_TERRAIN + `
        // two rotated scales blended by noise hide texture tiling
        vec3 tex2(sampler2D t, vec2 p, float s, float k){ ${QUALITY.lightGround ? 'return texture2D(t, p * s).rgb;' : 'vec2 q = vec2(p.x * 0.8 - p.y * 0.6, p.x * 0.6 + p.y * 0.8); return mix(texture2D(t, p * s).rgb, texture2D(t, q * s * 0.37 + 0.31).rgb, k);'} }`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        { vec2 p = vWP.xz; float macro = fbm2(p * 0.03), n2 = fbm2(p * 0.9), k = smoothstep(0.3, 0.7, fbm2(p * 0.11));
          vec3 grass = tex2(tGrass, p, 0.21, k);
          grass *= mix(vec3(1.1, 1.08, 0.72), vec3(0.86, 1.12, 0.8), macro) * 1.45;               // dry / lush drifts across the meadow
          { float dp = smoothstep(0.48, 0.74, fbm2(p * 0.045 + 7.3)) * (0.7 + 0.3 * n2); // sun-cured golden patches
            grass = mix(grass, grass * vec3(1.32, 1.04, 0.5) + vec3(0.03, 0.02, 0.0), dp * 0.85); }
          vec3 dirt = tex2(tDirt, p, 0.25, k);
          vec3 rock = tex2(tRock, p, 0.16, k) * vec3(0.92, 0.9, 0.86);
          vec3 trail = mix(tex2(tTrail, p, 0.3, k) * vec3(0.78, 0.66, 0.52), dirt * 1.2, 0.45);
          gForest = forestD(p);
          vec3 floorC = mix(dirt * vec3(1.02, 0.9, 0.74), dirt * vec3(0.66, 0.76, 0.44), smoothstep(0.45, 0.7, n2) * 0.6); // needles and moss
          { float lf = fbm2(p * 0.45 + 3.1), lf2 = fbm2(p * 2.3); // leaf litter drifts in ambers and browns
            vec3 litter = mix(vec3(0.36, 0.22, 0.1), vec3(0.5, 0.34, 0.14), lf2) * (0.8 + 0.4 * dot(dirt, vec3(0.33)) / 0.3);
            floorC = mix(floorC, litter, smoothstep(0.45, 0.72, lf) * 0.75); }
          vec3 c = mix(grass, floorC, smoothstep(0.15, 0.85, gForest + (n2 - 0.5) * 0.4));
          float td = trailDist(p) + (n2 - 0.5) * 0.9;
          gTrail = smoothstep(1.5, 0.5, td);
          c *= 1.0 - 0.2 * smoothstep(0.0, 0.35, gTrail) * (1.0 - smoothstep(0.55, 1.0, gTrail)); // crushed, shadowed trail edges
          c = mix(c, trail, gTrail);
          float pd = pondD(p);
          float shore = smoothstep(${(POND.r + 2.8).toFixed(1)}, ${(POND.r + 0.4).toFixed(1)}, pd + (n2 - 0.5) * 1.2);
          c = mix(c, dirt * vec3(0.55, 0.5, 0.42), shore);
          float slope = 1.0 - vWN.y;
          gRock = clamp(smoothstep(0.62, 0.95, (vWP.y - 6.0) / 14.0) * (0.6 + 0.4 * n2) + smoothstep(0.2, 0.38, slope + (n2 - 0.5) * 0.15), 0.0, 1.0);
          rock *= 0.78 + 0.5 * fbm2(p * 3.1 + vWP.y * 0.7); // strata and weathering
          c = mix(c, rock, gRock);
          // contact shadows: soft darkening under trunks, canopies, rocks and logs
          c *= mix(0.42, 1.0, texture2D(tAO, p / ${AO_W.toFixed(1)} + 0.5).r);
          // cloud shadows drifting with the wind
          float cs = smoothstep(0.42, 0.72, fbm2(p * 0.011 + vec2(uTime * 0.012 * (0.5 + uWind), uTime * 0.004)));
          c *= 1.0 - 0.36 * cs * smoothstep(0.15, 0.6, uCloud) * uDay * (1.0 - smoothstep(0.85, 1.0, uCloud) * 0.6);
          gPud = uWet * smoothstep(0.6, 0.7, fbm2(p * 0.22) + gTrail * 0.14 + shore * 0.15 - gRock * 0.4);
          c = mix(c, c * 0.62, uWet * 0.7);
          c = mix(c, c * 0.35, gPud);
          gSnowAmt = uSnow * smoothstep(0.2, 0.6, fbm2(p * 0.35) + 0.4 * uSnow) * (1.0 - gRock * 0.5);
          c = mix(c, vec3(0.66, 0.69, 0.74) * (0.9 + 0.1 * n2), gSnowAmt);
          // tangent-space normal from the dirt / rock maps (grass areas borrow a softened dirt normal)
          vec3 nd = texture2D(tDirtN, p * 0.25).xyz * 2.0 - 1.0, nr = texture2D(tRockN, p * 0.16).xyz * 2.0 - 1.0;
          gNts = normalize(mix(mix(nd * vec3(0.45, 0.45, 1.0), nd, max(gForest, gTrail)), nr, gRock) * vec3(1.0, 1.0, 1.0 + 2.0 * (gPud + gSnowAmt)));
          // micro detail: the same photos at 4x frequency, faded in near the camera so close ground stays sharp at 4K
          float dn = (1.0 - smoothstep(5.0, 24.0, length(vViewPosition))) * (1.0 - gSnowAmt) * (1.0 - gPud);
          if (${QUALITY.lightGround ? 'false' : 'true'} && dn > 0.001) { vec2 pr = vec2(p.x * 0.6 + p.y * 0.8, -p.x * 0.8 + p.y * 0.6);
            vec3 det = mix(mix(texture2D(tGrass, pr * 0.9).rgb, texture2D(tDirt, pr * 1.05).rgb, max(gForest, gTrail)), texture2D(tRock, pr * 0.72).rgb, gRock);
            float dl = dot(det, vec3(0.3, 0.59, 0.11)) / 0.3;
            c *= mix(1.0, clamp(dl, 0.55, 1.6), 0.42 * dn);
            vec3 nd2 = mix(texture2D(tDirtN, pr * 1.05).xyz, texture2D(tRockN, pr * 0.72).xyz, gRock) * 2.0 - 1.0;
            gNts = normalize(gNts + vec3(nd2.xy * 0.6 * dn, 0.0)); }
          ${PAINT ? `{ float lum = dot(texture2D(tGrass, p * 0.21, 4.0).rgb, vec3(0.33)) / 0.3;
            vec3 gA = vec3(0.15, 0.29, 0.09), gB = vec3(0.31, 0.45, 0.14), gDry = vec3(0.5, 0.47, 0.22);
            vec3 pg = mix(mix(gA, gB, smoothstep(0.25, 0.75, macro)), gDry, smoothstep(0.6, 0.85, fbm2(p * 0.05 + 7.0)) * 0.5) * mix(0.9, 1.08, lum);
            vec3 pf = mix(vec3(0.36, 0.26, 0.16), vec3(0.5, 0.36, 0.2), n2), pt = vec3(0.72, 0.58, 0.4) * mix(0.92, 1.05, n2), pr = vec3(0.55, 0.55, 0.52) * mix(0.85, 1.1, n2);
            vec3 pc = mix(pg, pf, smoothstep(0.15, 0.85, gForest + (n2 - 0.5) * 0.4)); pc = mix(pc, pt, gTrail); pc = mix(pc, vec3(0.42, 0.36, 0.28), shore); pc = mix(pc, pr, gRock);
            pc = mix(pc, vec3(0.8, 0.84, 0.9), gSnowAmt); pc *= 1.0 - 0.3 * cs * smoothstep(0.15, 0.6, uCloud) * uDay;
            c = mix(c, pc, 0.85); gNts = normalize(mix(gNts, vec3(0.0, 0.0, 1.0), 0.6)); }` : ''}
          diffuseColor.rgb = c; }`)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(mix(0.95, 0.8, gRock), 0.5, uWet * 0.6); roughnessFactor = mix(roughnessFactor, 0.06, gPud);')
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        { vec3 N = normalize(vWN), Tn = normalize(vec3(1.0, 0.0, 0.0) - N * N.x), Bn = normalize(cross(Tn, N));
          vec3 nw = normalize(Tn * gNts.x + Bn * gNts.y + N * gNts.z);
          normal = normalize((viewMatrix * vec4(nw, 0.0)).xyz); }`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        { vec3 V = normalize(vViewPosition); float fr = pow(1.0 - clamp(dot(normal, V), 0.0, 1.0), 4.0);
          vec2 pp = vWP.xz * 2.2; vec2 id = floor(pp); vec2 f = fract(pp) - 0.5 - (vec2(h21(id), h21(id + 7.0)) - 0.5) * 0.5;
          float ph = fract(uTime * 1.3 + h21(id + 3.0)); float rr = length(f);
          float ring = uRain * smoothstep(0.03, 0.0, abs(rr - ph * 0.45)) * (1.0 - ph);
          totalEmissiveRadiance += mix(uHor, uZen, 0.35) * (fr * 0.9 + 0.06 + ring * 0.5) * gPud; }`);
  };
  const ground = new THREE.Mesh(gGeo, gMat); ground.receiveShadow = true; scene.add(ground);

  // ---- pond: planar reflection (High), fresnel, depth tint, wind ripples + rain rings, sun glitter ----
  const REFL = !LITE && QUALITY.reflect !== false;
  const reflRT = REFL ? new THREE.WebGLRenderTarget(QUALITY.reflSize || 512, QUALITY.reflSize || 512, { type: THREE.HalfFloatType }) : null;
  const reflCam = new THREE.PerspectiveCamera(); reflCam.layers.set(0);
  const reflMat = new THREE.Matrix4();
  const wU = THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { uTime: { value: 0 }, uZen: { value: new THREE.Color() }, uHor: { value: new THREE.Color() }, uSun: { value: sunDir }, uSunCol: { value: new THREE.Color() }, uDay: { value: 1 }, uRain: { value: 0 }, uWind: { value: 0.45 }, tRefl: { value: reflRT ? reflRT.texture : null }, uReflOn: { value: 0 }, uReflMat: { value: reflMat } }]);
  Object.assign(wU, fogExtra()); wU.uRain = U.rain; wU.uWind = U.wind; wU.uReflMat.value = reflMat; wU.tRefl.value = reflRT ? reflRT.texture : null; // merge() clones textures: re-point at the live render target
  const water = new THREE.Mesh(new THREE.CircleGeometry(POND.r + 3.5, 96).rotateX(-Math.PI / 2), new THREE.ShaderMaterial({
    transparent: true, fog: true, uniforms: wU,
    vertexShader: `#include <fog_pars_vertex>
      varying vec3 vWP; void main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vWP = wp.xyz; vec4 mvPosition = viewMatrix * wp; gl_Position = projectionMatrix * mvPosition;
      #include <fog_vertex>
      }`,
    fragmentShader: `#include <fog_pars_fragment>
      uniform float uTime, uDay, uRain, uWind, uReflOn; uniform vec3 uZen, uHor, uSun, uSunCol; uniform sampler2D tRefl; uniform mat4 uReflMat; varying vec3 vWP;` + NOISE2 + `
      vec2 rings(vec2 p, float t){ vec2 id = floor(p), f = fract(p) - 0.5; vec2 o = (vec2(h21(id), h21(id + 5.3)) - 0.5) * 0.6; vec2 q = f - o;
        float ph = fract(t * 1.1 + h21(id + 9.1)); float r = length(q); float w = sin((r - ph * 0.45) * 70.0) * smoothstep(0.08, 0.0, abs(r - ph * 0.45)) * (1.0 - ph);
        return q / max(r, 1e-3) * w; }
      void main(){ vec2 p = vWP.xz; float t = uTime * (0.6 + uWind);
        vec2 g = vec2(vn2(p * 1.3 + t * 0.35) - vn2(p * 1.3 + vec2(3.1) - t * 0.3), vn2(p * 1.7 + vec2(7.0) + t * 0.25) - vn2(p * 1.6 - t * 0.28));
        g += 0.5 * vec2(vn2(p * 4.3 + t * 0.9) - vn2(p * 4.1 + 2.0 - t * 0.8), vn2(p * 3.9 + 5.0 - t * 0.7) - vn2(p * 4.4 + 9.0 + t)) ;
        g *= 0.12 + 0.16 * uWind;
        g += (rings(p * 2.6, uTime) + rings(p * 2.6 + 0.5, uTime * 1.13 + 0.4)) * 0.22 * uRain;
        vec3 n = normalize(vec3(g.x, 1.0, g.y));
        vec3 v = normalize(cameraPosition - vWP);
        float fr = 0.02 + 0.98 * pow(1.0 - max(dot(n, v), 0.0), 5.0);
        vec3 r = reflect(-v, n);
        vec3 refl = mix(uHor, uZen, smoothstep(0.0, 0.6, r.y));
        if (uReflOn > 0.5) { vec4 rp = uReflMat * vec4(vWP, 1.0); vec2 ruv = rp.xy / rp.w + n.xz * 0.05; vec4 rs = texture2D(tRefl, clamp(ruv, 0.001, 0.999)); refl = mix(refl, rs.rgb, rs.a * 0.0 + 1.0); }
        float dist = length(p - vec2(${POND.x.toFixed(2)}, ${POND.z.toFixed(2)}));
        float shallow = smoothstep(${(POND.r * 0.55).toFixed(1)}, ${(POND.r + 1.5).toFixed(1)}, dist);
        vec3 body = mix(vec3(0.015, 0.04, 0.035), vec3(0.1, 0.11, 0.065), shallow) * (0.2 + 0.8 * uDay);
        vec3 c = mix(body, refl, clamp(fr * 1.15, 0.0, 1.0));
        float sp = max(dot(r, uSun), 0.0);
        c += uSunCol * (pow(sp, 900.0) * 9.0 + pow(sp, 90.0) * 0.5) * uDay;
        c += vec3(0.25, 0.24, 0.2) * smoothstep(${(POND.r + 1.2).toFixed(1)}, ${(POND.r + 2.2).toFixed(1)}, dist) * 0.35 * uDay * (0.5 + 0.5 * vn2(p * 6.0 + uTime));
        gl_FragColor = vec4(c, smoothstep(${(POND.r + 3.5).toFixed(1)}, ${(POND.r + 2.0).toFixed(1)}, dist) * 0.96);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }` }));
  water.position.set(POND.x, POND.y, POND.z); water.layers.set(1); scene.add(water);
  const pondSphere = new THREE.Sphere(new THREE.Vector3(POND.x, POND.y, POND.z), POND.r + 4);
  const frus = new THREE.Frustum(), pm = new THREE.Matrix4(), rv = new THREE.Vector3(), ru = new THREE.Vector3();
  const bias = new THREE.Matrix4().set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
  let reflOn = REFL, reflFrame = 0;
  function renderReflection() {
    wU.uReflOn.value = 0;
    if (!reflOn || !reflRT) return;
    if (camera.position.distanceTo(pondSphere.center) > 150 || camera.position.y < POND.y) return;
    camera.updateMatrixWorld(); pm.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse); frus.setFromProjectionMatrix(pm);
    if (!frus.intersectsSphere(pondSphere)) return;
    wU.uReflOn.value = 1;
    if ((reflFrame++ & (QUALITY.reflEvery || 1) - 1) !== 0) return;
    reflCam.fov = camera.fov; reflCam.aspect = camera.aspect; reflCam.near = camera.near; reflCam.far = camera.far; reflCam.updateProjectionMatrix();
    camera.getWorldDirection(rv); ru.set(0, 1, 0).applyQuaternion(camera.quaternion);
    reflCam.position.set(camera.position.x, 2 * POND.y - camera.position.y, camera.position.z);
    rv.y = -rv.y; ru.y = -ru.y; reflCam.up.copy(ru); reflCam.lookAt(reflCam.position.x + rv.x, reflCam.position.y + rv.y, reflCam.position.z + rv.z);
    reflCam.updateMatrixWorld();
    reflMat.copy(bias).multiply(reflCam.projectionMatrix).multiply(reflCam.matrixWorldInverse);
    // no clip plane: everything below the waterline is back-facing from the mirrored camera, and toggling clip planes would swap shader programs every frame
    const prevT = renderer.getRenderTarget(), prevAuto = renderer.shadowMap.autoUpdate;
    renderer.shadowMap.autoUpdate = false;
    sky.position.copy(reflCam.position); stars.position.copy(reflCam.position);
    renderer.setRenderTarget(reflRT); renderer.clear(); renderer.render(scene, reflCam);
    renderer.setRenderTarget(prevT); renderer.shadowMap.autoUpdate = prevAuto;
    sky.position.copy(camera.position); stars.position.copy(camera.position);
  }


  // ---- grass (follows the focus, wraps on a patch) ----
  const GW = QUALITY.grassW;
  function makeGrass(count) {
    // photo grass clump: three crossed alpha cards (texture from the ez-tree demo), tinted per clump
    const pos = [], uvs = [], idx = [];
    for (let k = 0; k < 3; k++) { const a = k / 3 * Math.PI + 0.3, c = Math.cos(a) * 0.5, s2 = Math.sin(a) * 0.5, o = pos.length / 3;
      pos.push(-c, 0, -s2, c, 0, s2, c, 1, s2, -c, 1, -s2); uvs.push(0, 0, 1, 0, 1, 1, 0, 1); idx.push(o, o + 1, o + 2, o, o + 2, o + 3); }
    const g = new THREE.InstancedBufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setIndex(idx);
    g.setAttribute('normal', new THREE.Float32BufferAttribute(pos.map((_, i) => i % 3 === 1 ? 1 : 0), 3));
    const off = new Float32Array(count * 4), col = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      off.set([(rnd() - 0.5) * GW, (rnd() - 0.5) * GW, 0.2 + rnd() * 0.3 + (rnd() < 0.08 ? 0.22 : 0), rnd() * TAU], i * 4);
      const dry = rnd() < 0.5, v = 0.75 + rnd() * 0.4; col.set(dry ? [1.32 * v, 1.02 * v, 0.5 * v] : [0.88 * v, 1.0 * v, 0.58 * v], i * 3); // half the clumps sun-cured gold, like the target renders
    }
    g.setAttribute('aOff', new THREE.InstancedBufferAttribute(off, 4)); g.setAttribute('aCol', new THREE.InstancedBufferAttribute(col, 3));
    g.instanceCount = count; g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    // phones: Lambert lighting (no PBR, no environment probe) for the grass cards, the single most-drawn surface on screen
    const m = QUALITY.cheapGrass ? new THREE.MeshLambertMaterial({ color: 0xffffff, side: THREE.DoubleSide, map: TX.clump, alphaTest: 0.42 })
      : new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.82, side: THREE.DoubleSide, map: TX.clump, alphaTest: 0.42, alphaToCoverage: !!QUALITY.a2c });
    m.userData.env = 0.3;
    m.onBeforeCompile = sh => {
      if (PAINT) sh.fragmentShader = sh.fragmentShader.replace('#include <map_fragment>', '#include <map_fragment>\n diffuseColor.rgb = vec3(0.62);').replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n diffuseColor.rgb = mix(vec3(0.08, 0.17, 0.06), vec3(0.3, 0.46, 0.15), smoothstep(0.0, 0.95, vH)) * mix(vec3(1.0), vCol, 0.5);');
      Object.assign(sh.uniforms, { tAO, uTime: U.time, uWind: U.wind, uFocus: U.focus, uSunV: U.sunV, uSunCol: U.sunCol, uDay: U.day, uSnow: U.snow, uAutumn: U.autumn, uWet: U.wet });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', `#include <common>
        attribute vec4 aOff; attribute vec3 aCol; uniform float uTime, uWind, uSnow; uniform vec2 uFocus; uniform sampler2D tAO; varying float vH; varying vec3 vCol;
        float gh(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }` + NOISE2 + GLSL_TERRAIN)
        .replace('#include <beginnormal_vertex>', 'vec3 objectNormal = vec3(0.0, 1.0, 0.0);')
        .replace('#include <begin_vertex>', `
          float h = position.y;
          vec2 q = uFocus + mod(aOff.xy - uFocus + ${(GW / 2).toFixed(1)}, ${GW.toFixed(1)}) - ${(GW / 2).toFixed(1)};
          float fd = length(q - uFocus);
          float ht = aOff.z * smoothstep(${(GW / 2).toFixed(1)}, ${(GW / 2 - 6).toFixed(1)}, fd);
          ht *= smoothstep(0.5, 1.4, trailDist(q)) * smoothstep(${(POND.r + 0.8).toFixed(1)}, ${(POND.r + 2.2).toFixed(1)}, pondD(q));
          ht *= 1.0 - 0.75 * forestD(q);
          ht *= 1.0 - smoothstep(110.0, 130.0, length(q));
          ht *= 1.0 - 0.55 * uSnow;
          ht *= 0.55 + 0.8 * vn2(q * 0.21 + 3.0);
          if (gh(aOff.xy + 7.7) > mix(1.0, ${(QUALITY.grassFar ?? 0.35).toFixed(2)}, smoothstep(7.0, ${(GW / 2).toFixed(1)}, fd))) ht = 0.0; // distance thinning: the photo ground carries the far meadow
          float c = cos(aOff.w), s = sin(aOff.w);
          float wdt = (0.38 + ht * 0.8) * (0.75 + 0.5 * gh(aOff.xy)); // narrower cards: far less overdraw for the same look
          vec3 p = vec3(position.x * c - position.z * s, 0.0, position.x * s + position.z * c) * wdt;
          float wind = uWind * (0.32 * sin(uTime * 1.9 + q.x * 0.32 + q.y * 0.21) + 0.1 * sin(uTime * 5.1 + q.x * 1.7 + q.y * 0.9) + 0.25);
          float lean = 0.35 * (gh(aOff.xy + 3.1) - 0.5);
          float gust = uWind * 0.35 * smoothstep(0.45, 0.85, vn2(q * 0.05 - vec2(uTime * 0.9, uTime * 0.25)));
          vec2 bend = vec2(wind + gust + lean * c, lean * s + (wind + gust) * 0.3) * h * h * ht;
          vec2 dq = q - uFocus; float pdd = length(dq); float pk = smoothstep(1.3, 0.25, pdd);
          bend += dq / max(pdd, 1e-3) * pk * 0.55 * h * h * ht;
          vec3 transformed = vec3(q.x, terrainH(q) - 0.02, q.y) + p + vec3(bend.x, h * ht * 1.45 * (1.0 - 0.25 * h * abs(wind + gust) - 0.45 * pk), bend.y);
          vH = h; vCol = aCol * mix(vec3(1.1, 1.0, 0.78), vec3(0.88, 1.03, 0.92), vn2(q * 0.045 + 11.0)) * mix(0.4, 1.0, texture2D(tAO, q / ${AO_W.toFixed(1)} + 0.5).r);`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying float vH; varying vec3 vCol; uniform vec3 uSunV, uSunCol; uniform float uDay, uSnow, uAutumn, uWet;')
        .replace('#include <normal_fragment_begin>', 'float faceDirection = 1.0; vec3 normal = normalize(vNormal); vec3 nonPerturbedNormal = normal;')
        .replace('#include <color_fragment>', '#include <color_fragment>\n diffuseColor.rgb *= mix(vec3(0.16, 0.24, 0.07), mix(vec3(0.62, 0.66, 0.3), vec3(0.78, 0.6, 0.26), uAutumn), smoothstep(0.0, 0.9, vH)) * vCol * 1.25; diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.6, 0.63, 0.68), uSnow * smoothstep(0.3, 1.0, vH)); diffuseColor.rgb *= 1.0 - 0.28 * uWet;')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n float back = pow(max(dot(normalize(-vViewPosition), uSunV), 0.0), 5.0); totalEmissiveRadiance += uSunCol * back * vH * vH * 0.7 * vCol * uDay;');
    };
    const mesh = new THREE.Mesh(g, m); mesh.frustumCulled = false; mesh.receiveShadow = QUALITY.grassShadow !== false; return mesh;
  }
  const grassMesh = makeGrass(Math.round(QUALITY.grass * 0.45)); grassMesh.layers.set(1); scene.add(grassMesh);
  const GRASS_MAX = Math.round(QUALITY.grass * 0.45);
  function makeFlowers(count) {
    // stem + two crossed head cards; heads cut to petals in the fragment shader; meadows bloom in drifts
    const P = [], UV = [], I = []; const quad = (pts, uvs) => { const o = P.length / 3; P.push(...pts); UV.push(...uvs); I.push(o, o + 1, o + 2, o, o + 2, o + 3); };
    quad([-0.006, 0, 0, 0.006, 0, 0, 0.006, 0.92, 0, -0.006, 0.92, 0], [0, 0, 0, 0, 0, 0, 0, 0]);
    for (const r of [0, Math.PI / 2]) { const c = Math.cos(r), s2 = Math.sin(r), w = 0.07; quad([-w * c, 0.86, -w * s2, w * c, 0.86, w * s2, w * c, 1.0, w * s2, -w * c, 1.0, -w * s2], [2, 0, 3, 0, 3, 1, 2, 1]); } // head uv.x in [2,3]
    const g = new THREE.InstancedBufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(UV, 2)); g.setIndex(I);
    g.setAttribute('normal', new THREE.Float32BufferAttribute(P.map((_, i) => i % 3 === 1 ? 1 : 0), 3));
    const off = new Float32Array(count * 4), col = new Float32Array(count * 3);
    const pal = [[1.0, 0.95, 0.82], [1.0, 0.78, 0.18], [0.62, 0.42, 0.85], [0.95, 0.45, 0.55], [1.0, 1.0, 1.0]];
    for (let i = 0; i < count; i++) { off.set([(rnd() - 0.5) * GW, (rnd() - 0.5) * GW, 0.32 + rnd() * 0.25, rnd() * TAU], i * 4); const c = pal[(rnd() * pal.length) | 0]; col.set(c, i * 3); }
    g.setAttribute('aOff', new THREE.InstancedBufferAttribute(off, 4)); g.setAttribute('aCol', new THREE.InstancedBufferAttribute(col, 3));
    g.instanceCount = count; g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7, side: THREE.DoubleSide });
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { uTime: U.time, uWind: U.wind, uFocus: U.focus, uSnow: U.snow, uAutumn: U.autumn, uDay: U.day });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', `#include <common>
        attribute vec4 aOff; attribute vec3 aCol; uniform float uTime, uWind, uSnow, uAutumn; uniform vec2 uFocus; varying vec3 vCol; varying vec2 vFU;` + NOISE2 + GLSL_TERRAIN)
        .replace('#include <beginnormal_vertex>', 'vec3 objectNormal = vec3(0.0, 1.0, 0.0);')
        .replace('#include <begin_vertex>', `
          vec2 q = uFocus + mod(aOff.xy - uFocus + ${(GW / 2).toFixed(1)}, ${GW.toFixed(1)}) - ${(GW / 2).toFixed(1)};
          float fd = length(q - uFocus);
          float ht = aOff.z * smoothstep(${(GW / 2).toFixed(1)}, ${(GW / 2 - 6).toFixed(1)}, fd);
          ht *= smoothstep(0.9, 2.0, trailDist(q)) * smoothstep(${(POND.r + 1.5).toFixed(1)}, ${(POND.r + 3.0).toFixed(1)}, pondD(q));
          ht *= 1.0 - forestD(q); ht *= 1.0 - smoothstep(100.0, 120.0, length(q));
          ht *= smoothstep(0.5, 0.68, vn2(q * 0.07 + aCol.rg * 7.0)) * (1.0 - uSnow) * (1.0 - 0.7 * uAutumn);
          float c = cos(aOff.w), s = sin(aOff.w); vec3 p = vec3(position.x * c - position.z * s, 0.0, position.x * s + position.z * c);
          float h = position.y;
          float wind = uWind * (0.3 * sin(uTime * 1.9 + q.x * 0.32 + q.y * 0.21) + 0.22);
          vec2 dq = q - uFocus; float pk = smoothstep(1.2, 0.25, length(dq));
          vec2 bend = (vec2(wind, wind * 0.3) + normalize(dq + 1e-4) * pk * 0.5) * h * h * ht;
          vec3 transformed = vec3(q.x, terrainH(q), q.y) + p * ht * 2.4 + vec3(bend.x, h * ht * (1.0 - 0.4 * pk), bend.y);
          vCol = aCol; vFU = uv;`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vCol; varying vec2 vFU; uniform float uDay;')
        .replace('#include <normal_fragment_begin>', 'float faceDirection = 1.0; vec3 normal = normalize(vNormal); vec3 nonPerturbedNormal = normal;')
        .replace('#include <color_fragment>', `#include <color_fragment>
          if (vFU.x > 1.5) { vec2 d = vec2(vFU.x - 2.5, vFU.y - 0.5); float a = atan(d.y, d.x), r = length(d);
            float petal = 0.32 + 0.16 * cos(a * 5.0); if (r > petal) discard;
            diffuseColor.rgb = mix(vec3(0.95, 0.75, 0.2), vCol, smoothstep(0.06, 0.1, r)) * 0.62 * (0.35 + 0.65 * uDay); }
          else diffuseColor.rgb = vec3(0.12, 0.2, 0.05);`);
    };
    const mesh = new THREE.Mesh(g, m); mesh.frustumCulled = false; mesh.receiveShadow = true; mesh.layers.set(1); return mesh;
  }
  const flowerMesh = LITE ? null : makeFlowers(QUALITY.flowers || 5000); if (flowerMesh) scene.add(flowerMesh);

  // ---- trees & props (leaf/needle cards with spherical normals, wood separate) ----
  const colorize = (g, hex, vary = 0) => { const c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { const v = 1 + (rnd() - 0.5) * vary * 0.3; a.set([c.r * v, c.g * v, c.b * v], i * 3); } g.setAttribute('color', new THREE.BufferAttribute(a, 3)); return g; };
  const jitter = (g, amt) => { const P = g.attributes.position; for (let i = 0; i < P.count; i++) P.setXYZ(i, P.getX(i) + (rnd() - 0.5) * amt, P.getY(i) + (rnd() - 0.5) * amt, P.getZ(i) + (rnd() - 0.5) * amt); return g; };
  function merge(list, keepNormals = false) {
    let n = 0; list.forEach(g => n += g.attributes.position.count);
    const P = new Float32Array(n * 3), C = new Float32Array(n * 3), N = new Float32Array(n * 3), UV = new Float32Array(n * 2), I = []; let o = 0;
    for (const g of list) { const cnt = g.attributes.position.count; P.set(g.attributes.position.array, o * 3); C.set(g.attributes.color.array, o * 3);
      if (g.attributes.normal) N.set(g.attributes.normal.array, o * 3); if (g.attributes.uv) UV.set(g.attributes.uv.array, o * 2);
      if (g.index) for (const k of g.index.array) I.push(k + o); else for (let k = 0; k < cnt; k++) I.push(k + o); o += cnt; }
    const out = new THREE.BufferGeometry(); out.setAttribute('position', new THREE.BufferAttribute(P, 3)); out.setAttribute('color', new THREE.BufferAttribute(C, 3)); out.setAttribute('uv', new THREE.BufferAttribute(UV, 2)); out.setIndex(I);
    if (keepNormals) out.setAttribute('normal', new THREE.BufferAttribute(N, 3)); else out.computeVertexNormals();
    out.computeBoundingSphere(); return out;
  }
  // procedural foliage textures
  function leafTex(kind) {
    const S = 256, c = document.createElement('canvas'); c.width = c.height = S; const x = c.getContext('2d');
    if (kind === 'leaf') {
      for (let i = 0; i < 70; i++) {
        const a = rnd() * TAU, r = Math.sqrt(rnd()) * S * 0.42, px = S / 2 + Math.cos(a) * r, py = S / 2 + Math.sin(a) * r;
        x.save(); x.translate(px, py); x.rotate(rnd() * TAU); const l = 14 + rnd() * 12, w = l * (0.42 + rnd() * 0.15);
        const g = 150 + rnd() * 80; x.fillStyle = `rgb(${g * 0.78 | 0},${g | 0},${g * 0.55 | 0})`;
        x.beginPath(); x.moveTo(0, -l); x.quadraticCurveTo(w, -l * 0.2, 0, l); x.quadraticCurveTo(-w, -l * 0.2, 0, -l); x.fill();
        x.strokeStyle = 'rgba(40,50,20,0.35)'; x.lineWidth = 1; x.beginPath(); x.moveTo(0, -l * 0.9); x.lineTo(0, l * 0.9); x.stroke(); x.restore();
      }
    } else {
      x.strokeStyle = 'rgb(110,96,70)'; x.lineWidth = 3; x.beginPath(); x.moveTo(6, S / 2); x.lineTo(S - 6, S / 2); x.stroke();
      for (let k = 0; k < 6; k++) { const t0 = 0.15 + k * 0.13, side = k % 2 ? 1 : -1; x.lineWidth = 1.6; x.beginPath(); x.moveTo(t0 * S, S / 2); x.lineTo((t0 + 0.12) * S, S / 2 + side * S * 0.3); x.stroke(); }
      for (let i = 0; i < 520; i++) { const t = 0.03 + rnd() * 0.95, px = t * S, side = rnd() < 0.5 ? -1 : 1, len = (1 - t * 0.6) * (S * 0.36) * (0.5 + rnd() * 0.5), g = 130 + rnd() * 100;
        x.strokeStyle = `rgb(${g * 0.62 | 0},${g | 0},${g * 0.6 | 0})`; x.lineWidth = 1.1; x.beginPath(); x.moveTo(px, S / 2); x.lineTo(px + len * 0.45, S / 2 + side * len); x.stroke(); }
    }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
  }
  const texLeaf = leafTex('leaf'), texNeedle = leafTex('needle');
  function card(w, h, center, normalFrom) { const g = new THREE.PlaneGeometry(w, h); return { g, center, normalFrom }; }
  function cardsToGeo(cards) { // each card: transformed plane; normals = direction from canopy center (soft, volumetric shading)
    const list = cards.map(({ g, color, nc }) => { const P = g.attributes.position, N = g.attributes.normal, v = new THREE.Vector3();
      for (let i = 0; i < P.count; i++) { v.fromBufferAttribute(P, i).sub(nc).normalize(); v.y = v.y * 0.7 + 0.3; v.normalize(); N.setXYZ(i, v.x, v.y, v.z); }
      return colorize(g, color, 0.5); });
    return merge(list, true);
  }
  function hardwood(autumn) {
    const wood = [colorize(new THREE.CylinderGeometry(0.15, 0.32, 4.6, 9).translate(0, 2.3, 0), 0x4a3a2c, 0.2)];
    const crown = new THREE.Vector3(0, 6.4, 0), cards = [];
    for (let b = 0; b < 5; b++) { const br = new THREE.CylinderGeometry(0.04, 0.1, 2.6, 5).translate(0, 1.3, 0); br.rotateZ(0.55 + rnd() * 0.35); br.rotateY(b * 1.26 + rnd() * 0.5); br.translate(0, 3.4 + b * 0.35, 0); wood.push(colorize(br, 0x4a3a2c, 0.2)); }
    const pal = autumn ? [0xe0a040, 0xd77a2a, 0xc9b24a, 0xb5562a] : [0x8fb05a, 0x7da24e, 0xa2b862, 0x6f9446];
    for (let i = 0; i < 120; i++) {
      const u = rnd(), a = rnd() * TAU, r = Math.pow(rnd(), 0.5) * 2.9, y = 4.6 + rnd() * 3.6 - Math.max(0, r - 2.2) * 0.8;
      const p = new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r);
      const g = new THREE.PlaneGeometry(1.5 + rnd() * 0.8, 1.5 + rnd() * 0.8); g.rotateX(rnd() * TAU); g.rotateY(rnd() * TAU); g.rotateZ(rnd() * 0.8); g.translate(p.x, p.y, p.z);
      cards.push({ g, color: pal[(rnd() * 4) | 0], nc: crown });
    }
    return { wood: merge(wood), leaf: cardsToGeo(cards), tex: texLeaf };
  }
  function pine() {
    const wood = [colorize(new THREE.CylinderGeometry(0.07, 0.26, 10.5, 8).translate(0, 5.25, 0), 0x3e2e22, 0.2)];
    const cards = [], axis = new THREE.Vector3(0, 6, 0);
    const tiers = LITE ? 13 : 19;
    for (let t = 0; t < tiers; t++) {
      const u = t / tiers, y = 1.6 + u * 8.8, R = 2.4 * (1 - u) + 0.3, n = Math.max(5, Math.round(12 * (1 - u) + 4));
      for (let k = 0; k < n; k++) {
        const a = (k / n) * TAU + t * 0.7 + rnd() * 0.4, rr = R * (0.75 + rnd() * 0.35);
        for (const roll of [0.25, Math.PI / 2 + 0.25]) {
          const g = new THREE.PlaneGeometry(rr * 1.05, 0.55 + (1 - u) * 0.35); g.rotateX(roll); g.translate(rr * 0.52, 0, 0); g.rotateZ(-0.3 - rnd() * 0.3 - u * 0.2); g.rotateY(a); g.translate(0, y + (rnd() - 0.5) * 0.3, 0);
          const tone = rnd(); cards.push({ g, color: u < 0.25 ? (tone < 0.5 ? 0x6f8f56 : 0x7a9a5e) : tone < 0.4 ? 0x86a868 : tone < 0.8 ? 0x95b672 : 0xa4be7c, nc: new THREE.Vector3(0, y + 0.8, 0) });
        }
      }
    }
    return { wood: merge(wood), leaf: cardsToGeo(cards), tex: texNeedle };
  }
  function shrub() {
    const cards = [], c0 = new THREE.Vector3(0, 0.3, 0);
    for (let i = 0; i < 26; i++) { const g = new THREE.PlaneGeometry(0.8, 0.8); g.rotateX(rnd() * TAU); g.rotateY(rnd() * TAU); g.translate((rnd() - 0.5) * 1.1, 0.25 + rnd() * 0.6, (rnd() - 0.5) * 1.1); cards.push({ g, color: rnd() < 0.5 ? 0x7d9a4c : 0x93a85a, nc: c0 }); }
    return { wood: null, leaf: cardsToGeo(cards), tex: texLeaf };
  }
  function fern() { // arched fronds radiating from a crown: forest-floor undergrowth
    const cards = [], c0 = new THREE.Vector3(0, 0.15, 0), n = 9 + ((rnd() * 4) | 0);
    for (let i = 0; i < n; i++) { const g = new THREE.PlaneGeometry(1.0, 0.34, 6, 1); g.translate(0.5, 0, 0); const P = g.attributes.position;
      const arch = 0.55 + rnd() * 0.35; for (let k = 0; k < P.count; k++) { const x = P.getX(k); P.setY(k, P.getY(k) * (1 - x * 0.6) * 0.0 + x * arch - x * x * (arch * 0.95)); P.setZ(k, P.getY(k) === 0 ? 0 : 0); }
      // the plane's v-axis becomes the frond width (z)
      const P2 = g.attributes.position, uvs = g.attributes.uv; for (let k = 0; k < P2.count; k++) { const w = (uvs.getY(k) - 0.5) * 0.34 * (1 - P2.getX(k) * 0.7); P2.setZ(k, w); }
      g.rotateZ(0.15 + rnd() * 0.2); g.rotateY(i / n * TAU + rnd() * 0.4); g.translate(0, 0.05, 0);
      { const uv = g.attributes.uv; for (let q2 = 0; q2 < uv.count; q2++) { const u0 = uv.getX(q2), v0 = uv.getY(q2); uv.setXY(q2, v0, u0); } }
      cards.push({ g, color: rnd() < 0.5 ? 0xb8c4a0 : 0xd0d8b8, nc: c0 }); }
    return { wood: null, leaf: cardsToGeo(cards), tex: texNeedle };
  }
  function rockGeo() { const g = new THREE.IcosahedronGeometry(1, 3), P = g.attributes.position; const v = new THREE.Vector3(), ph = rnd() * 10;
    for (let k = 0; k < P.count; k++) { v.fromBufferAttribute(P, k); const s = 0.82 + 0.18 * Math.sin(v.x * 3.1 + ph) * Math.cos(v.z * 2.7) + 0.06 * Math.sin(v.x * 9 + v.y * 7 + ph); P.setXYZ(k, v.x * s, v.y * s * 0.58, v.z * s); }
    const ng = new THREE.BufferGeometry(); ng.setAttribute('position', P); const idx = []; for (let i = 0; i < P.count; i++) idx.push(i); // icosahedron is non-indexed; weld for smooth shading
    return { wood: mergeWeld(colorize(g, 0x7a766c, 0.4)), leaf: null };
  }
  function mergeWeld(g) { const pos = g.attributes.position, col = g.attributes.color, map = new Map(), P = [], C = [], I = [];
    for (let i = 0; i < pos.count; i++) { const k = [pos.getX(i), pos.getY(i), pos.getZ(i)].map(v => v.toFixed(3)).join(','); let j = map.get(k); if (j === undefined) { j = P.length / 3; map.set(k, j); P.push(pos.getX(i), pos.getY(i), pos.getZ(i)); C.push(col.getX(i), col.getY(i), col.getZ(i)); } I.push(j); }
    const o = new THREE.BufferGeometry(); o.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); o.setAttribute('color', new THREE.Float32BufferAttribute(C, 3)); o.setAttribute('uv', new THREE.Float32BufferAttribute(new Array(P.length / 3 * 2).fill(0), 2)); o.setIndex(I); o.computeVertexNormals(); o.computeBoundingSphere(); return o; }
  // ---- forest floor props: photo bark, moss on the up-facing side, growth rings, mushrooms, sticks, leaf litter ----
  const barkMat = (() => {
    const m = new THREE.MeshStandardMaterial({ vertexColors: true, map: TX.b_oak_color, normalMap: TX.b_oak_normal, roughnessMap: TX.b_oak_roughness, roughness: 1 });
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { tMoss: { value: TX.grass }, uWet: U.wet, uSnow: U.snow });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vBW; varying vec3 vBN;')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          { vec4 wp = vec4(transformed, 1.0); vec3 wn = objectNormal;
            #ifdef USE_INSTANCING
              wp = instanceMatrix * wp; wn = mat3(instanceMatrix) * wn;
            #endif
            vBW = (modelMatrix * wp).xyz; vBN = normalize(mat3(modelMatrix) * wn); }`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform sampler2D tMoss; uniform float uWet, uSnow; varying vec3 vBW; varying vec3 vBN; float gMossB;')
        .replace('#include <map_fragment>', `#include <map_fragment>
          { float n = fract(sin(dot(floor(vBW * 3.0), vec3(12.9, 78.2, 37.7))) * 43758.5);
            gMossB = smoothstep(0.25, 0.75, normalize(vBN).y + (n - 0.5) * 0.5) * 0.9;
            diffuseColor.rgb = mix(diffuseColor.rgb * 0.85, texture2D(tMoss, vBW.xz * 0.9).rgb * vec3(0.6, 0.78, 0.4), gMossB);
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.72, 0.75, 0.8), uSnow * smoothstep(0.5, 0.9, vBN.y)) * (1.0 - 0.3 * uWet); }`)
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(roughnessFactor, 0.95, gMossB);');
    };
    m.userData.env = 0.12; return m;
  })();
  const ringMat = (() => { // stump tops: rings + radial cracks
    const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
    x.fillStyle = '#b08a5e'; x.fillRect(0, 0, 256, 256);
    for (let r = 120; r > 4; r -= 3 + rnd() * 4) { x.strokeStyle = `rgba(90,58,30,${0.25 + rnd() * 0.35})`; x.lineWidth = 1 + rnd() * 1.6; x.beginPath(); x.ellipse(128 + (rnd() - 0.5) * 3, 128 + (rnd() - 0.5) * 3, r, r * (0.95 + rnd() * 0.08), 0, 0, TAU); x.stroke(); }
    for (let i = 0; i < 6; i++) { const a = rnd() * TAU; x.strokeStyle = 'rgba(40,26,14,0.6)'; x.lineWidth = 1.5; x.beginPath(); x.moveTo(128 + Math.cos(a) * 30, 128 + Math.sin(a) * 30); x.lineTo(128 + Math.cos(a) * 118, 128 + Math.sin(a) * 118); x.stroke(); }
    const g = x.createRadialGradient(128, 128, 100, 128, 128, 128); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(50,32,18,0.9)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
    return new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, vertexColors: true });
  })();
  function barkCyl(r0, r1, len, seg, uvLen) { // rough trunk section: noisy radius, UVs scaled so bark isn't stretched
    const g = new THREE.CylinderGeometry(r1, r0, len, seg, 8, true), P = g.attributes.position, UV = g.attributes.uv;
    for (let i = 0; i < P.count; i++) { const x = P.getX(i), y = P.getY(i), z = P.getZ(i), a = Math.atan2(z, x), k = 1 + 0.08 * Math.sin(a * 5 + y * 3.1) + 0.05 * Math.sin(a * 11 - y * 7.3); P.setXYZ(i, x * k, y, z * k); UV.setXY(i, UV.getX(i) * Math.max(1, Math.round(r0 * 9)), UV.getY(i) * uvLen); }
    g.computeVertexNormals(); return colorize(g, 0xffffff, 0.2);
  }
  function logGeo() {
    const parts = [barkCyl(0.27, 0.22, 4.4, 16, 3).rotateZ(Math.PI / 2).translate(0, 0.2, 0)];
    for (const [x, a, l] of [[0.9, 0.6, 0.55], [-0.7, -0.9, 0.4], [1.6, 2.4, 0.35]]) { const b = barkCyl(0.07, 0.04, l, 7, 1); b.translate(0, l / 2, 0); b.rotateX(a); b.translate(x, 0.2, 0); parts.push(b); }
    const ends = []; for (const s of [1, -1]) { const e = new THREE.CircleGeometry(0.235, 16); e.rotateY(s * Math.PI / 2); e.translate(s * 2.2, 0.2, 0); ends.push(colorize(e, 0xffffff, 0.1)); }
    return { wood: merge(parts), leaf: merge(ends), mat: barkMat, mat2: ringMat };
  }
  function stumpGeo() {
    const top = new THREE.CircleGeometry(0.4, 18); top.rotateX(-Math.PI / 2); top.translate(0, 0.42, 0);
    const roots = []; for (let i = 0; i < 5; i++) { const a = i / 5 * TAU + rnd() * 0.4, rt = barkCyl(0.1, 0.03, 0.55, 7, 1); rt.translate(0, 0.27, 0); rt.rotateZ(1.15); rt.rotateY(a); rt.translate(Math.cos(a) * 0.3, 0.05, -Math.sin(a) * 0.3); roots.push(rt); }
    return { wood: merge([barkCyl(0.47, 0.4, 0.45, 18, 0.6).translate(0, 0.2, 0), ...roots]), leaf: merge([colorize(top, 0xffffff, 0.1)]), mat: barkMat, mat2: ringMat };
  }
  function mushroomGeo() {
    const parts = [], n = 3 + (rnd() * 5 | 0), cap = rnd() < 0.5 ? 0x8a4a28 : rnd() < 0.5 ? 0xc9a46a : 0xa8321e;
    for (let i = 0; i < n; i++) { const x = (rnd() - 0.5) * 0.3, z = (rnd() - 0.5) * 0.3, h = 0.05 + rnd() * 0.08, r = 0.025 + rnd() * 0.035;
      parts.push(colorize(new THREE.CylinderGeometry(r * 0.32, r * 0.42, h, 7).translate(x, h / 2, z), 0xe6dcc6, 0.2));
      const c = new THREE.SphereGeometry(r, 10, 6, 0, TAU, 0, Math.PI / 2); c.scale(1, 0.62, 1); c.translate(x, h, z); parts.push(colorize(c, cap, 0.35));
      const g = new THREE.CircleGeometry(r * 0.98, 10); g.rotateX(Math.PI / 2); g.translate(x, h + 0.001, z); parts.push(colorize(g, 0xd9c7a4, 0.2)); }
    return { wood: merge(parts), leaf: null };
  }
  function sticksGeo() {
    const parts = []; for (let i = 0; i < 6; i++) { const l = 0.35 + rnd() * 0.7, st = new THREE.CylinderGeometry(0.012, 0.02, l, 5); st.rotateZ(Math.PI / 2 + (rnd() - 0.5) * 0.3); st.rotateY(rnd() * TAU); st.translate((rnd() - 0.5) * 0.8, 0.02, (rnd() - 0.5) * 0.8); parts.push(colorize(st, rnd() < 0.5 ? 0x4a3a2a : 0x6a5640, 0.3)); }
    return { wood: merge(parts), leaf: null };
  }
  function litterGeo() { // fallen leaves: flat cards in browns and ambers, using the oak leaf photo
    const parts = []; for (let i = 0; i < 9; i++) { const p = new THREE.PlaneGeometry(0.7 + rnd() * 0.6, 0.7 + rnd() * 0.6); p.rotateX(-Math.PI / 2); p.rotateY(rnd() * TAU); p.translate((rnd() - 0.5) * 1.6, 0.015 + i * 0.002, (rnd() - 0.5) * 1.6);
      parts.push(colorize(p, [0x8a5a2a, 0x9a7a3a, 0x6a4a28, 0xa86a2a][i % 4], 0.4)); }
    return { wood: null, leaf: merge(parts), tex: TX.l_oak };
  }
  function reedGeo() { const parts = []; for (let i = 0; i < 11; i++) { const h = 1.2 + rnd() * 0.6, x = (rnd() - 0.5) * 0.5, z = (rnd() - 0.5) * 0.5, lean = (rnd() - 0.5) * 0.2; const st = new THREE.CylinderGeometry(0.006, 0.014, h, 5).translate(0, h / 2, 0); st.rotateZ(lean); st.translate(x, 0, z); parts.push(colorize(st, rnd() < 0.5 ? 0x7d8a44 : 0x8f9a52, 0.3)); if (rnd() < 0.55) { const hd = new THREE.CylinderGeometry(0.022, 0.022, 0.16, 7).translate(0, h - 0.12, 0); hd.rotateZ(lean); hd.translate(x, 0, z); parts.push(colorize(hd, 0x5a3a22, 0.2)); } } return { wood: merge(parts), leaf: null }; }
  function berryGeo() { const b = shrub(); const parts = []; for (let i = 0; i < 26; i++) parts.push(colorize(new THREE.SphereGeometry(0.045, 6, 4).translate((rnd() - 0.5) * 1.0, 0.35 + rnd() * 0.5, (rnd() - 0.5) * 1.0), rnd() < 0.5 ? 0x5a1a4a : 0x2a2a6a, 0.3)); return { wood: merge(parts), leaf: b.leaf, tex: texLeaf }; }

  const windChunk = (strength) => `#include <begin_vertex>
      float sw = max(position.y - 2.0, 0.0); float ph = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.21;
      transformed.x += sw * sw * ${strength} * uWind * sin(uTime * 1.3 + ph); transformed.z += sw * sw * ${strength * 0.7} * uWind * sin(uTime * 1.7 + ph * 1.3);
      transformed += normal * 0.04 * uWind * sin(uTime * 4.0 + position.x * 3.0 + position.y * 2.0 + ph) * step(0.5, uLeaf);`;
  function foliageMat(tex) { // eslint-disable-line
    const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.88, map: tex || null, alphaTest: tex ? 0.42 : 0, side: tex ? THREE.DoubleSide : THREE.FrontSide, alphaToCoverage: !!tex && !!QUALITY.a2c });
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { uTime: U.time, uWind: U.wind, uLeaf: { value: tex ? 1 : 0 }, uSunV: U.sunV, uSunCol: U.sunCol, uDay: U.day, uSnow: U.snow, uAutumn: { value: 0 }, uNeedle: { value: tex === texNeedle ? 1 : 0 } });
      m.userData.sh = sh;
      Object.assign(sh.uniforms, { uWet: U.wet });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime, uWind, uLeaf; varying vec3 vLP;').replace('#include <begin_vertex>', windChunk(0.006) + '\n vLP = position;');
      if (!tex) sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vLP; uniform float uWet;' + NOISE2)
        .replace('#include <color_fragment>', '#include <color_fragment>\n { float ang = atan(vLP.z, vLP.x); float bark = vn2(vec2(ang * 5.0, vLP.y * 2.2)) * 0.6 + vn2(vec2(ang * 14.0, vLP.y * 7.0)) * 0.4; diffuseColor.rgb *= 0.72 + 0.5 * bark; diffuseColor.rgb *= 1.0 - 0.3 * uWet; }')
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(roughnessFactor, 0.45, uWet * 0.7);');
      if (tex) sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 uSunV, uSunCol; uniform float uDay, uSnow, uAutumn, uNeedle;')
        .replace('#include <color_fragment>', '#include <color_fragment>\n { float lum = dot(diffuseColor.rgb, vec3(0.3, 0.59, 0.11)); vec3 aut = mix(vec3(0.95, 0.38, 0.07), vec3(0.92, 0.68, 0.12), fract(vColor.r * 17.0 + vColor.g * 5.0)) * lum * 2.1; diffuseColor.rgb = mix(diffuseColor.rgb, aut, uAutumn * (1.0 - uNeedle)); } diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.62, 0.65, 0.7), uSnow * 0.55 * smoothstep(0.1, 0.7, vNormal.y + 0.3));')
        .replace('#include <normal_fragment_begin>', 'float faceDirection = 1.0; vec3 normal = normalize(vNormal); vec3 nonPerturbedNormal = normal;')
        .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n float back = pow(max(dot(normalize(-vViewPosition), uSunV), 0.0), 4.0); totalEmissiveRadiance += uSunCol * back * 0.35 * diffuseColor.rgb * uDay + diffuseColor.rgb * (0.03 + 0.11 * uDay);');
    };
    m.userData.env = 0.04;
    return m;
  }
  function depthMat(tex) {
    const d = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: tex, alphaTest: 0.42 });
    return d;
  }
  function rockDetail(m) {
    m.onBeforeCompile = sh => {
      Object.assign(sh.uniforms, { tDet: { value: TX.rock }, tDetN: { value: TX.rockN }, tMoss: { value: TX.grass }, uSnow: U.snow, uWet: U.wet });
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vRW; varying vec3 vRN;')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          { vec4 wp = vec4(transformed, 1.0); vec3 wn = objectNormal;
            #ifdef USE_INSTANCING
              wp = instanceMatrix * wp; wn = mat3(instanceMatrix) * wn;
            #endif
            vRW = (modelMatrix * wp).xyz; vRN = normalize(mat3(modelMatrix) * wn); }`);
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform sampler2D tDet, tDetN, tMoss; uniform float uSnow, uWet; varying vec3 vRW; varying vec3 vRN; float gMoss, gSnowR;' + GLSL_TERRAIN + `
          vec3 tri(sampler2D t, vec3 p, vec3 w){ return texture2D(t, p.zy).rgb * w.x + texture2D(t, p.xz).rgb * w.y + texture2D(t, p.xy).rgb * w.z; }`)
        .replace('#include <map_fragment>', `#include <map_fragment>
          { vec3 N = normalize(vRN), w = pow(abs(N), vec3(4.0)); w /= dot(w, vec3(1.0));
            float near = 1.0 - smoothstep(8.0, 40.0, length(vViewPosition));
            vec3 d = tri(tDet, vRW * 1.7, w); float dl = dot(d, vec3(0.3, 0.59, 0.11)) / 0.36;
            diffuseColor.rgb *= mix(1.0, clamp(dl, 0.5, 1.7), 0.5 * near);
            float n = dot(tri(tDet, vRW * 0.45, w), vec3(0.33));
            gMoss = smoothstep(0.5, 0.85, N.y + (n - 0.45) * 0.9) * 0.85;
            vec3 moss = texture2D(tMoss, vRW.xz * 0.6).rgb * vec3(0.62, 0.78, 0.42);
            diffuseColor.rgb = mix(diffuseColor.rgb, moss, gMoss);
            float ao = mix(0.62, 1.0, smoothstep(0.0, 0.45, vRW.y - terrainH(vRW.xz)));
            diffuseColor.rgb *= ao * (1.0 - 0.35 * uWet);
            gSnowR = uSnow * smoothstep(0.45, 0.8, N.y + (n - 0.45) * 0.5);
            diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.72, 0.75, 0.8), gSnowR); }`)
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(mix(roughnessFactor, 0.95, gMoss), 0.35, uWet * (1.0 - gMoss));')
        .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
          { vec3 N = normalize(vRN), w = pow(abs(N), vec3(4.0)); w /= dot(w, vec3(1.0));
            vec3 nd = tri(tDetN, vRW * 1.7, w) * 2.0 - 1.0; float near = 1.0 - smoothstep(8.0, 40.0, length(vViewPosition));
            normal = normalize(normal + vec3(nd.xy, 0.0) * 0.55 * near * (1.0 - gSnowR)); }`);
    };
  }
  // scanned rocks (ez-tree demo, MIT): centered, unit-sized, sunk a little into the ground
  const rockV = ASSETS.rocks.map(mesh => { const g = mesh.geometry.clone(); g.computeBoundingBox(); const bb = g.boundingBox, c = bb.getCenter(new THREE.Vector3()), sz = bb.getSize(new THREE.Vector3());
    const k = 2 / Math.max(sz.x, sz.z); g.translate(-c.x, -bb.min.y - sz.y * 0.18, -c.z); g.scale(k, k, k); g.computeBoundingSphere();
    const m = mesh.material.clone(); m.side = THREE.FrontSide; m.userData.env = 0.5; if (!g.attributes.color) m.vertexColors = false; rockDetail(m); return { wood: g, mat: m }; });
  function pebbleGeo(g0) { // the rock shape with fewer triangles, flattened like a stream stone
    let out;
    try { out = SIMPLIFY.modify(g0.clone(), Math.floor(g0.attributes.position.count * 0.7)); } catch (e) { out = g0.clone(); }
    out.scale(0.5, 0.35, 0.5); out.computeBoundingSphere(); return out;
  }
  const berryDots = (() => { const parts = []; for (let i = 0; i < 30; i++) parts.push(colorize(new THREE.SphereGeometry(0.03, 6, 4).translate((rnd() - 0.5) * 1.1, 0.3 + rnd() * 0.75, (rnd() - 0.5) * 1.1), rnd() < 0.5 ? 0x5a1a4a : 0x2a2a6a, 0.3)); return { wood: merge(parts), leaf: null }; })();
  const VARIANTS = { stump: [stumpGeo()], mushroom: [mushroomGeo(), mushroomGeo(), mushroomGeo()], sticks: [sticksGeo()], litter: [litterGeo()], berry: [berryDots], rock: rockV, log: [logGeo()], reed: [reedGeo()], fern: [fern(), fern(), fern()], pebble: rockV.map(r => ({ wood: pebbleGeo(r.wood), mat: r.mat })) };
  const forest = createForest(scene, renderer, ASSETS, U, { LITE, QUALITY });
  const FOREST_KINDS = { pine: 1, hard: 1, shrub: 1, berry: 1 };
  const MAT = { wood: foliageMat(null), leaf: foliageMat(texLeaf), needle: foliageMat(texNeedle), fern: foliageMat(TX.l_ash), litter: foliageMat(TX.l_oak), rock: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9 }) };
  MAT.rock.userData.env = 0.08;
  const DEPTH = { leaf: depthMat(texLeaf), needle: depthMat(texNeedle) };
  let api_ao = null;
  const CH = 50, chunks = new Map(), trees = [], props = []; // props: every placed object (for gathering/chopping)
  function put(kind, vi, x, z, s, r, collide) {
    const ck = Math.floor(x / CH) + ',' + Math.floor(z / CH), k = ck + ':' + kind + vi;
    const item = { kind, vi, x, y: terrainH(x, z) - 0.05, z, s, r, alive: true, collide: collide * s };
    if (FOREST_KINDS[kind]) forest.add(item);
    if (kind !== 'pine' && kind !== 'hard' && kind !== 'shrub') { const c = chunks.get(k) || (chunks.set(k, { kind, vi, items: [], cx: (Math.floor(x / CH) + 0.5) * CH, cz: (Math.floor(z / CH) + 0.5) * CH }), chunks.get(k)); item.chunk = c; item.idx = c.items.length; c.items.push(item); }
    props.push(item);
    if (collide) trees.push(item);
    return item;
  }
  const SPACE = QUALITY.treeSpace;
  for (let gx = -205; gx <= 205; gx += SPACE) for (let gz = -205; gz <= 205; gz += SPACE) {
    const x = gx + (rnd() - 0.5) * SPACE * 0.9, z = gz + (rnd() - 0.5) * SPACE * 0.9, r = Math.hypot(x, z);
    if (r > 215) continue;
    const f = forestD(x, z);
    if (trailDist(x, z) < 3.5 || pondD(x, z) < POND.r + 5) continue;
    if (rnd() < f * 0.88 || rnd() < 0.006) {
      const isPine = rnd() < 0.55 + 0.25 * sstep(100, 160, r);
      put(isPine ? 'pine' : 'hard', (rnd() * 3) | 0, x, z, 0.75 + rnd() * 0.6, rnd() * TAU, 0.45);
    } else if (rnd() < 0.05 + f * 0.1) put(rnd() < 0.35 ? 'berry' : 'shrub', (rnd() * 2) | 0, x, z, 0.7 + rnd() * 0.9, rnd() * TAU, 0);
    if (rnd() < 0.02) put('rock', (rnd() * 2) | 0, x + 2, z - 1, 0.3 + rnd() * 1.1, rnd() * TAU, 0.8);
    if (f > 0.6 && rnd() < 0.03) put('log', 0, x + 1.5, z + 1.5, 0.8 + rnd() * 0.5, rnd() * TAU, 0);
    if (f > 0.4 && rnd() < 0.018) put('stump', 0, x - 1.2, z + 0.8, 0.7 + rnd() * 0.6, rnd() * TAU, 0.35);
    if (!LITE && f > 0.3) { const D = LITE ? 0.4 : 1;
      if (rnd() < 0.05 * D) put('mushroom', (rnd() * 3) | 0, x + (rnd() - 0.5) * 2, z + (rnd() - 0.5) * 2, 0.8 + rnd() * 0.7, rnd() * TAU, 0);
      if (rnd() < 0.07 * D) put('sticks', 0, x + (rnd() - 0.5) * SPACE, z + (rnd() - 0.5) * SPACE, 0.8 + rnd() * 0.5, rnd() * TAU, 0);
      if (rnd() < 0.16 * f * D) { const lx = x + (rnd() - 0.5) * SPACE, lz = z + (rnd() - 0.5) * SPACE; if (trailDist(lx, lz) > 1.5) put('litter', 0, lx, lz, 0.9 + rnd() * 0.8, rnd() * TAU, 0); } }
    if (!LITE) for (let k = 0; k < 3; k++) if (f > 0.25 && rnd() < f * 0.55) { const fx = x + (rnd() - 0.5) * SPACE, fz = z + (rnd() - 0.5) * SPACE; if (trailDist(fx, fz) > 2.2) put('fern', (rnd() * 3) | 0, fx, fz, 0.6 + rnd() * 0.7, rnd() * TAU, 0); }
  }
  for (let i = 0; i < (LITE ? 120 : 420); i++) { const s0 = rnd() * TAU, pt = trailPoint(s0), side = (rnd() - 0.5) * 3.2; const x = pt.x + Math.cos(s0) * side, z = pt.z + Math.sin(s0) * side; put('pebble', (rnd() * 3) | 0, x, z, 0.05 + rnd() * rnd() * 0.22, rnd() * TAU, 0); }
  for (let i = 0; i < 46; i++) { const a = rnd() * TAU, d = POND.r + 0.3 + rnd() * 1.8; put('reed', 0, POND.x + Math.cos(a) * d, POND.z + Math.sin(a) * d, 0.8 + rnd() * 0.5, rnd() * TAU, 0); }
  for (let i = 0; i < 14; i++) { const a = rnd() * TAU, d = 12 + rnd() * 38; const x = Math.cos(a) * d, z = Math.sin(a) * d; if (trailDist(x, z) > 3 && pondD(x, z) > POND.r + 4) put('rock', (rnd() * 2) | 0, x, z, 0.4 + rnd() * 0.9, rnd() * TAU, 0.9); }
  for (let i = 0; i < 18; i++) { const a = rnd() * TAU, d = 40 + rnd() * 30; const x = Math.cos(a) * d, z = Math.sin(a) * d; if (trailDist(x, z) > 3 && pondD(x, z) > POND.r + 4) put('berry', 0, x, z, 0.8 + rnd() * 0.5, rnd() * TAU, 0); }
  { // bake the contact-shadow map: radial falloffs under each object, darker at the trunk, a faint pool under the canopy
    const N = LITE ? 512 : 1024, cv = document.createElement('canvas'); cv.width = cv.height = N; const g2 = cv.getContext('2d'); g2.fillStyle = '#fff'; g2.fillRect(0, 0, N, N);
    const px = v => (v / AO_W + 0.5) * N, k = N / AO_W;
    const blob = (x, z, r, a) => { const X = px(x), Z = px(z), R = Math.max(1.5, r * k), gr = g2.createRadialGradient(X, Z, 0, X, Z, R); gr.addColorStop(0, `rgba(0,0,0,${a})`); gr.addColorStop(0.55, `rgba(0,0,0,${a * 0.45})`); gr.addColorStop(1, 'rgba(0,0,0,0)'); g2.fillStyle = gr; g2.fillRect(X - R, Z - R, R * 2, R * 2); };
    for (const p of props) {
      if (p.kind === 'pine' || p.kind === 'hard') { blob(p.x, p.z, 3.8 * p.s, 0.2); blob(p.x, p.z, 0.8 * p.s + 0.55, 0.5); }
      else if (p.kind === 'rock') blob(p.x, p.z, 1.25 * p.s + 0.35, 0.55);
      else if (p.kind === 'log' || p.kind === 'stump') blob(p.x, p.z, 1.0 * p.s + 0.3, 0.45);
      else if (p.kind === 'shrub' || p.kind === 'berry') blob(p.x, p.z, 1.05 * p.s, 0.32);
    }
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.NoColorSpace; t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter; t.magFilter = THREE.LinearFilter; t.flipY = false; tAO.value = t;
    api_ao = { canvas: cv, blob, tex: t, px };
  }
  const chunkMeshes = [];
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), sv = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0), pv = new THREE.Vector3();
  function itemMatrix(it) { return m4.compose(pv.set(it.x, it.y, it.z), q.setFromAxisAngle(up, it.r), sv.setScalar(it.alive ? it.s : 0)); }
  for (const c of chunks.values()) {
    const V = VARIANTS[c.kind][c.vi % VARIANTS[c.kind].length]; c.meshes = [];
    for (const part of ['wood', 'leaf']) {
      const geo = V[part]; if (!geo) continue;
      const mat = part === 'wood' ? (V.mat || (c.kind === 'rock' || c.kind === 'pebble' ? MAT.rock : MAT.wood)) : (V.mat2 || (c.kind === 'fern' ? MAT.fern : c.kind === 'litter' ? MAT.litter : V.tex === texNeedle ? MAT.needle : MAT.leaf));
      const im = new THREE.InstancedMesh(geo, mat, c.items.length);
      if (part === 'leaf' && !V.mat2) im.customDepthMaterial = V.tex === texNeedle ? DEPTH.needle : DEPTH.leaf;
      c.items.forEach((it, i) => im.setMatrixAt(i, itemMatrix(it)));
      im.castShadow = !['reed', 'pebble', 'fern', 'litter', 'sticks', 'mushroom'].includes(c.kind); im.receiveShadow = c.kind === 'fern' || !(part === 'leaf' && V.tex === texNeedle); im.computeBoundingSphere();
      scene.add(im); c.meshes.push(im); chunkMeshes.push({ im, cx: c.cx, cz: c.cz, near: c.kind === 'pebble' || c.kind === 'fern' || c.kind === 'mushroom' || c.kind === 'sticks' || c.kind === 'litter' });
    }
  }
  forest.build();
  function refreshItem(it) { if (it.tv !== undefined) forest.refresh(); if (it.chunk) for (const im of it.chunk.meshes) { im.setMatrixAt(it.idx, itemMatrix(it)); im.instanceMatrix.needsUpdate = true; } }
  const treeGrid = new Map();
  for (const t of trees) { const k = Math.floor(t.x / 10) + ',' + Math.floor(t.z / 10); if (!treeGrid.has(k)) treeGrid.set(k, []); treeGrid.get(k).push(t); }
  function nearTrees(x, z) { const out = [], gx = Math.floor(x / 10), gz = Math.floor(z / 10); for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { const a = treeGrid.get((gx + i) + ',' + (gz + j)); if (a) for (const t of a) if (t.alive) out.push({ x: t.x, z: t.z, r: t.collide }); } return out; }
  const propGrid = new Map();
  for (const p of props) { const k = Math.floor(p.x / 10) + ',' + Math.floor(p.z / 10); if (!propGrid.has(k)) propGrid.set(k, []); propGrid.get(k).push(p); }
  function nearProps(x, z, R = 3) { const out = [], gx = Math.floor(x / 10), gz = Math.floor(z / 10); for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { const a = propGrid.get((gx + i) + ',' + (gz + j)); if (a) for (const p of a) if (p.alive && Math.hypot(p.x - x, p.z - z) < R + (p.kind === 'pine' || p.kind === 'hard' ? 0.6 : 0.5) * p.s) out.push(p); } return out; }

  // ---- motes: pollen by day, fireflies at night ----
  const MN = LITE ? 220 : 500, mG = new THREE.BufferGeometry(), mP = new Float32Array(MN * 3), mSeed = [];
  for (let i = 0; i < MN; i++) mSeed.push([(rnd() - 0.5) * 36, 0.2 + rnd() * 3, (rnd() - 0.5) * 36, rnd() * TAU, 0.5 + rnd()]);
  mG.setAttribute('position', new THREE.BufferAttribute(mP, 3));
  const mc = document.createElement('canvas'); mc.width = mc.height = 32; { const x = mc.getContext('2d'), gr = x.createRadialGradient(16, 16, 0, 16, 16, 16); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.fillRect(0, 0, 32, 32); }
  const mM = new THREE.PointsMaterial({ size: 0.03, map: new THREE.CanvasTexture(mc), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, color: 0xffd9a0, opacity: 0.8 });
  const motes = new THREE.Points(mG, mM); motes.frustumCulled = false; motes.layers.set(1); scene.add(motes);

  // ---- time of day + weather state (targets ease in over seconds; wetness soaks and dries slowly) ----
  const C = (h) => new THREE.Color(h);
  const cols = { zenDay: C(PAINT ? 0x2e6fd0 : 0x2a62c8), zenNight: C(0x0c1730), horDay: C(PAINT ? 0xb8e0f0 : 0xb4d2ee), horNight: C(0x1e2946), horWarm: C(0xffa25a), horDusk: C(0xd8708a), sunWarm: C(0xff9448), sunDay: C(0xfff0d8), moon: C(0x9fb6e8), fogNight: C(0x1a2236), storm: C(0x5f6872) };
  const tmpC = new THREE.Color();
  env.tgt = { cloud: env.cloud, rain: 0, snow: 0, mist: env.mist, fall: 0 }; env.fall = 0; env.wet = 0; env.flash = 0;
  let lastEnvK = -1, keyBase = 3, hemiBase = 0.8;
  function applyTime() {
    const h = env.hour, ang = (h - 5.5) / 13.5 * Math.PI, sE = Math.sin(ang) * 0.74;
    const elev = Math.asin(clamp(sE, -1, 1));
    sunDir.set(Math.cos(ang) * Math.cos(elev), Math.sin(elev), -0.62 * Math.cos(elev) - 0.2).normalize();
    const day = sstep(-0.06, 0.22, sE), night = 1 - sstep(-0.16, 0.0, sE), warm = (1 - sstep(0.1, 0.5, sE)) * sstep(-0.1, 0.05, sE), dusk = warm * (h > 12 ? 1 : 0.4) * (1 - sstep(0.0, 0.12, sE));
    const zen = skyU.uZen.value.copy(cols.zenNight).lerp(cols.zenDay, day);
    const hor = skyU.uHor.value.copy(cols.horNight).lerp(cols.horDay, day).lerp(cols.horWarm, warm * 0.85).lerp(cols.horDusk, dusk * 0.35);
    zen.lerp(tmpC.copy(cols.horWarm).multiplyScalar(0.6), warm * 0.1);
    const sunCol = skyU.uSunCol.value.copy(cols.sunDay).lerp(cols.sunWarm, warm);
    skyU.uDay.value = day; skyU.uNight.value = night;
    const isSun = sE > -0.02;
    const gloom = Math.max(env.rain, env.cloud * 0.45, env.snow * 0.5 * (env.fall > 0.1 ? 1 : 0.4));
    starM.uniforms.uOp.value = night * 0.95 * (1 - Math.min(1, env.cloud * 0.9 + env.rain));
    key.color.copy(isSun ? sunCol : cols.moon); key.intensity = isSun ? 3.4 * sstep(-0.02, 0.15, sE) : 1.2 * night;
    hemi.color.copy(zen).lerp(hor, 0.5); hemi.groundColor.set(0x4f5a2c).multiplyScalar(0.3 + 0.7 * day);
    hemi.intensity = (0.26 + 0.8 * day) * (PAINT ? 1.3 : 1); // lifted, sky-tinted shadows (painted lifts them further)
    if (night > 0.5) hemi.color.lerp(tmpC.set(0x5a6f9a), 0.5);
    fill.intensity = 0.48 * day; fill.color.copy(zen);
    key.intensity *= 1 - 0.72 * gloom; hemi.intensity *= 1 - 0.2 * gloom;
    const gray = tmpC.copy(cols.storm).multiplyScalar(0.22 + 0.78 * day);
    hor.lerp(gray, gloom * 0.7); zen.lerp(gray, gloom * 0.8);
    scene.fog.color.copy(hor).lerp(cols.fogNight, night * 0.55);
    const clear = day * (1 - warm) * (1 - sstep(0.3, 0.6, env.cloud)) * (1 - env.rain) * (1 - sstep(0.2, 0.5, env.mist)); skyU.uClear.value = clear;
    scene.fog.density = (0.002 + env.mist * 0.016) * (1 - 0.35 * clear) + night * 0.002 + env.rain * 0.009 + env.snow * env.fall * 0.012;
    // height fog: valley mist that hugs low ground; sun glow through the haze
    ridgeMurk.value = clamp(gloom * 1.1 + Math.max(0, env.mist - 0.2) * 0.9, 0, 1);
    FOGU.height.z = 0.5 + gloom * 0.45; FOGU.height.w = 0.7 + env.mist * 1.4;
    FOGU.sun.x = sunDir.x; FOGU.sun.y = sunDir.y; FOGU.sun.z = sunDir.z; FOGU.sun.w = isSun ? (0.55 + 0.4 * warm) * day * (1 - 0.85 * gloom) : 0; // dusty western haze toward the sun
    FOGU.sunCol.x = sunCol.r; FOGU.sunCol.y = sunCol.g; FOGU.sunCol.z = sunCol.b;
    skyU.uCloud.value = Math.max(env.cloud, env.rain * 0.95, env.snow * env.fall * 0.85);
    U.cloud.value = skyU.uCloud.value; U.snow.value = env.snow; U.wet.value = env.wet; U.rain.value = env.rain; MAT.leaf.userData.sh && (MAT.leaf.userData.sh.uniforms.uAutumn.value = env.autumn);
    U.sunCol.value.copy(sunCol); U.day.value = day; U.zen.value.copy(zen); U.hor.value.copy(hor);
    water.material.uniforms.uZen.value.copy(zen); water.material.uniforms.uHor.value.copy(hor); water.material.uniforms.uSunCol.value.copy(sunCol).multiplyScalar(1 - gloom * 0.9); water.material.uniforms.uDay.value = day;
    mM.color.set(night > 0.5 ? 0xc8ff6a : 0xffe2b0); mM.size = night > 0.5 ? 0.07 : 0.042; mM.opacity = night > 0.5 ? 0.95 : 0.85 * day; // drifting dust catches the sun
    renderer.toneMappingExposure = 1.0 + night * 0.35;
    // photo skies: pick the pair that matches the sun's height, rotate each so its sun lines up with ours
    let skyK = null;
    if (ASSETS.sky.day) {
      const e = Math.asin(clamp(sunDir.y, -1, 1)) * 57.2958; let A = 'day', B = 'day', mx = 0;
      if (e >= 22) {} else if (e >= 8) { A = 'gold'; mx = (e - 8) / 14; } else if (e >= 1) { A = 'dawn'; B = 'gold'; mx = (e - 1) / 7; } else if (e >= -7) { A = 'night'; B = 'dawn'; mx = (e + 7) / 8; } else { A = B = 'night'; }
      const azS = Math.atan2(sunDir.z, sunDir.x), azM = Math.atan2(-sunDir.z, -sunDir.x);
      const rot = k => (k === 'night' ? azM : azS) / TAU + 0.5 - SKY_META[k].sunU;
      skyU.tA.value = ASSETS.sky[A]; skyU.tB.value = ASSETS.sky[B]; skyU.uMixAB.value = mx; skyU.uRotA.value = rot(A); skyU.uRotB.value = rot(B); skyU.uExpA.value = SKY_META[A].exp; skyU.uExpB.value = SKY_META[B].exp;
      skyK = mx < 0.5 ? A : B;
      if (ENVS[skyK] && scene.environment !== ENVS[skyK]) scene.environment = ENVS[skyK];
      // pull the fog / horizon toward the photo's own horizon so the land meets the sky without a seam
      const hA = SKY_META[A].hor, hB = SKY_META[B].hor, eA = SKY_META[A].exp, eB = SKY_META[B].exp;
      tmpC.setRGB(lerp(hA[0] * eA, hB[0] * eB, mx), lerp(hA[1] * eA, hB[1] * eB, mx), lerp(hA[2] * eA, hB[2] * eB, mx));
      const lumOf = c => 0.3 * c.r + 0.59 * c.g + 0.11 * c.b; tmpC.multiplyScalar(lumOf(hor) / Math.max(1e-4, lumOf(tmpC))); // keep our brightness, borrow the photo's hue
      const pw = 0.55 * (1 - sstep(0.5, 0.9, skyU.uCloud.value)) * (1 - 0.6 * skyU.uClear.value); // clear days keep our blue horizon, not the photo's grey
      hor.lerp(tmpC, pw); scene.fog.color.lerp(tmpC, pw * 0.8); U.hor.value.copy(hor); water.material.uniforms.uHor.value.copy(hor);
    }
    const envK = skyK ? SKY_META[skyK].env * (1 - 0.45 * gloom) : 0.15 + 0.85 * day;
    if (Math.abs(envK - lastEnvK) > 0.02) { lastEnvK = envK; scene.traverse(o => { const ms = o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : []; for (const m of ms) { if (!('envMapIntensity' in m)) continue; if (m.userData.envBase === undefined) m.userData.envBase = m.userData.env ?? 0.06; m.envMapIntensity = m.userData.envBase * envK; } }); }
    keyBase = key.intensity; hemiBase = hemi.intensity;
    env._isSun = isSun; env._day = day; env._night = night; env._warm = warm; env._gloom = gloom;
  }
  applyTime();
  const refreshEnv = () => { lastEnvK = -1; applyTime(); };

  // lightning: storms flash the sky and light the valley, thunder follows with distance delay
  let boltT = 6 + rnd() * 10, flashSeq = [];
  const tv = new THREE.Vector3();
  let lastT = 0, lightDirty = 0;
  function update(time, focus) {
    const dt = clamp(time - lastT, 0, 0.1); lastT = time;
    // ease weather toward targets
    const T = env.tgt, k = 1 - Math.exp(-dt / 5);
    let moved = false;
    for (const key2 of ['cloud', 'rain', 'snow', 'mist', 'fall']) { const d = T[key2] - env[key2]; if (Math.abs(d) > 0.002) { env[key2] += d * k; moved = true; } else env[key2] = T[key2]; }
    const wetT = env.rain > 0.3 ? 1 : 0; env.wet += (wetT - env.wet) * (1 - Math.exp(-dt / (wetT ? 25 : 60)));
    if (moved || (lightDirty += dt) > 0.5) { lightDirty = 0; applyTime(); }
    // lightning
    if (env.rain > 0.75 && env.weather === 'rain') { boltT -= dt; if (boltT < 0) { boltT = 9 + rnd() * 16; flashSeq = [0, 0.09, 0.2].map(t => time + t); const dist = 0.4 + rnd() * 2.6; api.onThunder && setTimeout(() => api.onThunder(1 - dist / 3.4), dist * 1000); } }
    let fl = 0; for (const t0 of flashSeq) { const u = time - t0; if (u > 0 && u < 0.16) fl = Math.max(fl, 1 - u / 0.16); }
    env.flash = fl; skyU.uFlash.value = fl;
    key.intensity = keyBase + fl * 2.5; hemi.intensity = hemiBase + fl * 1.2;
    U.time.value = time; U.wind.value = 0.15 + env.wind * 1.4; U.focus.value.set(focus.x, focus.z);
    const ld = env._isSun ? sunDir : tv.copy(sunDir).negate();
    key.target.position.copy(focus); key.position.copy(focus).addScaledVector(ld, 80);
    fill.target.position.copy(focus); fill.position.copy(focus).add(tv.set(-30, 40, 20));
    sky.position.copy(camera.position); stars.position.copy(camera.position);
    U.sunV.value.copy(sunDir).transformDirection(camera.matrixWorldInverse);
    water.material.uniforms.uTime.value = time;
    forest.update(camera.position, dt);
    for (const c of chunkMeshes) c.im.visible = Math.hypot(c.cx - camera.position.x, c.cz - camera.position.z) < (c.near ? (LITE ? 30 : 48) : LITE ? 150 : 200);
    const night = skyU.uNight.value > 0.5;
    mSeed.forEach(([x0, y0, z0, ph, k3], i) => {
      const x = focus.x + (((x0 - focus.x) % 36) + 54) % 36 - 18 + 0.6 * Math.sin(time * 0.3 * k3 + ph);
      const z = focus.z + (((z0 - focus.z) % 36) + 54) % 36 - 18 + 0.6 * Math.cos(time * 0.27 * k3 + ph);
      const y = terrainH(x, z) + (night ? 0.3 + y0 * 0.5 : y0) + 0.25 * Math.sin(time * 0.5 * k3 + ph * 2);
      mP.set([x, y, z], i * 3);
    });
    mG.attributes.position.needsUpdate = true;
    if (night) mM.opacity = (0.6 + 0.4 * Math.sin(time * 3)) * (1 - env.rain);
  }
  // runtime quality knobs for the auto-tuner
  function setDetail({ grass, flowers, reflect, reflEvery, trees } = {}) {
    if (grass !== undefined) grassMesh.geometry.instanceCount = Math.round(GRASS_MAX * clamp(grass, 0.1, 1));
    if (flowers !== undefined && flowerMesh) flowerMesh.visible = flowers;
    if (reflect !== undefined) reflOn = REFL && reflect;
    if (reflEvery !== undefined) QUALITY.reflEvery = reflEvery;
    if (trees !== undefined) forest.setLodScale(trees);
  }
  const api = { grassMesh, ground, chunkMeshes, forest, env, applyTime, refreshEnv, update, nearTrees, nearProps, refreshItem, props, U, sunDir, skyU, key, renderReflection, setDetail, onThunder: null, hasReflection: () => REFL };
  return api;
}
