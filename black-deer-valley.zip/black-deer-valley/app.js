import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { createWorld, setPaintedLighting, terrainH, trailPoint, trailDist, forestD, pondD, POND, TRAIL, TAU, clamp, lerp, sstep, rnd } from './world.js';
import { Creature, CAT, MOVES, SPEAR_MOVE, loadSpecies, speciesReady, bindCreatureEnv, CQ } from './creatures.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';
import { createFX, createWeather } from './fx.js';
import { createAudio } from './audio.js';
import { createLive, VERSION, WHATS_NEW } from './live.js';
import { loadAssets } from './assets.js';
import { CFG } from './config.js';

const Q = new URLSearchParams(location.search);
const TOUCH = matchMedia('(pointer: coarse)').matches;
const $ = id => document.getElementById(id);
const store = { get(k, d) { try { const v = localStorage.getItem('bdv:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('bdv:' + k, JSON.stringify(v)); } catch (e) {} } };

// ---------- quality ----------
const QUALS = {
  // auto: starts from the device's best preset, then the tuner trades resolution and detail for a steady frame rate
  auto: TOUCH ? { treeHi: 16, treeMid: 46, pr: 2, grass: 72000, grassW: 40, grassFar: 0.25, grassShadow: false, lightGround: true, cheapGrass: true, shadow: 1536, treeSpace: 6.5, post: true, msaa: 0, fxaa: true, rays: 0, reflect: false, reflSize: 256, reflEvery: 2, flowers: 3000, sharpen: 0.16, auto: true }
              : { pr: 2, grass: 160000, grassW: 66, shadow: 4096, treeSpace: 6.5, post: true, msaa: 4, rays: 32, reflect: true, reflSize: 512, reflEvery: 2, flowers: 6000, sharpen: 0.12, auto: true },
  // ultra (PC): renders up to a 4K frame (supersampled on 1080p/1440p screens), longest draw distances, sharpest filtering
  ultra: { treeHi: 40, treeMid: 105, pr: 3, res4k: true, grass: 230000, grassW: 82, shadow: 4096, treeSpace: 6.5, post: true, msaa: 4, rays: 40, reflect: true, reflSize: 1024, reflEvery: 1, flowers: 9000, sharpen: 0.06, lod: 1.7, aniso: 16 },
  high: { pr: 2, grass: TOUCH ? 110000 : 160000, grassW: TOUCH ? 50 : 66, shadow: TOUCH ? 2048 : 4096, treeSpace: 6.5, post: true, msaa: 4, rays: TOUCH ? 24 : 32, reflect: true, reflSize: TOUCH ? 256 : 512, reflEvery: 2, flowers: TOUCH ? 3500 : 6000, sharpen: 0.14 },
  medium: { treeHi: 20, treeMid: 55, pr: 1.5, grass: 70000, grassW: 42, grassFar: 0.3, shadow: 2048, treeSpace: 8, post: true, msaa: 2, rays: 20, reflect: true, reflSize: 256, reflEvery: 2, flowers: 2500, sharpen: 0.2 },
  low: { treeHi: 14, treeMid: 38, pr: 1, grass: 28000, grassW: 32, grassFar: 0.3, grassShadow: false, lightGround: true, shadow: 1024, treeSpace: 10.5, post: false, msaa: 0, rays: 0, reflect: false, flowers: 0 },
};
let qualName = Q.get('quality') || store.get('quality', 'auto');
if (!QUALS[qualName] || (qualName === 'ultra' && TOUCH)) qualName = 'auto';
const QUALITY = QUALS[qualName];
const LITE = qualName === 'low';
QUALITY.painted = (Q.get('style') || store.get('style', 'photo')) === 'painted';
setPaintedLighting(true, QUALITY.painted ? 0.45 : 0.2); // soft wrapped light: painted strong, photo look gentle
const LODK = QUALITY.lod || 1; // creature detail-distance multiplier
CQ.painted = QUALITY.painted;
if (TOUCH) Object.assign(CQ, { shells: 7, furDist: 6, hi: 10, mid: 26 }); else if (qualName === 'ultra') Object.assign(CQ, { shells: 18, furDist: 16 }); else if (qualName === 'medium') Object.assign(CQ, { shells: 9, furDist: 8 });
let fpsCap = store.get('fpsCap', 0); // 0 = uncapped; 40/30 like the console port's iPhone modes
QUALITY.a2c = !LITE && !TOUCH && QUALITY.msaa > 0; // alpha-to-coverage is costly on phone GPUs

// ---------- renderer + post ----------
const canvas = $('view');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: !QUALITY.post, powerPreference: 'high-performance', preserveDrawingBuffer: Q.has('qa') });
renderer.setPixelRatio(Math.min(devicePixelRatio, QUALITY.pr));
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
const camera = new THREE.PerspectiveCamera(50, 1, 0.05, 900);
let composer = null, bloom = null;
const GradeShader = {
  uniforms: { tDiffuse: { value: null }, uVig: { value: 0.3 }, uSat: { value: 1.1 }, uHurt: { value: 0 }, uLow: { value: 0 }, uTime: { value: 0 }, uWarm: { value: 0 }, uNight: { value: 0 }, uTexel: { value: new THREE.Vector2(1 / 1024, 1 / 1024) }, uSharp: { value: 0.12 }, uPaint: { value: 0 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float uVig, uSat, uHurt, uLow, uTime, uWarm, uNight, uSharp, uPaint; uniform vec2 uTexel; varying vec2 vUv;
    void main(){ vec4 c = texture2D(tDiffuse, vUv);
      // light sharpen (keeps foliage crisp when the tuner lowers resolution)
      vec3 nb = texture2D(tDiffuse, vUv + vec2(uTexel.x, 0.0)).rgb + texture2D(tDiffuse, vUv - vec2(uTexel.x, 0.0)).rgb + texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y)).rgb + texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y)).rgb;
      c.rgb = max(c.rgb + (c.rgb * 4.0 - nb) * uSharp, 0.0);
      float l = dot(c.rgb, vec3(0.299, 0.587, 0.114));
      c.rgb = mix(vec3(l), c.rgb, uSat);
      // split toning: cool shadows, warm highlights (stronger at golden hour); moonlit nights lean blue
      float hl = smoothstep(0.15, 0.9, l);
      c.rgb *= mix(vec3(0.955, 1.0, 1.06), vec3(1.07 + 0.05 * uWarm, 1.01, 0.9 - 0.05 * uWarm), hl); // Red Dead look: amber light, cool teal shadows
      c.rgb = mix(c.rgb, c.rgb * vec3(0.86, 0.95, 1.18), uNight * 0.6 * (1.0 - hl));
      // western film look (reference: Red Dead Redemption): deeper toe, greens pulled toward olive, warm highlights
      c.rgb = mix(c.rgb, c.rgb * c.rgb / (c.rgb + 0.045), 0.36); c.rgb += vec3(0.004, 0.006, 0.01) * (1.0 - smoothstep(0.0, 0.25, l)); // shallower toe: shadows hold detail, a touch of sky in them
      float gx = max(c.g - max(c.r, c.b), 0.0); c.rgb += vec3(0.35, -0.25, -0.1) * gx * 0.36; // greens lean olive, like the western plains
      c.rgb = 0.18 * pow(max(c.rgb, 0.0) / 0.18, vec3(1.07)); // film contrast around mid grey (works on HDR values)
      // painted look: cool lifted shadows, warm clean highlights, a touch more colour
      if (uPaint > 0.0) { float pl = dot(c.rgb, vec3(0.3, 0.59, 0.11)); c.rgb += vec3(0.010, 0.016, 0.034) * (1.0 - smoothstep(0.0, 0.35, pl)) * uPaint; c.rgb = mix(vec3(pl), c.rgb, 1.0 + 0.12 * uPaint); c.rgb *= mix(vec3(1.0), vec3(1.03, 1.01, 0.97), smoothstep(0.4, 1.2, pl) * uPaint); }
      float d = length(vUv - 0.5); c.rgb *= 1.0 - uVig * smoothstep(0.35, 0.85, d);
      float pulse = uLow * (0.55 + 0.45 * sin(uTime * 5.5));
      c.rgb = mix(c.rgb, vec3(0.6, 0.05, 0.02), max(uHurt, pulse * 0.55) * smoothstep(0.3, 0.75, d));
      c.rgb = mix(c.rgb, vec3(dot(c.rgb, vec3(0.3, 0.59, 0.11))), uLow * 0.35);
      gl_FragColor = vec4(c.rgb, 1.0); }`,
};
// crepuscular rays: radial march toward the sun over open-sky pixels (sky writes alpha < 1 where the sky is clear)
const RaysShader = (N) => ({
  uniforms: { tDiffuse: { value: null }, uSun: { value: new THREE.Vector2(0.5, 0.8) }, uOn: { value: 0 }, uCol: { value: new THREE.Color(1, 0.8, 0.6) }, uAspect: { value: 1.6 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform vec2 uSun; uniform float uOn, uAspect; uniform vec3 uCol; varying vec2 vUv;
    void main(){ vec4 base = texture2D(tDiffuse, vUv);
      if (uOn < 0.002) { gl_FragColor = base; return; }
      vec2 dir = uSun - vUv; float dist = length(dir * vec2(uAspect, 1.0));
      vec2 st = dir / ${N}.0 * 0.9; vec2 uv = vUv + st * fract(sin(dot(vUv, vec2(12.9898, 78.233))) * 43758.5453);
      float acc = 0.0, w = 1.0;
      for (int i = 0; i < ${N}; i++) { uv += st; vec4 s = texture2D(tDiffuse, uv); float lum = dot(s.rgb, vec3(0.3, 0.59, 0.11));
        acc += (1.0 - s.a) * smoothstep(0.35, 2.4, lum) * w; w *= 0.965; }
      acc /= ${N}.0;
      gl_FragColor = vec4(base.rgb + uCol * acc * uOn * smoothstep(1.25, 0.0, dist) * 1.6, base.a); }`,
});
let grade = null, rays = null, fxaa = null;
camera.layers.enable(1); // layer 1: grass, water, weather, particles (kept out of the pond reflection)
if (QUALITY.post) {
  const rt = new THREE.WebGLRenderTarget(16, 16, { type: THREE.HalfFloatType, samples: QUALITY.msaa });
  composer = new EffectComposer(renderer, rt);
  composer.addPass(new RenderPass(scene, camera));
  if (QUALITY.rays) { rays = new ShaderPass(RaysShader(QUALITY.rays)); composer.addPass(rays); }
  bloom = new UnrealBloomPass(new THREE.Vector2(256, 256), QUALITY.painted ? 0.32 : 0.22, 0.5, 0.96); composer.addPass(bloom);
  grade = new ShaderPass(GradeShader); grade.uniforms.uSharp.value = QUALITY.sharpen || 0; grade.uniforms.uPaint.value = QUALITY.painted ? 1 : 0; if (QUALITY.painted) grade.uniforms.uVig.value = 0.2; composer.addPass(grade);
  composer.addPass(new OutputPass());
  if (QUALITY.fxaa) { fxaa = new ShaderPass(FXAAShader); composer.addPass(fxaa); } // phones: edge smoothing on the final image (after tone mapping, as FXAA expects)
}
function resize() {
  const w = innerWidth, h = innerHeight;
  if (QUALITY.res4k) renderer.setPixelRatio(clamp(Math.min(3840 / w, 2160 / h), 1, 2.5)); // aim for a 3840x2160 frame
  renderer.setSize(w, h, false); camera.aspect = w / h; camera.fov = w / h < 0.8 ? 62 : 50; camera.updateProjectionMatrix();
  if (composer) { composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(w, h); bloom.resolution.set(w / 2, h / 2); const pr = renderer.getPixelRatio(); grade.uniforms.uTexel.value.set(1 / (w * pr), 1 / (h * pr)); if (rays) rays.uniforms.uAspect.value = w / h; if (fxaa) fxaa.uniforms.resolution.value.set(1 / (w * pr), 1 / (h * pr)); }
  fx && fx.setScale(h * renderer.getPixelRatio() * 0.9);
  document.body.classList.toggle('narrow', w < 640);
}
const sunNdc = new THREE.Vector3();
function draw() {
  if (world) {
    world.renderReflection();
    if (rays) { // sun position on screen; fade when it leaves the frame, at night, or under heavy cloud
      const E = world.env; sunNdc.copy(world.sunDir).multiplyScalar(400).add(camera.position).project(camera);
      const vis = sunNdc.z < 1 ? sstep(1.7, 0.95, Math.max(Math.abs(sunNdc.x), Math.abs(sunNdc.y))) : 0;
      rays.uniforms.uSun.value.set((sunNdc.x + 1) / 2, (sunNdc.y + 1) / 2);
      rays.uniforms.uOn.value = vis * (E._isSun ? 1 : 0) * (E._day || 0) * (0.45 + 0.9 * (E._warm || 0)) * (1 - 0.85 * (E._gloom || 0)) * (0.6 + E.mist);
      rays.uniforms.uCol.value.copy(world.skyU.uSunCol.value);
    }
    if (grade) { grade.uniforms.uTime.value = simTime; grade.uniforms.uWarm.value = world.env._warm || 0; grade.uniforms.uNight.value = world.env._night || 0; grade.uniforms.uLow.value = player && !player.ko && player.hp / player.maxHp < 0.3 ? 1 - player.hp / player.maxHp / 0.3 : 0; }
  }
  composer ? composer.render() : renderer.render(scene, camera);
}

// ---------- state ----------
let world, fx, wx, all = [], player = null, followT = null, simTime = 0, timeScale = 1, hurtT = 0, shake = 0;
const birds = [], builds = [], buildObs = [];
const audio = createAudio();
const ctx = { notice: true, nightWolves: true };
const CAP = LITE ? 40 : 70;
const SAVE = { journal: store.get('journal', {}), inv: store.get('inv', { wood: 0, stone: 0, fiber: 0, berries: 0, axe: 0, spear: 0, torch: 0, campfire: 0, shelter: 0, fence: 0 }), builds: store.get('builds', []), skins: store.get('skins', {}) };
SAVE.vitals = store.get('vitals', { water: 100, hunger: 100 }); SAVE.water = clamp(+SAVE.vitals.water || 0, 0, 100);
const saveSoon = (() => { let t = 0; return () => { clearTimeout(t); t = setTimeout(() => { store.set('journal', SAVE.journal); store.set('inv', SAVE.inv); store.set('builds', SAVE.builds); store.set('skins', SAVE.skins); }, 800); }; })();

const FACTS = {
  buck: ['Black (melanistic) whitetail. Rare: dark pigment from a gene mutation.', 'Diet: browse, acorns, grasses.'],
  wbuck: ['Antlers regrow every year; tines grow with age and food.', 'Flags its white tail to warn the herd.'],
  doe: ['Leads the family herd; stomps and snorts at danger.', 'Can sprint 30 mph and leap 8 ft fences.'],
  fawn: ['White spots camouflage it in dappled light.', 'Nearly scentless in its first weeks.'],
  elk: ['Bulls bugle in autumn: a whistle that carries for miles.', 'Antlers can weigh 40 lb a pair.'],
  cow: ['Cows lead elk herds most of the year.', 'Calls softly to keep the herd together.'],
  horse: ['Free-roaming herds keep a lead mare and a stallion.', 'Kicks backwards with huge force.'],
  wolf: ['Hunts as a pack; howls to rally and claim territory.', 'Trots for hours at 5 mph.'],
  fox: ['Hears rodents under snow and pounces from above.', 'Tail ("brush") is for balance and warmth.'],
  rabbit: ['Zigzags to shake predators; thumps to warn others.', 'Eats its own weight in plants weekly.'],
  hiker: ['Carries a trekking pole and a camera.', 'Will back away from wolves.'],
  athlete: ['Hybrid athlete: calisthenics, running, discipline.', '5′11″, 148 lb, lean athletic. Upper-body strength, endurance, always improving.'],
  bird: ['Catches insects on the wing over meadows.', 'Flocks wheel and land together.'],
};
const SKINS = {
  buck: [['black', 'Melanistic', 0], ['whitetail', 'Natural', 'wbuck'], ['albino', 'Albino', 6], ['piebald:whitetail', 'Piebald', 10]],
  wbuck: [['whitetail', 'Natural', 0], ['black', 'Melanistic', 'buck'], ['albino', 'Albino', 6], ['piebald:whitetail', 'Piebald', 10]],
  doe: [['whitetail', 'Natural', 0], ['albino', 'Albino', 6], ['piebald:whitetail', 'Piebald', 10]],
  fawn: [['fawn', 'Natural', 0], ['albino', 'Albino', 8]],
  elk: [['elk', 'Natural', 0], ['albino', 'Albino', 10]], cow: [['elk', 'Natural', 0], ['albino', 'Albino', 10]],
  horse: [['horse', 'Natural', 0], ['melanistic', 'Black', 4], ['albino', 'Cremello', 8]],
  wolf: [['wolf', 'Gray', 0], ['melanistic', 'Black', 4], ['arctic', 'Arctic', 8]],
  fox: [['fox', 'Red', 0], ['silver', 'Silver', 4], ['arctic', 'Arctic', 8]],
  rabbit: [['rabbit', 'Natural', 0], ['arctic', 'Snowshoe white', 5]],
  hiker: [['human', 'Random outfit', 0]], athlete: [['athlete', 'Trail black', 0]], bird: [['bird', 'Natural', 0]],
};
const STARTERS = ['buck', 'athlete'];
const scannedCount = () => Object.keys(SAVE.journal).length;
const unlocked = t => STARTERS.includes(t) || !!SAVE.journal[t];
const skinUnlocked = (need) => need === 0 || (typeof need === 'number' ? scannedCount() >= need : !!SAVE.journal[need]);

// ---------- spawning (lazy species) ----------
const pending = [];
function spawn(type, x, z, opts = {}) {
  if (all.length >= CAP && type !== 'bird') return null;
  const mesh = CAT[type].mesh;
  if (!speciesReady(mesh)) { const p = { type, x, z, opts }; pending.push(p); loadSpecies(mesh); return null; }
  const c = new Creature(type, scene, { x, z, ...opts });
  c.initStats(); c.pos.y = terrainH(x, z); c.place(0);
  if (c.type === 'hiker') addHikerProps(c);
  if (c.spec.kind === 'bird') birds.push(c); else all.push(c);
  if (opts.leader) c.leader = opts.leader;
  return c;
}
function flushPending() { for (let i = pending.length - 1; i >= 0; i--) { const p = pending[i]; if (speciesReady(CAT[p.type].mesh)) { pending.splice(i, 1); const c = spawn(p.type, p.x, p.z, p.opts); if (c && p.then) p.then(c); } } }
function spawnGroup(type, x, z, n, followerType = type, r = 6) {
  const lead = { type, x, z, opts: {} };
  const go = () => { const L = spawn(type, x, z); if (!L) return; for (let i = 0; i < n; i++) { const [a, b] = near(x, z, r); spawn(followerType, a, b, { leader: L }); } };
  if (speciesReady(CAT[type].mesh) && speciesReady(CAT[followerType].mesh)) go(); else Promise.all([loadSpecies(CAT[type].mesh), loadSpecies(CAT[followerType].mesh)]).then(go);
}
const near = (x, z, r) => { const a = rnd() * TAU, d = Math.sqrt(rnd()) * r; return [x + Math.cos(a) * d, z + Math.sin(a) * d]; };
function spot(r) { for (let i = 0; i < 20; i++) { const [x, z] = near(0, 0, r); if (pondD(x, z) > POND.r + 4) return [x, z]; } return [0, 10]; }
const SPAWNS = {
  'Doe herd': () => { const [x, z] = spot(30); spawnGroup('doe', x, z, 2); spawnGroup('fawn', x + 2, z + 2, 0); },
  'Buck': () => spawn('wbuck', ...spot(35)),
  'Elk': () => { const [x, z] = spot(40); spawnGroup('elk', x, z, 2, 'cow', 7); },
  'Horses': () => { const [x, z] = spot(35); spawnGroup('horse', x, z, 3, 'horse', 8); },
  'Wolf pack': () => { const a = rnd() * TAU; spawnGroup('wolf', Math.cos(a) * 70, Math.sin(a) * 70, 2, 'wolf', 4); },
  'Fox': () => spawn('fox', ...spot(40)),
  'Rabbits': () => { const [x, z] = spot(35); for (let i = 0; i < 4; i++) spawn('rabbit', ...near(x, z, 6)); },
  'Hikers': () => { for (let i = 0; i < 2; i++) { const s = rnd() * TAU, p = trailPoint(s); const h = spawn('hiker', p.x, p.z); if (h) { h.trailS = s; h.dir = rnd() < 0.5 ? 1 : -1; } } },
  'Birds': () => { for (let i = 0; i < 8; i++) spawn('bird', ...near(0, 0, 20)); },
};
// compile every shader up front (hidden LODs included) so the first minutes don't hitch
async function warmShaders() {
  const hidden = []; scene.traverse(o => { if (!o.visible) { hidden.push(o); o.visible = true; } });
  try { await (renderer.compileAsync ? renderer.compileAsync(scene, camera) : renderer.compile(scene, camera)); } catch (e) { console.warn('warm', e); }
  for (const o of hidden) o.visible = false;
}
// the saddle first appears on a tame: compile its materials now (one horse, one synchronous compile) so that moment doesn't hitch
function warmHorseTack() { const h = all.find(c => c.type === 'horse' && c.tack); if (!h) return; const g = h.tack.g, was = g.visible, gv = h.group.visible; g.visible = true; h.group.visible = true; try { renderer.compile(scene, camera); } catch (e) {} g.visible = was; h.group.visible = gv; }
function populate() {
  const buck = spawn('buck', 4, 2, { yaw: 0.4, coat: SAVE.skins.buck });
  const man = spawn('athlete', 0.5, 4.5, { yaw: 0.3 }); man.trailS = 1.2; man.dir = 1; man.state = 'rest'; man.timer = 30;
  player = Q.get('as') === 'athlete' ? man : buck;
  for (const c of [man, buck]) c.hunger = clamp(+SAVE.vitals.hunger || 100, 5, 100);
  const herd = spawn('doe', 6, 22); for (const [x, z] of [[10, 25], [3, 27], [12, 19]]) spawn('doe', x, z, { leader: herd });
  for (const [x, z] of [[8, 23], [5, 24]]) spawn('fawn', x, z, { leader: herd });
  spawn('wbuck', -12, 30);
  for (let i = 0; i < 3; i++) { const s = i * 2.1 + 0.3, p = trailPoint(s); const h = spawn('hiker', p.x, p.z); if (h) { h.trailS = s; h.dir = i % 2 ? 1 : -1; } }
  for (let i = 0; i < 16; i++) spawn('bird', ...near(0, 0, 20));
  // background species stream in
  loadSpecies('elk').then(() => spawnGroup('elk', 42, 8, 2, 'cow', 6));
  loadSpecies('horse').then(() => { spawnGroup('horse', -28, -14, 3, 'horse', 7); restoreHorses(); setTimeout(warmHorseTack, 50); });
  loadSpecies('wolf').then(() => { spawnGroup('wolf', -78, 22, 2, 'wolf', 4); spawn('fox', 18, -40); });
  loadSpecies('rabbit').then(() => { for (let i = 0; i < 7; i++) spawn('rabbit', ...near(-6, -24, 12)); });
}
function addHikerProps(c) {
  const pm = new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.4, metalness: 0.5 });
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.012, 1.15, 6), pm); pole.position.set(0.02, -0.52, 0); pole.rotation.z = 0.15;
  const h = c.rest.handL; c.b.handL.add(pole); c.pole = pole; pole.castShadow = true;
}

// ---------- builds (campfire, shelter, fence) ----------
function makeBuild(kind) {
  const g = new THREE.Group(), wood = new THREE.MeshStandardMaterial({ color: 0x6b5038, roughness: 0.9 }), stone = new THREE.MeshStandardMaterial({ color: 0x7a766c, roughness: 0.95 });
  if (kind === 'campfire') {
    for (let i = 0; i < 9; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 6), stone); const a = i / 9 * TAU; s.position.set(Math.cos(a) * 0.55, 0.06, Math.sin(a) * 0.55); s.scale.y = 0.6; g.add(s); }
    for (let i = 0; i < 4; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 7), wood); l.rotation.z = 1.1; l.rotation.y = i * 1.57; l.position.y = 0.18; g.add(l); }
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 10, 1, true), new THREE.MeshBasicMaterial({ color: 0xffa03a, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }));
    flame.position.y = 0.45; g.add(flame); g.userData.flame = flame;
    const light = new THREE.PointLight(0xff9a40, 6, 14, 1.6); light.position.y = 0.8; g.add(light); g.userData.light = light;
  } else if (kind === 'shelter') {
    for (let i = 0; i < 7; i++) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.12, 2.6, 0.22), wood); p.position.set(-0.3, 0.95, -1.2 + i * 0.4); p.rotation.z = 0.75; g.add(p); }
    for (const z of [-1.3, 1.3]) { const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 1.9, 7), wood); post.position.set(0.55, 0.95, z); g.add(post); }
    const ridge = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.9, 7), wood); ridge.rotation.x = Math.PI / 2; ridge.position.set(0.55, 1.88, 0); g.add(ridge);
    const thatch = new THREE.MeshStandardMaterial({ color: 0x7a6440, roughness: 1 });
    for (let i = 0; i < 22; i++) { const t = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.035, 2.5 + rnd() * 0.3, 4), thatch); t.position.set(-0.24 + (rnd() - 0.5) * 0.05, 1.0, -1.35 + i * 0.13); t.rotation.z = 0.75 + (rnd() - 0.5) * 0.08; g.add(t); }
  } else if (kind === 'fence') {
    for (const x of [-1.4, 0, 1.4]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 1.2, 7), wood); p.position.set(x, 0.6, 0); g.add(p); }
    for (const y of [0.45, 0.9]) { const r = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.08, 0.06), wood); r.position.y = y; g.add(r); }
  }
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  return g;
}
function placeBuild(kind, x, z, yaw, persist = true) {
  const g = makeBuild(kind); g.position.set(x, terrainH(x, z), z); g.rotation.y = yaw; scene.add(g);
  const b = { kind, x, z, yaw, g }; builds.push(b); const o0 = buildObs.length;
  if (kind === 'fence') { for (const t of [-1.4, 0, 1.4]) buildObs.push({ x: x + Math.cos(yaw) * t, z: z - Math.sin(yaw) * t, r: 0.45 }); }
  if (kind === 'shelter') buildObs.push({ x: x - Math.cos(yaw) * 0.3, z: z + Math.sin(yaw) * 0.3, r: 0.9 });
  if (kind === 'campfire') buildObs.push({ x, z, r: 0.55 });
  b.obs = buildObs.slice(o0);
  if (persist) { SAVE.builds.push({ kind, x, z, yaw }); saveSoon(); }
  return b;
}
function removeBuild(b) {
  const i = builds.indexOf(b); if (i < 0) return; builds.splice(i, 1); scene.remove(b.g);
  for (const o of b.obs || []) { const j = buildObs.indexOf(o); if (j >= 0) buildObs.splice(j, 1); }
}
const worldProxy = { nearTrees: (x, z) => { const a = world.nearTrees(x, z); for (const o of buildObs) if (Math.abs(o.x - x) < 6 && Math.abs(o.z - z) < 6) a.push(o); return a; } };

// ---------- combat ----------
const tv = new THREE.Vector3(), tv2 = new THREE.Vector3();
const angTo = (a, b) => Math.atan2(-(b.z - a.z), b.x - a.x);
const d2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const angDiff = (a, b) => ((a - b + Math.PI * 3) % TAU) - Math.PI;
const vol = c => clamp(1 - camera.position.distanceTo(c.pos) / 45, 0, 1);
const radiusOf = c => (c.spec.kind === 'rabbit' ? 0.2 : c.spec.kind === 'human' ? 0.35 : 0.45 * c.S * c.size);
const FIGHTERS = { wolf: 1, elk: 1, wbuck: 1, buck: 1, horse: 1, fox: 0.6, hiker: 0.8 };
function resolveHit(att, m) {
  audio.play(m.dmg ? 'whoosh' : ({ snort: 'snort', bugle: 'bugle', whinny: 'whinny', howl: 'howl', yip: 'bark', thump: 'hoof' }[m.id] || 'whoosh'), vol(att));
  if (m.scare) for (const o of all) { if (o === att || o.ko || o === player) continue; if (d2(o.pos, att.pos) < m.scare && o.spec.group !== att.spec.group && (o.spec.role !== 'predator' || att.S * att.size > 1.1)) { o.state = 'flee'; o.fleeFrom = att; o.timer = 4 + rnd() * 3; } }
  if (m.rally) for (const o of all) { if (o === att || o.ko || o.spec.group !== 'wolf') continue; if (d2(o.pos, att.pos) < m.rally) { o.leader = att; o.state = 'wander'; o.goal = att.pos.clone(); o.timer = 4; if (att.target) { o.state = 'fight'; o.target = att.target; o.timer = 12; } } }
  if (!m.dmg) return;
  const fwd = att.forward(tv), reach = m.range * Math.sqrt(att.S * att.size);
  let hits = 0;
  for (const t of all) {
    if (t === att || t.ko || t === att.rider || t === att.mount) continue;
    const dx = t.pos.x - att.pos.x, dz = t.pos.z - att.pos.z, d = Math.hypot(dx, dz) - radiusOf(t);
    if (d > reach) continue;
    const ang = Math.atan2(-dz, dx), rel = Math.abs(angDiff(ang, att.yaw + (m.back ? Math.PI : 0)));
    if (rel > m.arc) continue;
    if (Math.abs(t.pos.y - att.pos.y) > 1.6 * att.S) continue;
    hits++;
    const sparring = att.sparWith === t;
    const dmg = sparring ? 0 : m.dmg * Math.pow(att.S * att.size, 0.35) * (att === player && SAVE.inv.axe && m.id === 'punch' && equipped === 'axe' ? 1.6 : 1);
    t.hp -= dmg; t.lastHit = simTime; t.flinch = 1; att.lastAtk = simTime;
    const mass = Math.max(0.25, t.S * t.size * (t.spec.kind === 'rabbit' ? 0.3 : 1));
    tv2.set(dx, 0, dz).normalize(); t.kv.addScaledVector(tv2, m.kb / mass * (sparring ? 0.4 : 1));
    tv2.copy(t.center); fx.burst('hit', tv2, { n: 7 }); fx.burst('dust', tv2.setY(t.pos.y + 0.1), { n: 6, k: 0.8 });
    audio.play('hit', vol(t));
    if (t === player) { hurtT = 1; shake = 0.35; hitArc(att); }
    if (dmg > 0 && (att === player || t === player)) { popNum(t, dmg, t === player); if (att === player) hitStop = dmg >= 25 ? 0.07 : 0.04; }
    if (att === player || t === player) showTarget(t === player ? att : t);
    // reactions
    if (t !== player && !t.rider && !sparring) {
      const fights = FIGHTERS[t.type] && !(t.spec.role === 'human' && att.spec.role === 'predator');
      if (fights && rnd() < FIGHTERS[t.type] + 0.3) { t.state = 'fight'; t.target = att; t.timer = 14; }
      else { t.state = 'flee'; t.fleeFrom = att; t.timer = 5 + rnd() * 4; }
    }
    if (t.hp <= 0) {
      t.hp = 0; t.knockOut(); audio.play('ko', vol(t));
      if (att.spec.role === 'predator' || att.spec.role === 'hunter') att.hunger = Math.min(100, att.hunger + 45);
      if (att === player) { toast(`${t.spec.name} knocked out`); live?.stat('kos'); }
      if (t === player) { setTimeout(showKO, 900); live?.stat('knockedOut'); }
      if (att.target === t) { att.target = null; att.state = 'rest'; att.timer = 5; }
    }
  }
}
let targetShown = null, targetT = 0;
function showTarget(c) { targetShown = c; targetT = 3.5; }
let hitStop = 0;
const camR = new THREE.Vector3(), camF = new THREE.Vector3();
function hitArc(att) {
  if (!att || !player) return; camera.getWorldDirection(camF); camF.y = 0; camF.normalize(); camR.set(-camF.z, 0, camF.x);
  const vx = att.pos.x - player.pos.x, vz = att.pos.z - player.pos.z, a = Math.atan2(vx * camR.x + vz * camR.z, vx * camF.x + vz * camF.z);
  const el = document.createElement('div'); el.className = 'hitArc'; el.style.rotate = a + 'rad'; $('dmgDir').appendChild(el); setTimeout(() => el.remove(), 950);
}
function popNum(t, dmg, me) {
  camera.updateMatrixWorld(); tv.copy(t.center).setY(t.pos.y + t.height * 1.02).project(camera); if (tv.z > 1) return;
  const el = document.createElement('div'); el.className = 'num' + (me ? ' me' : dmg >= 25 ? ' big' : ''); el.textContent = Math.round(dmg);
  el.style.transform = `translate(${((tv.x + 1) / 2 * innerWidth + (rnd() - 0.5) * 30).toFixed(0)}px, ${((1 - tv.y) / 2 * innerHeight).toFixed(0)}px) translate(-50%, -100%)`;
  $('nums').appendChild(el); setTimeout(() => el.remove(), 850); while ($('nums').children.length > 12) $('nums').firstChild.remove();
}

// ---------- behavior ----------
function isThreat(c, o) {
  if (o === c || o.ko || o.spec.kind === 'bird') return 0;
  const me = c.spec.role, them = o.spec.role, isP = o === player;
  if (isP && !ctx.notice) return 0;
  if (c.tamed && (isP || o === player?.mount)) return 0; // a tamed horse trusts its rider
  if (c.type === 'horse' && isP && o.spec.kind === 'human' && !o.mount) { if (c.calming) return 0; if (o.speed < CFG.tame.calmSpeed && !o.act) return CFG.tame.walkThreat; } // walk up slowly and wild horses only watch you
  if (them === 'predator' && me !== 'predator') return me === 'grazer' ? 0.8 : 1;
  if (them === 'hunter' && me === 'small') return 1;
  if (them === 'human') { if (me === 'grazer') return 0.45; if (me === 'predator') return isTorchOn(o) ? 1.2 : 0.4; return 0.9; }
  if (isP && o.speed > 5.5 && o.spec.group !== c.spec.group && me !== 'predator') return 0.5;
  return 0;
}
const isNight = () => world.env.hour > 19.9 || world.env.hour < 5.8;
const isTorchOn = c => c === player && equipped === 'torch' && SAVE.inv.torch > 0;
function think(c, dt) {
  const sp = c.spec, role = sp.role, [vW, vT, vR] = sp.speeds;
  c.timer -= dt; c.cool = (c.cool || 0) - dt;
  c.hunger = Math.max(0, c.hunger - dt * 0.05);
  if (role === 'human') return thinkHiker(c, dt);
  if (c.tamed) return thinkTamed(c, dt);
  if (c.calming) { c.wantSpeed = 0; c.state = 'alert'; c.alertOf = player; c.timer = 2; if (Math.abs(angDiff(angTo(c.pos, player.pos), c.yaw)) > 0.9) c.wantYaw = angTo(c.pos, player.pos); return; }
  if (c.state === 'fight') {
    const t = c.target;
    if (!t || t.ko || c.timer < 0 || d2(t.pos, c.pos) > 40) { c.state = 'rest'; c.timer = 4; c.target = null; c.sparWith = null; return; }
    const d = d2(t.pos, c.pos) - radiusOf(t), m = MOVES[c.type][0];
    c.wantYaw = angTo(c.pos, t.pos);
    if (m.back) c.wantYaw += Math.PI * (d < m.range * 1.2 ? 1 : 0);
    c.wantSpeed = d > m.range * 0.8 ? (d > 6 ? vR * 0.9 : vT) : 0;
    if (d < m.range * 1.1 && Math.abs(angDiff(c.yaw, c.wantYaw)) < 0.5) { const i = rnd() < 0.75 ? 0 : (rnd() < 0.5 ? 1 : 0); c.startAction(MOVES[c.type][i].dmg ? i : 0); }
    return;
  }
  // nearest weighted threat
  let threat = null, best = 1e9;
  for (const o of all) { const w = isThreat(c, o); if (!w) continue; const d = d2(c.pos, o.pos) / w; if (d < best) { best = d; threat = o; } }
  const fleeD = { prey: 15, grazer: 11, small: 8, hunter: 9, predator: 6 }[role], alertD = fleeD * 1.9;
  if (threat && best < fleeD && c.state !== 'chase') {
    if (c.state !== 'flee') { c.timer = 5 + rnd() * 4; c.fleeFrom = threat; }
    c.state = 'flee';
    for (const o of all) if (o !== c && !o.ko && o.spec.group === sp.group && o.state !== 'flee' && o.state !== 'fight' && d2(o.pos, c.pos) < 18 && o !== player) { o.state = 'flee'; o.timer = 4 + rnd() * 3; o.fleeFrom = threat; }
  } else if (threat && best < alertD && c.state !== 'flee' && c.state !== 'chase') {
    if (c.state !== 'alert') c.timer = 2 + rnd() * 3;
    if (c.state === 'bed') c.timer = 3;
    c.state = 'alert'; c.alertOf = threat;
  }
  switch (c.state) {
    case 'flee': {
      const f = c.fleeFrom || threat, away = f ? angTo(f.pos, c.pos) : c.yaw;
      const zig = role === 'small' ? Math.sin(c.timer * 5 + c.id) * 0.9 : Math.sin(c.timer * 1.3 + c.id) * 0.25;
      c.wantYaw = away + zig; c.wantSpeed = vR * (0.85 + 0.15 * Math.sin(c.id));
      if (sp.kind === 'hoofed' && rnd() < dt * 0.25) c.jump();
      if (c.timer < 0 && (!f || d2(f.pos, c.pos) > fleeD * 1.6)) { c.state = 'alert'; c.timer = 2.5; c.alertOf = f; }
      break;
    }
    case 'alert': {
      c.wantSpeed = 0; const o = c.alertOf; if (o) c.lookYaw = clamp(angDiff(angTo(c.pos, o.pos), c.yaw), -0.9, 0.9);
      if (c.timer < 0) { c.state = 'idle'; c.timer = 1 + rnd() * 2; }
      break;
    }
    case 'chase': {
      const t = c.target;
      if (!t || t.ko || c.timer < 0 || d2(t.pos, c.pos) > 50) { c.state = 'rest'; c.timer = 6 + rnd() * 5; c.cool = 25 + rnd() * 15; c.target = null; break; }
      if (isTorchOn(t) && d2(t.pos, c.pos) < 10) { c.state = 'flee'; c.fleeFrom = t; c.timer = 4; break; }
      c.wantYaw = angTo(c.pos, t.pos); c.wantSpeed = vR * 0.92;
      const d = d2(t.pos, c.pos) - radiusOf(t);
      if (d < 1.4 * c.S * c.size) { const i = sp.group === 'fox' && d > 0.8 ? 1 : 0; c.startAction(i); }
      break;
    }
    case 'drink': c.wantSpeed = 0; if (c.timer < 0) { c.state = 'idle'; c.timer = 2; c.hunger = Math.min(100, c.hunger + 10); } break;
    case 'bed': c.wantSpeed = 0; if (!isNight() && c.timer < 0) { c.state = 'idle'; c.timer = 2; } break;
    case 'spar': {
      const o = c.sparWith; if (!o || o.ko || c.timer < 0) { c.state = 'idle'; c.timer = 3; c.sparWith = null; break; }
      const d = d2(o.pos, c.pos); c.wantYaw = angTo(c.pos, o.pos); c.wantSpeed = d > 2.2 ? 1.2 : 0;
      if (d < 2.4 && rnd() < dt * 1.2) c.startAction(0);
      break;
    }
    case 'rest': c.wantSpeed = 0; if (c.timer < 0) { c.state = 'idle'; c.timer = 2; } break;
    default: {
      // night: herbivores bed down; wolves hunt the player
      if (isNight() && (role === 'prey' || role === 'grazer') && rnd() < dt * 0.08 && c.state !== 'wander') { c.state = 'bed'; c.timer = 20 + rnd() * 30; break; }
      if ((role === 'predator' || role === 'hunter') && c.cool <= 0 && !c.leader) {
        let prey = null, pd = role === 'hunter' ? 16 : 34;
        for (const o of all) { if (o === c || o.ko) continue; const r = o.spec.role; let ok = role === 'hunter' ? r === 'small' : (r === 'prey' || r === 'small');
          if (o === player && role === 'predator' && ctx.nightWolves && isNight() && player.spec.group !== 'wolf') { ok = true; }
          if (!ok) continue; const d = d2(o.pos, c.pos) * (o === player ? 0.6 : 1); if (d < pd) { pd = d; prey = o; } }
        if (prey && rnd() < dt * 0.5) { c.state = 'chase'; c.target = prey; c.timer = 7 + rnd() * 3; for (const o of all) if (o.leader === c && !o.ko) { o.state = 'chase'; o.target = prey; o.timer = c.timer; } if (rnd() < 0.3) c.startAction(2); break; }
        if (isNight() && rnd() < dt * 0.02) c.startAction(2);
      }
      if (c.type === 'elk' && (world.env.hour > 17 && world.env.hour < 20) && rnd() < dt * 0.03) c.startAction(2);
      // sparring bucks
      if ((c.type === 'wbuck' || c.type === 'elk') && !c.sparWith && rnd() < dt * 0.02) {
        const o = all.find(o => o !== c && o !== player && !o.ko && o.type === c.type && d2(o.pos, c.pos) < 14 && o.state !== 'flee');
        if (o) { c.state = 'spar'; o.state = 'spar'; c.sparWith = o; o.sparWith = c; c.timer = o.timer = 6 + rnd() * 4; break; }
      }
      const L = c.leader && all.includes(c.leader) && !c.leader.ko ? c.leader : null;
      if (L && d2(L.pos, c.pos) > 12 * c.S) { c.state = 'wander'; c.goal = L.pos.clone().add(new THREE.Vector3((rnd() - 0.5) * 6, 0, (rnd() - 0.5) * 6)); c.timer = 6; }
      if (c.timer < 0) {
        const r = rnd();
        if ((role === 'prey' || role === 'grazer') && r < 0.08) { const a = rnd() * TAU; c.goal = new THREE.Vector3(POND.x + Math.cos(a) * (POND.r + 0.9), 0, POND.z + Math.sin(a) * (POND.r + 0.9)); c.state = 'wander'; c.timer = 25; c.toDrink = true; }
        else if (r < (role === 'predator' ? 0.25 : 0.5)) { c.state = 'graze'; c.timer = 5 + rnd() * 9; c.hunger = Math.min(100, c.hunger + 6); }
        else if (r < 0.7) { c.state = 'idle'; c.timer = 2 + rnd() * 4; }
        else {
          c.state = 'wander'; c.timer = 8 + rnd() * 8; c.toDrink = false;
          const base = L ? L.pos : c.pos, R = role === 'predator' ? 25 : 14;
          let gx = base.x + (rnd() - 0.5) * R * 2, gz = base.z + (rnd() - 0.5) * R * 2;
          const rr = Math.hypot(gx, gz), lim = role === 'predator' ? 95 : role === 'hunter' ? 70 : 55;
          if (rr > lim) { gx *= lim / rr; gz *= lim / rr; }
          if (pondD(gx, gz) < POND.r + 2) gx += 14;
          c.goal = new THREE.Vector3(gx, 0, gz);
        }
      }
      if (c.state === 'wander' && c.goal) {
        const d = d2(c.goal, c.pos); c.wantYaw = angTo(c.pos, c.goal);
        c.wantSpeed = d < 1.2 ? 0 : (L && d2(L.pos, c.pos) > 14 * c.S) || role === 'predator' ? vT : vW;
        if (d < 1.2) { if (c.toDrink) { c.state = 'drink'; c.timer = 6 + rnd() * 4; c.wantYaw = angTo(c.pos, { x: POND.x, z: POND.z }); c.toDrink = false; } else { c.state = 'idle'; c.timer = 1 + rnd() * 3; } }
      } else c.wantSpeed = 0;
      c.lookYaw = 0;
    }
  }
  if (pondD(c.pos.x, c.pos.z) < POND.r + 0.6 && c.wantSpeed > 0 && !c.toDrink) c.wantYaw = Math.atan2(-(c.pos.z - POND.z), c.pos.x - POND.x);
  // campfires keep predators away
  if (role === 'predator') for (const b of builds) if (b.kind === 'campfire' && d2(b, c.pos) < 7) { c.state = 'flee'; c.fleeFrom = { pos: new THREE.Vector3(b.x, 0, b.z) }; c.timer = 3; }
}
// tamed horse: grazes near where you left it, still runs from wolves, comes when you whistle
function thinkTamed(c, dt) {
  const [vW, vT, vR] = c.spec.speeds; c.home = c.home || c.pos.clone();
  let threat = null, best = 9; for (const o of all) { if (o.ko || o.spec.role !== 'predator') continue; const d = d2(o.pos, c.pos); if (d < best) { best = d; threat = o; } }
  if (threat && c.state !== 'flee') { c.state = 'flee'; c.fleeFrom = threat; c.timer = 4; }
  switch (c.state) {
    case 'flee': { const f = c.fleeFrom; c.wantYaw = f ? angTo(f.pos, c.pos) : c.yaw; c.wantSpeed = vR * 0.85; if (c.timer < 0) { c.state = 'come'; c.timer = 25; } break; }
    case 'come': { if (!player) { c.state = 'idle'; break; } const d = d2(player.pos, c.pos); c.wantYaw = angTo(c.pos, player.pos); c.wantSpeed = d > 25 ? vR * 0.8 : d > 8 ? vT : d > 3 ? vW : 0;
      if (d < 3 || c.timer < 0) { c.state = 'idle'; c.timer = 4; c.home = c.pos.clone(); c.wantSpeed = 0; } break; }
    case 'graze': c.wantSpeed = 0; if (c.timer < 0) { c.state = 'idle'; c.timer = 2 + rnd() * 3; } break;
    case 'wander': { const d = d2(c.goal, c.pos); c.wantYaw = angTo(c.pos, c.goal); c.wantSpeed = d < 1 ? 0 : vW; if (d < 1 || c.timer < 0) { c.state = 'graze'; c.timer = 6 + rnd() * 8; } break; }
    default: c.wantSpeed = 0; if (c.timer < 0) { if (rnd() < 0.6) { c.state = 'graze'; c.timer = 6 + rnd() * 10; } else { const a = rnd() * TAU, r = rnd() * CFG.tame.stayRadius; c.goal = new THREE.Vector3(c.home.x + Math.cos(a) * r, 0, c.home.z + Math.sin(a) * r); if (pondD(c.goal.x, c.goal.z) < POND.r + 1.5) c.goal.copy(c.home); c.state = 'wander'; c.timer = 10; } }
  }
  if (pondD(c.pos.x, c.pos.z) < POND.r + 0.6 && c.wantSpeed > 0) c.wantYaw = Math.atan2(-(c.pos.z - POND.z), c.pos.x - POND.x);
}
function thinkHiker(c, dt) {
  const [vW] = c.spec.speeds;
  if (c.state === 'fight') { const t = c.target; if (!t || t.ko || c.timer < 0) { c.state = 'walk'; return; } const d = d2(t.pos, c.pos) - radiusOf(t); c.wantYaw = angTo(c.pos, t.pos); c.wantSpeed = d > 1.0 ? 2.4 : 0; if (d < 1.2) c.startAction(rnd() < 0.6 ? 0 : 1); return; }
  if (c.state === 'flee') { const f = c.fleeFrom; c.wantSpeed = c.spec.speeds[2]; if (f) c.wantYaw = angTo(f.pos, c.pos); if (c.timer < 0) c.state = 'walk'; return; }
  if (c.state === 'photo') { c.wantSpeed = 0; if (c.subject) c.wantYaw = angTo(c.pos, c.subject.pos); if (c.timer < 0) { c.state = 'walk'; c.cool = 10 + rnd() * 10; } if (rnd() < dt * 0.6) audio.play('shutter', vol(c) * 0.5); return; }
  if (c.state === 'wary') { const w = c.subject; c.wantSpeed = 1.1; if (w) c.wantYaw = angTo(w.pos, c.pos); if (c.timer < 0) c.state = 'walk'; return; }
  if (c.state === 'rest') { c.wantSpeed = 0; if (c.timer < 0) c.state = 'walk'; return; }
  c.state = 'walk';
  for (const o of all) {
    if (o === c || o.spec.role === 'human' || o.ko) continue;
    const d = d2(o.pos, c.pos);
    if (o.spec.role === 'predator' && d < 9) { c.state = 'wary'; c.subject = o; c.timer = 3; return; }
    if (c.cool <= 0 && d < 24 && d > 4) { c.state = 'photo'; c.subject = o; c.timer = 4 + rnd() * 3; return; }
  }
  if (rnd() < dt * 0.01) { c.state = 'rest'; c.timer = 5 + rnd() * 5; }
  c.trailS = Math.atan2(c.pos.z / TRAIL.b, c.pos.x / TRAIL.a);
  const tgt = trailPoint(c.trailS + c.dir * 0.09); tgt.x += Math.sin(c.id * 3.1) * 0.6;
  c.wantYaw = angTo(c.pos, tgt); c.wantSpeed = vW * (0.9 + 0.2 * Math.sin(c.id));
}
let flockMode = 'fly', flockT = 30, flockSpot = new THREE.Vector3();
function updateBirds(dt, time) {
  flockT -= dt;
  if (flockT < 0) { if (flockMode === 'fly') { flockMode = 'land'; flockT = 14; const [x, z] = spot(35); flockSpot.set(x, terrainH(x, z), z); } else { flockMode = 'fly'; flockT = 35 + rnd() * 25; } }
  if (flockMode !== 'fly' && player && d2(player.pos, flockSpot) < 7) { flockMode = 'fly'; flockT = 30; birds.forEach(b => { audio.play('chirp', vol(b) * 0.5); b.vel.y = 6; }); }
  const cx = Math.cos(time * 0.05) * 35, cz = Math.sin(time * 0.07) * 28, cy = 16 + 4 * Math.sin(time * 0.2);
  for (const b of birds) {
    if (b === player) {
      const m = moveVec(), s = 9 + (input.run ? 6 : 0);
      if (m.mag > 0.05) b.wantDir = Math.atan2(-m.z, m.x);
      b.yawB = lerp(b.yawB ?? b.yaw, b.wantDir ?? b.yaw, 1 - Math.exp(-2.5 * dt));
      const gy = terrainH(b.pos.x, b.pos.z);
      b.vel.set(Math.cos(b.yawB) * s * Math.max(0.35, m.mag), (input.jumpHeld ? 5 : 0) - (input.down ? 5 : 0) + (b.pos.y < gy + 2 ? 4 : -0.6), -Math.sin(b.yawB) * s * Math.max(0.35, m.mag));
      b.gliding = m.mag < 0.05; b.step(dt, time); continue;
    }
    const landing = flockMode === 'land';
    const tx = landing ? flockSpot.x + Math.sin(b.id * 7.3) * 4 : cx, tz = landing ? flockSpot.z + Math.cos(b.id * 5.1) * 4 : cz, ty = landing ? terrainH(tx, tz) + 0.05 : cy;
    if (landing && b.pos.distanceTo(tv.set(tx, ty, tz)) < 1.2) { // on the ground: hop and peck
      b.vel.multiplyScalar(0.8); b.pos.y = terrainH(b.pos.x, b.pos.z) + 0.05 + Math.max(0, Math.sin(time * 6 + b.id)) * 0.06; b.gliding = true;
      if (rnd() < dt * 0.5) b.vel.set((rnd() - 0.5) * 1.5, 0, (rnd() - 0.5) * 1.5);
      b.pos.addScaledVector(b.vel, dt); b.group.position.copy(b.pos); b.wings[0].rotation.x = -1.3; b.wings[1].rotation.x = 1.3; continue;
    }
    const steer = new THREE.Vector3(tx - b.pos.x, (ty - b.pos.y) * 2, tz - b.pos.z).multiplyScalar(landing ? 0.08 : 0.03);
    for (const o of birds) { if (o === b) continue; const d = b.pos.distanceTo(o.pos); if (d < 3) steer.add(tv.copy(b.pos).sub(o.pos).multiplyScalar(0.6 / Math.max(d, 0.3))); else if (d < 9) steer.add(tv.copy(o.vel).multiplyScalar(0.01)); }
    if (player && player.spec.kind !== 'bird' && b.pos.distanceTo(player.pos) < 6) steer.add(tv.copy(b.pos).sub(player.pos).multiplyScalar(0.8));
    const oy = Math.atan2(-b.vel.z, b.vel.x);
    b.vel.addScaledVector(steer, dt * 6); const sp = b.vel.length(); b.vel.multiplyScalar(clamp(sp, landing ? 3 : 7, 13) / sp);
    b._yawRate = angDiff(Math.atan2(-b.vel.z, b.vel.x), oy) / Math.max(dt, 1e-3);
    if (rnd() < dt * 0.4) b.gliding = !b.gliding;
    b.step(dt, time);
  }
}

// ---------- input ----------
const input = { keys: new Set(), stick: { x: 0, y: 0 }, pad: { x: 0, y: 0, run: false, on: false }, run: false, jumpHeld: false, down: false, ctxHeld: false };
let camYaw = 2.4, camPitch = 0.26, camDist = 0, camMode = 'follow', lastManual = -10, equipped = 'hands', buildGhost = null;
const freeCam = { pos: new THREE.Vector3(10, 4, 18), yaw: 0.6, pitch: -0.1 };
addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  audio.start();
  if (story.on) { e.preventDefault(); if (e.code === 'Escape') endStory(); else if (!e.repeat) nextStory(); return; }
  if (input.keys.has(e.code)) return;
  input.keys.add(e.code);
  const k = e.code;
  if (k === 'Space') { e.preventDefault(); doJump(); input.jumpHeld = true; }
  if (k === 'Digit1') doAct(1); if (k === 'Digit2') doAct(2); if (k === 'Digit3') doAct(3);
  if (k === 'KeyF' || k === 'KeyE') { input.ctxHeld = true; ctxTap(); }
  if (k === 'KeyK') togglePanel('kit'); if (k === 'KeyJ') togglePanel('journal'); if (k === 'KeyC' && player?.spec.kind === 'human') togglePanel('craft');
  if (k === 'KeyP') setPhoto(!document.body.classList.contains('photo'));
  if (k === 'Tab') { e.preventDefault(); const list = all.filter(c => c !== player && !c.ko && unlocked(c.type)); const n = list[(list.indexOf(followT) + 1) % list.length] || list[0]; if (n) control(n); }
  if (k === 'KeyV') setCam({ follow: 'orbit', orbit: 'free', free: 'follow' }[camMode]);
  if (k.startsWith('Digit') && +k.slice(5) >= 4) { const s = hotSlots()[+k.slice(5) - 4]; if (s) selectSlot(s.id); }
  if (k === 'Escape') { closePanels(); cancelBuild(); }
});
addEventListener('keyup', e => { input.keys.delete(e.code); if (e.code === 'Space') input.jumpHeld = false; if (e.code === 'KeyF' || e.code === 'KeyE') input.ctxHeld = false; });
function moveVec() {
  let x = input.stick.x + input.pad.x, y = input.stick.y + input.pad.y;
  const K = input.keys;
  if (K.has('KeyW') || K.has('ArrowUp')) y += 1; if (K.has('KeyS') || K.has('ArrowDown')) y -= 1;
  if (K.has('KeyD') || K.has('ArrowRight')) x += 1; if (K.has('KeyA') || K.has('ArrowLeft')) x -= 1;
  const mag = Math.min(1, Math.hypot(x, y));
  const cy = camMode === 'free' ? freeCam.yaw : camYaw;
  const fx_ = -Math.sin(cy), fz = -Math.cos(cy), rx = Math.cos(cy), rz = -Math.sin(cy);
  const wx = fx_ * y + rx * x, wz = fz * y + rz * x, l = Math.hypot(wx, wz) || 1;
  input.run = K.has('ShiftLeft') || K.has('ShiftRight') || Math.hypot(input.stick.x, input.stick.y) > 0.92 || input.pad.run;
  input.down = K.has('KeyQ') || K.has('ControlLeft') || !!input.pad.down;
  return { x: wx / l, z: wz / l, mag };
}
// ---------- opening story: four captioned cards over slow camera moves ----------
const story = { on: false, i: 0, t: 0, then: null }, storyFocus = new THREE.Vector3();
function playStory(then) {
  story.on = true; story.i = -1; story.then = then || null; closePanels(); hideCard(); document.body.classList.add('story'); $('story').hidden = false;
  $('storyTip').textContent = TOUCH ? 'Tap to continue' : 'Click or press any key';
  const D = $('storyDots'); D.textContent = ''; for (let k = 0; k < CFG.story.cards.length; k++) D.appendChild(document.createElement('i'));
  nextStory();
}
function nextStory() {
  if (!story.on) return; story.i++; story.t = 0; const C = CFG.story.cards[story.i]; if (!C) return endStory();
  $('storyT').textContent = C.title; $('storyP').textContent = C.text; [...$('storyDots').children].forEach((d, k) => d.classList.toggle('on', k <= story.i));
  $('storyNext').textContent = story.i === CFG.story.cards.length - 1 ? 'Begin' : 'Next';
  const c = $('story').querySelector('.card'); c.classList.remove('in'); void c.offsetWidth; c.classList.add('in'); audio.play('ui');
}
function endStory() {
  if (!story.on) return; story.on = false; $('story').hidden = true; document.body.classList.remove('story'); store.set('storySeen', 1); camS.ready = false;
  const t = story.then; story.then = null; if (t) t();
}
$('story').addEventListener('pointerdown', e => { if (e.target.closest('button')) return; e.preventDefault(); audio.start(); nextStory(); });
$('storyNext').onclick = () => nextStory(); $('storySkip').onclick = () => endStory();
$('storyReplay').onclick = () => playStory();
function storyShot(id) { // a target and an orbit for each card
  if (id === 'herd') { const h = all.find(c => c.type === 'horse' && !c.tamed && !c.ko) || all.find(c => c.type === 'horse'); if (h) return { x: h.pos.x, z: h.pos.z, y: h.pos.y + 1.1, R: 13, H: 2.0, a: Math.atan2(-h.pos.z, -h.pos.x) - 0.15 }; } // from the meadow side, the forest behind
  if (id === 'pond') return { x: POND.x, z: POND.z, y: POND.y + 1, R: 17, H: 3.2, a: 2.2 };
  if (id === 'camp' && CAMP) return { x: CAMP.x, z: CAMP.z, y: CAMP.g.position.y + 1.4, R: 8.5, H: 2.8, a: 1.1 };
  return { x: 4, z: 4, y: 1.5, R: 30, H: 7.5, a: 0.9 };
}
function storyCamera(dt) {
  story.t += dt; if (story.t > CFG.story.cardSec) { nextStory(); if (!story.on) return false; }
  const C = CFG.story.cards[story.i], S = storyShot(C.shot), a = S.a + story.t * 0.045, k = 1 + story.t * 0.006;
  camera.position.set(S.x + Math.cos(a) * S.R * k, S.y + S.H * k, S.z + Math.sin(a) * S.R * k); camera.position.y = Math.max(camera.position.y, terrainH(camera.position.x, camera.position.z) + 0.8);
  camera.lookAt(S.x, S.y, S.z); storyFocus.set(S.x, 0, S.z); return true;
}
// ---------- Frontier quest chain ----------
SAVE.quest = store.get('quest', { i: 0, rode: 0, lit: 0 });
const QUESTS = CFG.quests, curQuest = () => QUESTS[SAVE.quest.i] || null;
let CAMP = null;
function findRidge() { // highest open ground in the meadow, away from the pond, trail and trees
  let best = null, bh = -1e9;
  for (let i = 0; i < 48; i++) for (let j = 0; j < 48; j++) { const x = -60 + i * 2.5, z = -60 + j * 2.5, r = Math.hypot(x, z);
    if (r < 26 || r > 52 || forestD(x, z) > 0.2 || pondD(x, z) < POND.r + 14 || trailDist(x, z) < 4) continue;
    if (world.nearTrees(x, z).some(t => Math.hypot(t.x - x, t.z - z) < 6.5)) continue;
    const h = terrainH(x, z) - 0.002 * r; if (h > bh) { bh = h; best = { x, z }; } }
  return best || { x: -30, z: 30 };
}
function buildCamp() {
  const { x, z } = CAMP = findRidge(), g = new THREE.Group(); g.position.set(x, terrainH(x, z), z); scene.add(g);
  const wood = new THREE.MeshStandardMaterial({ color: 0x6b5038, roughness: 0.9 }), dark = new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 0.95 }), stone = new THREE.MeshStandardMaterial({ color: 0x77736a, roughness: 0.95 });
  for (let i = 0; i < 12; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), stone), a = i / 12 * TAU; s.position.set(Math.cos(a) * 0.95, 0.08, Math.sin(a) * 0.95); s.scale.set(1, 0.6, 0.9); g.add(s); }
  const pile = new THREE.Group(); for (let i = 0; i < 9; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 1.9, 7), i % 2 ? wood : dark), a = i / 9 * TAU; l.position.set(Math.cos(a) * 0.32, 0.8, Math.sin(a) * 0.32); l.rotation.set(Math.sin(a) * 0.38, 0, -Math.cos(a) * 0.38); pile.add(l); } g.add(pile);
  const lean = makeBuild('shelter'); lean.position.set(-3.2, 0, 1.2); lean.rotation.y = 0.5; g.add(lean);
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 3.4, 7), wood); pole.position.set(1.8, 1.7, -1.6); g.add(pole);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.5, 6, 1), new THREE.MeshStandardMaterial({ color: 0x8e2a1a, roughness: 0.9, side: THREE.DoubleSide })); flag.position.set(2.25, 3.1, -1.6); g.add(flag);
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  buildObs.push({ x, z, r: 1.05 }, { x: x - 3.2, z: z + 1.2, r: 1.0 }, { x: x + 1.8, z: z - 1.6, r: 0.12 });
  CAMP.g = g; CAMP.flag = flag; if (SAVE.quest.lit) lightSignal(true);
}
function lightSignal(quiet) {
  if (CAMP.fire) return; const f = new THREE.Group(); f.position.y = 0.2; CAMP.g.add(f);
  const fm = new THREE.MeshBasicMaterial({ color: 0xffa03a, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false });
  for (let i = 0; i < 4; i++) { const c = new THREE.Mesh(new THREE.ConeGeometry(0.45 - i * 0.06, 1.6 + i * 0.25, 12, 1, true), fm); c.position.set((i - 1.5) * 0.12, 0.8 + i * 0.12, (i % 2 - 0.5) * 0.15); f.add(c); }
  const light = new THREE.PointLight(0xff9440, 14, 34, 1.5); light.position.y = 1.8; f.add(light); CAMP.fire = f; CAMP.light = light;
  if (!quiet) { audio.play('timber', 0.6); audio.play('unlock'); for (let i = 0; i < 8; i++) fx.burst('ember', tv.set(CAMP.x, CAMP.g.position.y + 1, CAMP.z)); }
}
function nearestWildHorse() { let h = null, hd = 1e9; for (const c of all) if (c.type === 'horse' && !c.tamed && !c.ko && !c.remote) { const d = d2(c.pos, player.pos); if (d < hd) { hd = d; h = c; } } return h; }
let woodTgt = null, woodT = 0;
function questTarget(q) {
  if (!q || !player) return null;
  if (q.id === 'herd' || q.id === 'tame') { const h = nearestWildHorse(); return h ? { x: h.pos.x, z: h.pos.z, y: h.pos.y + h.height + 0.4 } : null; }
  if (q.id === 'pond') return { x: POND.x, z: POND.z, y: POND.y + 1.5 };
  if (q.id === 'wood') { if ((woodT -= 1) < 0 || !woodTgt?.alive) { woodT = 30; let b = null, bd = 1e9; for (const p of world.props) if (p.alive && (p.kind === 'log' || p.kind === 'pine' || p.kind === 'hard')) { const d = Math.hypot(p.x - player.pos.x, p.z - player.pos.z); if (d < bd) { bd = d; b = p; } } woodTgt = b; }
    return woodTgt ? { x: woodTgt.x, z: woodTgt.z, y: woodTgt.y + (woodTgt.kind === 'log' ? 1.2 : 3.2) * woodTgt.s } : null; }
  if (q.id === 'signal' && CAMP) return { x: CAMP.x, z: CAMP.z, y: CAMP.g.position.y + 2.6 };
  return null;
}
function questDone(q) {
  switch (q.id) {
    case 'herd': { const h = nearestWildHorse(); return !!SAVE.journal.horse || (h && d2(h.pos, player.pos) < CFG.quest.herdNear) || all.some(c => c.tamed); }
    case 'tame': return all.some(c => c.tamed && !c.remote);
    case 'pond': return !!SAVE.quest.drank;
    case 'wood': return SAVE.inv.wood >= q.need;
    case 'signal': return !!SAVE.quest.lit;
  }
  return false;
}
function questProg(q) { if (q.id === 'wood') return `${Math.min(SAVE.inv.wood, q.need)}/${q.need} wood`; const t = questTarget(q); return t && player ? `${Math.round(Math.hypot(t.x - player.pos.x, t.z - player.pos.z))} m` : ''; }
let questT = 0;
function questTick(dt) {
  if (!player || player.spec.kind !== 'human' || !window.__ready) return;
  if (player.mount && pondD(player.pos.x, player.pos.z) < POND.r + CFG.quest.pondRide && curQuest()?.id === 'pond') SAVE.quest.rode = 1;
  if ((questT -= dt) > 0) return; questT = 0.3;
  const q = curQuest(); if (!q || !questDone(q)) return;
  SAVE.quest.i++; store.set('quest', SAVE.quest); toast(`Quest complete: ${q.title}`, true); gainXP(q.xp, 'quest'); live?.stat('quests');
  const n = curQuest(); if (n) setTimeout(() => toast(`New quest: ${n.title}. ${n.hint}`), 1800); else setTimeout(() => { toast('Frontier chapter complete. The valley is yours.', true); audio.play('unlock'); }, 1800);
  refreshGoals();
}
const wpV = new THREE.Vector3();
function updateWaypoint() {
  const el = $('wp'), q = curQuest(), t = player && player.spec.kind === 'human' && !followT && camMode !== 'free' ? questTarget(q) : null;
  if (!t) { el.hidden = true; return; }
  const d = Math.hypot(t.x - player.pos.x, t.z - player.pos.z); if (d < CFG.quest.wpHide) { el.hidden = true; return; }
  wpV.set(t.x, t.y, t.z).project(camera); let x = wpV.x, y = wpV.y; const behind = wpV.z > 1;
  if (behind) { x = -x; y = -1; }
  const m = 0.9, edge = behind || Math.abs(x) > m || Math.abs(y) > m; if (edge) { const k = m / Math.max(Math.abs(x), Math.abs(y), 1e-3); if (Math.max(Math.abs(x), Math.abs(y)) > m) { x *= k; y *= k; } }
  el.hidden = false; el.classList.toggle('edge', edge); el.style.left = ((x + 1) / 2 * innerWidth).toFixed(0) + 'px'; el.style.top = ((1 - y) / 2 * innerHeight).toFixed(0) + 'px';
  const txt = `${Math.round(d)} m`; if (el.lastChild.textContent !== txt) el.lastChild.textContent = txt;
}
// ---------- XP + levels ----------
SAVE.xp = store.get('xp', { xp: 0, level: 1, perks: {} }); SAVE.xp.perks = SAVE.xp.perks || {};
const xpNeed = L => Math.round(CFG.xp.base * Math.pow(L, CFG.xp.growth));
const perkN = id => SAVE.xp.perks[id] || 0;
const carryCap = () => CFG.xp.carryBase + CFG.xp.carryPer * perkN('carry');
const staCost = () => 1 - CFG.xp.staPer * perkN('sta');
function applyPerks(c) { if (!c || !c.maxHp) return; c.baseHp = c.baseHp || c.maxHp; const m = Math.round(c.baseHp * (1 + CFG.xp.hpPer * perkN('hp'))); if (m !== c.maxHp) { c.hp = Math.min(m, c.hp + Math.max(0, m - c.maxHp)); c.maxHp = m; } }
let xpPopT = 0;
function gainXP(n, why) {
  const X = SAVE.xp; if (!n || X.level >= CFG.xp.maxLevel) return; X.xp += n;
  const pop = $('xpPop'); pop.textContent = `+${n} XP` + (why ? ` · ${why}` : ''); pop.classList.remove('go'); void pop.offsetWidth; pop.classList.add('go');
  while (X.level < CFG.xp.maxLevel && X.xp >= xpNeed(X.level)) { X.xp -= xpNeed(X.level); X.level++; levelUp(X.level); }
  store.set('xp', X); refreshLevel();
}
function levelUp(L) {
  const P = CFG.xp.perks[(L - 2) % CFG.xp.perks.length]; SAVE.xp.perks[P.id] = perkN(P.id) + 1;
  applyPerks(player); if (player) player.hp = player.maxHp; audio.play('unlock'); live?.stat('levelUps');
  toast(`Level ${L}! ${P.name}: ${P.text}`, true); $('lvl').classList.remove('up'); void $('lvl').offsetWidth; $('lvl').classList.add('up');
}
function refreshLevel() {
  const X = SAVE.xp, max = X.level >= CFG.xp.maxLevel; $('lvlN').textContent = X.level; $('lvl').style.setProperty('--p', max ? 1 : (X.xp / xpNeed(X.level)).toFixed(3));
  $('lvl').title = max ? `Level ${X.level} (max)` : `Level ${X.level} · ${X.xp} / ${xpNeed(X.level)} XP`;
  const perks = CFG.xp.perks.filter(p => perkN(p.id)).map(p => `${p.name} ×${perkN(p.id)}`).join(', ');
  $('lvlLine').textContent = `Level ${X.level}` + (max ? ' (max)' : ` · ${X.xp} / ${xpNeed(X.level)} XP to level ${X.level + 1}`) + (perks ? ` · Perks: ${perks}` : '') + ` · Carry ${carryCap()} per material`;
}
function addRes(k, n) { const cap = carryCap(), got = Math.max(0, Math.min(n, cap - SAVE.inv[k])); SAVE.inv[k] += got; if (got < n) toast(got ? `+${got} ${k} · pack full (${cap})` : `Pack full: ${cap} ${k} max`); else toast(`+${n} ${k}`); return got; }
// ---------- taming ----------
SAVE.horses = store.get('horses', []);
function horseRecord(h) { return { x: +h.pos.x.toFixed(1), z: +h.pos.z.toFixed(1), name: h.horseName, coat: h.coat, size: +h.size.toFixed(3), v: h.variant ? [h.variant.c, h.variant.blaze ? 1 : 0, h.variant.socks.reduce((a, b, i) => a | (b ? 1 << i : 0), 0)] : [0, 0, 0] }; }
function saveHorses() { SAVE.horses = all.filter(c => c.tamed && !c.remote).map(horseRecord); store.set('horses', SAVE.horses); }
function tameHorse(h) {
  const used = new Set(all.filter(c => c.tamed).map(c => c.horseName)), names = CFG.tame.names.filter(n => !used.has(n));
  h.tamed = true; h.calming = false; h.trust = 1; h.horseName = names[(rnd() * names.length) | 0] || 'Horse'; h.leader = null; h.state = 'idle'; h.timer = 3; h.home = h.pos.clone();
  for (const o of all) if (o.leader === h) o.leader = null;
  h.showTack(true); fx.burst('scan', h.center, { n: 26 }); audio.play('unlock'); setTimeout(() => audio.play('nicker', 0.8), 400);
  toast(`You tamed a wild horse. Meet ${h.horseName}!`, true); toast('Walk up and press Ride. Whistle from afar to call it.');
  FLAGS.tamed = 1; live?.stat('tames'); saveHorses(); onTamed(h);
}
function onTamed(h) { gainXP(CFG.xp.gain.tame, 'tamed'); } // quests hook in here too
function spookHorse(h, why) {
  if ((h.trust || 0) > 0.04) toast(why === 'attack' ? 'The fight spooked the horse' : 'You ran at the horse. It bolted.');
  h.trust = 0; h.calming = false; h._nick = false; h.state = 'flee'; h.fleeFrom = player; h.timer = 6 + rnd() * 3; audio.play('whinny', vol(h));
  for (const o of all) if (o !== h && o.type === 'horse' && !o.tamed && !o.ko && d2(o.pos, h.pos) < 16) { o.state = 'flee'; o.fleeFrom = player; o.timer = 5 + rnd() * 3; o.trust = 0; }
}
let horseSaveT = 0;
function updateHorses(dt) {
  const p = player, onFoot = p && !p.ko && p.spec.kind === 'human' && !p.mount;
  const attacking = onFoot && p.act && p.act.m.dmg > 0, running = onFoot && p.speed > CFG.tame.calmSpeed + 0.3;
  for (const h of all) {
    if (h.type !== 'horse' || h.ko || h.tamed || h.remote) continue;
    if (!h.calming && h.trust > 0) { h.trust = Math.max(0, h.trust - dt * CFG.tame.decay); if (h.trust < 0.45) h._nick = false; }
    if (!onFoot || h.state === 'flee') continue;
    const d = d2(p.pos, h.pos);
    if (running && d < CFG.tame.spookDist) spookHorse(h, 'run'); else if (attacking && d < CFG.tame.spookDist * 1.5) spookHorse(h, 'attack');
  }
  // calming pose: hand out, palm low
  if (ctxNow?.kind === 'calm' && input.ctxHeld && p?.b?.armR) { const w = Math.min(1, calmT * 2.5); p.b.armR.rotation.z += 0.95 * w; p.b.armR.rotation.x -= 0.15 * w; p.b.foreR.rotation.z = lerp(p.b.foreR.rotation.z, 0.35, w); p.b.head.rotation.z -= 0.12 * w; }
  if ((horseSaveT -= dt) < 0) { horseSaveT = 8; if (all.some(c => c.tamed && !c.remote)) saveHorses(); }
}
function restoreHorses() {
  for (const r of SAVE.horses) { const x = num(r.x, -170, 170), z = num(r.z, -170, 170), v = Array.isArray(r.v) ? r.v : [0, 0, 0];
    const h = spawn('horse', x, z, { variant: horseVariant([num(v[0], 0, 4) | 0, v[1] ? 1 : 0, num(v[2], 0, 15) | 0]), size: num(r.size, 0.8, 1.2, 1), coat: COATS.has(r.coat) && r.coat !== 'horse' ? r.coat : undefined }); if (!h) continue;
    h.size = num(r.size, 0.8, 1.2, 1); h.rig.scale.setScalar(h.size); h.tamed = true; h.horseName = typeof r.name === 'string' ? r.name.slice(0, 20) : 'Horse'; h.home = h.pos.clone(); h.showTack(true); h.initStats(); }
}
// ---------- riding ----------
function mountHorse(h) {
  const p = player; if (!p || p.mount || p.ko || p.spec.kind !== 'human' || !h || h.ko || h.rider) return;
  cancelBuild(); if (p.state === 'photo') p.state = 'idle'; equipped = 'hands'; updateTorch();
  p.mount = h; h.rider = p; p._rideW = 0; p._rideFrom = p.pos.clone(); p.act = null;
  h.state = 'ridden'; h.wantSpeed = 0; h.target = null; h.fleeFrom = null; h.leader = null; h.showTack(true);
  camDist = CFG.ride.camDist; audio.play('whinny', 0.5); toast(`Riding ${h.horseName || 'your horse'}`);
  refreshActions(); buildHotbar(); live?.stat('rides');
}
function dismountHorse(fall) {
  const p = player, h = p?.mount; if (!h) return;
  p.unseat(h); p.mount = null; h.rider = null; h.state = 'idle'; h.timer = 3; h.wantSpeed = 0;
  const sx = Math.sin(h.yaw), sz = Math.cos(h.yaw); // the horse's left side
  const x = h.pos.x + sx * 1.15, z = h.pos.z + sz * 1.15, seatY = p.pos.y;
  p.pos.set(x, terrainH(x, z), z); p.air = Math.max(0.01, seatY - p.pos.y); p.vy = fall ? 0 : 1.2;
  p.yaw = p.wantYaw = h.yaw; p.speed = p.wantSpeed = 0; p.state = 'idle'; p.place(0);
  h.home = h.pos.clone(); saveHorses();
  camDist = 0; refreshActions(); buildHotbar();
}
function driveMount(dt) {
  const p = player, h = p.mount, R = CFG.ride, m = moveVec();
  const analog = TOUCH || input.pad.on, walk = input.down || (analog && m.mag < 0.55);
  const want = m.mag > 0.05 && p._rideW >= 1, gallop = want && input.run && !walk && h.sta > (h._galloping ? 0.5 : h._winded ? R.windedUntil : R.gallopMin);
  if (want) { h.wantYaw = Math.atan2(-m.z, m.x); h.wantSpeed = gallop ? R.speeds[2] : walk ? R.speeds[0] : R.speeds[1]; } else h.wantSpeed = 0;
  if (h._galloping && !gallop && input.run && want && h.sta <= 0.5) { h._winded = true; toast(`${h.horseName || 'Your horse'} is winded`); }
  if (h._winded && h.sta >= R.windedUntil) h._winded = false;
  h._galloping = gallop;
  h.sta = gallop ? Math.max(0, h.sta - dt * R.gallopDrain) : Math.min(100, h.sta + dt * (h.speed > 3 ? R.regenTrot : R.regenRest));
  $('stickBase').classList.toggle('sprint', gallop);
}
function drivePlayer(dt) {
  if (!player || player.ko || camMode === 'free' || player.spec.kind === 'bird') return;
  if (player.mount) return driveMount(dt);
  const m = moveVec(), [vW, vT, vR] = player.spec.speeds;
  const canRun = player.sta > 4;
  if (m.mag > 0.05 && !(input.ctxHeld && ctxNow && ctxNow.hold)) {
    player.wantYaw = Math.atan2(-m.z, m.x);
    const run = input.run && canRun;
    player.wantSpeed = run ? vR : m.mag < 0.55 && TOUCH ? lerp(vW * 0.5, vW, m.mag / 0.55) : vT * (player.spec.kind === 'human' ? 0.55 : 1);
    if (run) player.sta = Math.max(0, player.sta - dt * 13 * staCost());
    if (player.state !== 'photo') player.state = 'move';
  } else { player.wantSpeed = 0; if (player.state === 'move') player.state = 'idle'; }
  $('stickBase').classList.toggle('sprint', input.run && canRun && m.mag > 0.05);
}
function doJump() { if (!player || player.ko) return;
  if (player.mount) { const h = player.mount; if (h.air === 0 && h.sta >= CFG.ride.jumpCost && player._rideW >= 1) { h.sta -= CFG.ride.jumpCost; h.jump(); } return; } if (player.spec.kind === 'human' && player.state === 'photo') return; if (player.sta < 8 * staCost()) return; if (player.air === 0) { player.sta -= 8 * staCost(); player.jump(); } }
function doAct(k) { // keyboard 1-3
  if (!player) return;
  const human = player.spec.kind === 'human';
  if (k === 1) playerAction(1);
  else if (k === 2) playerAction(human ? 2 : 2);
  else if (k === 3) { if (human && !player.mount) togglePhotoPose(); else playerAction(2); }
}
function togglePhotoPose() { player.state = player.state === 'photo' ? 'idle' : 'photo'; if (player.state === 'photo') audio.play('shutter'); refreshActions(); }
function playerAction(slot) { // slot 0 primary, 1..2 skills, 3 = third
  audio.start();
  if (!player || player.ko) return;
  if (slot === 0 && buildGhost) return placeGhost();
  if (player.spec.kind === 'bird') return;
  if (player.mount) { if (player._rideW >= 1) player.mount.startAction(RIDE_SLOT[slot] ?? 1, true); return; } // in the saddle the buttons are the horse's: rear, whinny, buck
  if (slot === 2 && player.spec.kind === 'human' && SAVE.inv.spear) return void player.startAction(2, true, SPEAR_MOVE);
  player.startAction(slot, true);
}
// pointer
const ptrs = new Map(); let stickId = null, pinch0 = 0;
const stickEl = $('stickBase');
stickEl.addEventListener('pointerdown', e => { e.preventDefault(); audio.start(); stickId = e.pointerId; stickEl.setPointerCapture(e.pointerId); stickEl.classList.add('live'); moveStick(e); });
// floating stick: touch anywhere in the lower-left zone and the stick appears under your thumb
const zoneEl = $('stickZone'), stickHome = { l: '', b: '' };
zoneEl.addEventListener('pointerdown', e => { e.preventDefault(); audio.start(); const r = stickEl.getBoundingClientRect(); stickEl.style.left = (e.clientX - r.width / 2) + 'px'; stickEl.style.bottom = (innerHeight - e.clientY - r.height / 2) + 'px'; stickId = e.pointerId; zoneEl.setPointerCapture(e.pointerId); stickEl.classList.add('live'); moveStick(e); });
zoneEl.addEventListener('pointermove', e => { if (e.pointerId === stickId) moveStick(e); });
const endZone = e => { if (e.pointerId !== stickId) return; endStick(e); stickEl.style.left = stickHome.l; stickEl.style.bottom = stickHome.b; };
zoneEl.addEventListener('pointerup', endZone); zoneEl.addEventListener('pointercancel', endZone);
stickEl.addEventListener('pointermove', e => { if (e.pointerId === stickId) moveStick(e); });
const endStick = e => { if (e.pointerId !== stickId) return; stickId = null; input.stick.x = input.stick.y = 0; stickEl.firstElementChild.style.transform = ''; stickEl.classList.remove('live'); };
stickEl.addEventListener('pointerup', endStick); stickEl.addEventListener('pointercancel', endStick);
function moveStick(e) { const r = stickEl.getBoundingClientRect(), R = r.width / 2 - 10; let sx = (e.clientX - r.left - r.width / 2) / R, sy = (e.clientY - r.top - r.height / 2) / R; const l = Math.hypot(sx, sy); if (l > 1) { sx /= l; sy /= l; } input.stick.x = sx; input.stick.y = -sy; stickEl.firstElementChild.style.transform = `translate(${sx * R}px, ${sy * R}px)`; }
canvas.addEventListener('contextmenu', e => e.preventDefault());
canvas.addEventListener('pointerdown', e => {
  audio.start(); canvas.setPointerCapture(e.pointerId);
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, t: performance.now(), btn: e.button, type: e.pointerType });
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch0 = Math.hypot(a.x - b.x, a.y - b.y); }
});
canvas.addEventListener('pointermove', e => {
  const p = ptrs.get(e.pointerId); if (!p) return;
  const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (pinch0) camDist = clamp(camDist * pinch0 / d, 1.5, 30); pinch0 = d; return; }
  const k = TOUCH ? 0.006 : 0.005;
  if (camMode === 'free') { freeCam.yaw -= dx * k; freeCam.pitch = clamp(freeCam.pitch - dy * k, -1.3, 1.2); }
  else { camYaw -= dx * k; camPitch = clamp(camPitch + dy * k, -0.15, 1.35); }
  lastManual = simTime;
});
function endPtr(e) {
  const p = ptrs.get(e.pointerId); ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = 0;
  if (!p) return;
  const tap = Math.hypot(e.clientX - p.x0, e.clientY - p.y0) < 8 && performance.now() - p.t < 450;
  if (!tap) return;
  if (p.type === 'mouse' && p.btn === 0 && player && !document.body.classList.contains('photo')) { if (!pick(e.clientX, e.clientY, true)) playerAction(0); return; }
  pick(e.clientX, e.clientY, false);
}
canvas.addEventListener('pointerup', endPtr); canvas.addEventListener('pointercancel', e => ptrs.delete(e.pointerId));
canvas.addEventListener('wheel', e => { e.preventDefault(); camDist = clamp(camDist * (1 + Math.sign(e.deltaY) * 0.1), 1.5, 30); }, { passive: false });
const bindHold = (el, down, up) => { el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); audio.start(); down(); }); el.addEventListener('pointerup', e => { e.preventDefault(); up && up(); }); el.addEventListener('pointercancel', () => up && up()); el.addEventListener('pointerleave', () => up && up()); };
bindHold($('a0'), () => playerAction(0)); bindHold($('a1'), () => playerAction(1)); bindHold($('a2'), () => playerAction(2));
bindHold($('a3'), () => { if (player?.spec.kind === 'human' && !player.mount) togglePhotoPose(); else playerAction(2); });
const RIDE_SLOT = [1, 2, 0]; // slot -> horse move index
bindHold($('aj'), () => { doJump(); input.jumpHeld = true; }, () => input.jumpHeld = false);
bindHold($('ctx'), () => { input.ctxHeld = true; ctxTap(); }, () => input.ctxHeld = false);

const ray = new THREE.Raycaster();
function pick(x, y, onlyCheck) {
  if (document.body.classList.contains('photo')) return false;
  ray.setFromCamera(new THREE.Vector2(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1), camera);
  let best = null, bt = 1e9;
  for (const c of [...all, ...birds]) {
    if (!c.group.visible || c === player) continue;
    const ctr = c.spec.kind === 'bird' ? c.pos : c.center, r = c.spec.kind === 'bird' ? 1.2 : Math.max(0.5, c.height * 0.65);
    const t = tv.copy(ctr).sub(ray.ray.origin).dot(ray.ray.direction); if (t < 0) continue;
    const d = ray.ray.distanceSqToPoint(ctr); if (d < r * r && t < bt) { bt = t; best = c; }
  }
  if (onlyCheck && best && bt > 6) { showCard(best); return true; }
  if (onlyCheck) return false;
  if (best) showCard(best); else hideCard();
  return !!best;
}
canvas.addEventListener('pointerdown', e => { if (e.button === 2) { pick(e.clientX, e.clientY, false); } });

// ---------- context interactions ----------
let ctxNow = null, ctxProg = 0, chopT = 0;
const HERB = ['buck', 'wbuck', 'doe', 'fawn', 'elk', 'cow', 'horse', 'rabbit'];
function findContext() {
  if (!player || player.ko || player.spec.kind === 'bird') {
    if (player?.spec.kind === 'bird') { const t = scanTarget(32, 3.2); if (t) return { kind: 'scan', label: SAVE.journal[t.type] ? 'Scan' : 'Scan new', sub: t.spec.name, target: t, hold: 1.0 }; }
    return null;
  }
  if (buildGhost) return { kind: 'place', label: 'Place', sub: buildGhost.kind, hold: 0 };
  const human = player.spec.kind === 'human';
  if (player.mount) return { kind: 'dismount', label: 'Dismount', hold: 0 };
  const atPond = pondD(player.pos.x, player.pos.z) < POND.r + 1.6;
  if (human && !atPond) { let h = null, hd = CFG.ride.reach; for (const c of all) if (c.tamed && !c.ko && !c.rider && !c.remote) { const d = d2(c.pos, player.pos); if (d < hd) { hd = d; h = c; } }
    if (h) return { kind: 'ride', label: 'Ride', sub: h.horseName || '', target: h, hold: 0 }; }
  const props = world.nearProps(player.pos.x, player.pos.z, human ? 2.3 : 1.6);
  let p = null, pd = 1e9; for (const q of props) { const d = Math.hypot(q.x - player.pos.x, q.z - player.pos.z); if (d < pd) { pd = d; p = q; } }
  const t = scanTarget(20, 0.7);
  if (t && !SAVE.journal[t.type] && !(p && pd < 1.8)) return { kind: 'scan', label: 'Scan new', sub: t.spec.name, target: t, hold: 1.2 };
  if (human && player.speed < CFG.tame.calmSpeed) { let w = null, wd = CFG.tame.reach; for (const c of all) if (c.type === 'horse' && !c.tamed && !c.ko && !c.remote && c.state !== 'flee') { const d = d2(c.pos, player.pos); if (d < wd) { wd = d; w = c; } }
    if (w) return { kind: 'calm', label: 'Calm', sub: 'hold', target: w, hold: CFG.tame.holdSec, noMove: true }; }
  if (p) {
    if (human && (p.kind === 'pine' || p.kind === 'hard')) return { kind: 'chop', label: 'Chop', sub: p.kind === 'pine' ? 'Pine' : 'Oak', prop: p, hold: SAVE.inv.axe ? 1.6 : 3.2 };
    if (human && p.kind === 'rock' && p.s < 1.3) return { kind: 'mine', label: 'Mine', sub: 'Stone', prop: p, hold: SAVE.inv.axe ? 1.2 : 2.2 };
    if (human && p.kind === 'reed') return { kind: 'gather', label: 'Gather', sub: 'Reeds → fiber', prop: p, hold: 0.8 };
    if (human && p.kind === 'log') return { kind: 'gather', label: 'Gather', sub: 'Log → wood', prop: p, hold: 1.4 };
    if (p.kind === 'berry' && !(p.picked > simTime)) return { kind: 'berries', label: human ? 'Pick berries' : 'Eat berries', prop: p, hold: 0.9 };
  }
  if (human && CAMP && curQuest()?.id === 'signal' && Math.hypot(CAMP.x - player.pos.x, CAMP.z - player.pos.z) < CFG.quest.campReach) { const need = curQuest().need || QUESTS.find(q => q.id === 'wood').need;
    return SAVE.inv.wood >= need ? { kind: 'signal', label: 'Light signal fire', sub: `${need} wood`, hold: 2.2 } : { kind: 'info', label: 'Signal fire', sub: `needs ${need} wood (${SAVE.inv.wood})`, hold: 0 }; }
  for (const b of builds) if (b.kind === 'campfire' && d2(b, player.pos) < 2.6) return { kind: 'rest', label: 'Rest by fire', hold: 0.4, repeat: true };
  if (human) { const h = all.find(c => c.tamed && !c.ko && !c.rider && !c.remote); if (h && d2(h.pos, player.pos) > CFG.tame.whistleMin && h.state !== 'come') return { kind: 'whistle', label: 'Whistle', sub: h.horseName, target: null, horse: h, hold: 0.45 }; }
  if (pondD(player.pos.x, player.pos.z) < POND.r + 1.6) return { kind: 'drink', label: 'Drink', hold: 1.2 };
  if (HERB.includes(player.type) && forestD(player.pos.x, player.pos.z) < 0.5 && trailDist(player.pos.x, player.pos.z) > 1.3) return { kind: 'graze', label: 'Graze', hold: 0.5, repeat: true };
  if (human && SAVE.inv.berries > 0 && player.hunger < 92) return { kind: 'eat', label: 'Eat berries', sub: `×${SAVE.inv.berries}`, hold: 0.6 };
  if (t) return { kind: 'scan', label: 'Scan', sub: t.spec.name, target: t, hold: 1.0 };
  return null;
}
function scanTarget(R, cone) {
  let best = null, bd = 1e9; const f = player.forward(tv2);
  const camF = new THREE.Vector3(); camera.getWorldDirection(camF);
  for (const c of [...all, ...birds]) {
    if (c === player || c.ko) continue;
    const d = c.pos.distanceTo(player.pos); if (d > R) continue;
    tv.copy(c.pos).sub(camera.position).normalize();
    if (tv.dot(camF) < Math.cos(cone)) continue;
    if (d < bd) { bd = d; best = c; }
  }
  return best;
}
function ctxTap() {
  if (!ctxNow) return;
  if (ctxNow.kind === 'place') placeGhost();
  else if (ctxNow.kind === 'ride') { mountHorse(ctxNow.target); ctxNow = null; }
  else if (ctxNow.kind === 'dismount') { if (player._rideW >= 1) dismountHorse(false); ctxNow = null; }
}
function completeContext(cx) {
  const inv = SAVE.inv, p = cx.prop;
  switch (cx.kind) {
    case 'scan': {
      const t = cx.target, first = !SAVE.journal[t.type];
      SAVE.journal[t.type] = (SAVE.journal[t.type] || 0) + 1; saveSoon(); live?.stat('scans');
      fx.burst('scan', t.center, { n: 22 }); audio.play(first ? 'unlock' : 'scan');
      gainXP(first ? CFG.xp.gain.scanNew : CFG.xp.gain.scan, first ? 'new species' : 'sighting');
      if (first) { toast(`New species: ${t.spec.name}`, true); if (!STARTERS.includes(t.type)) toast('Unlocked to play in the Field kit'); checkSkinUnlocks(); } else toast(`${t.spec.name} sighting #${SAVE.journal[t.type]}`);
      $('jCount').textContent = scannedCount(); buildPlayRow(); buildJournal();
      break;
    }
    case 'chop': p.alive = false; world.refreshItem(p); audio.play('timber'); fx.burst('leaves', tv.set(p.x, p.y + 4 * p.s, p.z), { n: 30, k: 2 }); fx.burst('chips', tv.set(p.x, p.y + 1, p.z), { n: 14 }); addRes('wood', p.kind === 'pine' ? 4 : 5); regrow(p, 240); break;
    case 'mine': addRes('stone', 2); audio.play('mine'); fx.burst('stone', tv.set(p.x, p.y + 0.4, p.z)); p.uses = (p.uses || 0) + 1; if (p.uses >= 3) { p.alive = false; world.refreshItem(p); regrow(p, 300); } break;
    case 'gather': if (p.kind === 'reed') addRes('fiber', 2); else addRes('wood', 3); p.alive = false; world.refreshItem(p); audio.play('pick'); regrow(p, 200); break;
    case 'berries': p.picked = simTime + 90; fx.burst('berry', tv.set(p.x, p.y + 0.6, p.z)); if (player.spec.kind === 'human') { addRes('berries', 3); audio.play('pick'); } else { player.hunger = Math.min(100, player.hunger + 22); audio.play('eat'); toast('Tasty'); } break;
    case 'eat': inv.berries--; player.hunger = Math.min(100, player.hunger + 14); player.hp = Math.min(player.maxHp, player.hp + 4); audio.play('eat'); break;
    case 'drink': FLAGS.drink = 1; if (SAVE.quest.rode) { SAVE.quest.drank = 1; store.set('quest', SAVE.quest); } if (player.mount) player.mount.sta = 100; SAVE.water = Math.max(SAVE.water, CFG.thirst.drinkTo); thirstWarned = false; player.sta = 100; player.hunger = Math.min(100, player.hunger + 6); fx.burst('splash', tv.copy(player.pos).setY(POND.y + 0.05)); audio.play('splash'); toast('Refreshed'); break;
    case 'graze': FLAGS.graze = 1; player.hunger = Math.min(100, player.hunger + 7); audio.play('eat', 0.6); break;
    case 'rest': player.hp = Math.min(player.maxHp, player.hp + 6); player.sta = Math.min(100, player.sta + 10); break;
    case 'signal': { const need = QUESTS.find(q => q.id === 'wood').need; SAVE.inv.wood -= need; SAVE.quest.lit = 1; store.set('quest', SAVE.quest); lightSignal(false); toast('The signal fire is lit. Smoke rises over the valley.', true); break; }
    case 'whistle': { const h = cx.horse; audio.play('whistle'); toast(`You whistle for ${h.horseName}`); h.state = 'come'; h.timer = 40; setTimeout(() => audio.play('whinny', vol(h) * 0.8 + 0.2), 700); break; }
  }
  saveSoon(); refreshCraft();
}
function regrow(p, sec) { setTimeout(() => { p.alive = true; p.uses = 0; world.refreshItem(p); }, sec * 1000); }
function updateCtxMark() {
  const el = $('ctxMark'), cx = ctxNow, tr = $('trust');
  if (cx?.kind === 'calm' && !$('ctx').hidden) { const h = cx.target; tv.copy(h.center).setY(h.pos.y + h.height * 1.08 + 0.2).project(camera);
    if (tv.z < 1) { tr.hidden = false; tr.style.left = ((tv.x + 1) / 2 * innerWidth).toFixed(0) + 'px'; tr.style.top = ((1 - tv.y) / 2 * innerHeight).toFixed(0) + 'px'; tr.style.setProperty('--p', (h.trust || 0).toFixed(3)); el.hidden = true; return; } }
  tr.hidden = true;
  if (!cx || (!cx.prop && !cx.target) || $('ctx').hidden) { el.hidden = true; return; }
  if (cx.target) { const t = cx.target; tv.copy(t.center).setY(t.pos.y + (t.height || 0.5) * 1.15 + 0.15); }
  else { const p = cx.prop; tv.set(p.x, p.y + (p.kind === 'pine' || p.kind === 'hard' ? 2.2 : 1.0) * p.s + 0.3, p.z); }
  tv.project(camera); if (tv.z > 1) { el.hidden = true; return; }
  el.hidden = false; el.style.left = ((tv.x + 1) / 2 * innerWidth).toFixed(0) + 'px'; el.style.top = ((1 - tv.y) / 2 * innerHeight).toFixed(0) + 'px';
}
let calmT = 0;
function updateContext(dt) {
  const cx = findContext();
  if (ctxNow?.kind === 'calm' && cx?.target !== ctxNow.target) ctxNow.target.calming = false;
  const same = ctxNow && cx && cx.kind === ctxNow.kind && cx.prop === ctxNow.prop && cx.target === ctxNow.target;
  if (!same) { ctxNow = cx; ctxProg = 0; }
  const el = $('ctx');
  if (!cx || document.body.classList.contains('photo')) { el.hidden = true; return; }
  el.hidden = false; $('ctxLabel').textContent = cx.label + (TOUCH ? '' : ' (F)'); $('ctxSub').textContent = cx.sub ? ' ' + cx.sub : '';
  if (cx.kind === 'calm') { const h = cx.target; h.calming = input.ctxHeld; calmT = input.ctxHeld ? calmT + dt : 0;
    if (input.ctxHeld) { h.trust = Math.min(1, (h.trust || 0) + dt / cx.hold); player.wantSpeed = 0; player.wantYaw = angTo(player.pos, h.pos);
      if (h.trust > 0.5 && !h._nick) { h._nick = true; audio.play('nicker', vol(h)); } if (rnd() < dt * 3) fx.burst('scan', tv.copy(h.center).setY(h.pos.y + h.height * 0.95), { n: 1 }); }
    ctxProg = h.trust || 0; $('ctxProg').style.width = (ctxProg * 100) + '%';
    if (h.trust >= 1) { tameHorse(h); ctxNow = null; input.ctxHeld = TOUCH ? false : input.ctxHeld; }
    return; }
  if (input.ctxHeld && cx.hold > 0) {
    ctxProg += dt / cx.hold;
    if (cx.kind === 'graze' || cx.kind === 'drink') player.state = 'graze';
    if (cx.kind === 'chop' || cx.kind === 'mine') { chopT -= dt; player.wantYaw = angTo(player.pos, cx.prop); if (chopT < 0) { chopT = 0.55; player.startAction(0, false); setTimeout(() => { audio.play(cx.kind === 'chop' ? 'chop' : 'mine'); fx.burst(cx.kind === 'chop' ? 'chips' : 'stone', tv.set(cx.prop.x, cx.prop.y + 1, cx.prop.z), { n: 5 }); }, 160); } }
    if (cx.kind === 'scan' && rnd() < dt * 12) fx.burst('scan', cx.target.center, { n: 2 });
    if (ctxProg >= 1) { completeContext(cx); ctxProg = cx.repeat ? 0 : 0; if (!cx.repeat) { ctxNow = null; input.ctxHeld = TOUCH ? false : input.ctxHeld && false; } }
  } else { ctxProg = Math.max(0, ctxProg - dt); if (player && player.state === 'graze' && player.speed < 0.1 && !input.ctxHeld) player.state = 'idle'; }
  $('ctxProg').style.width = (ctxProg * 100) + '%';
}

// ---------- crafting + hotbar + building ----------
const RECIPES = [
  { id: 'axe', name: 'Stone axe', cost: { wood: 3, stone: 2, fiber: 2 }, note: 'Chops and mines twice as fast; harder punches.' },
  { id: 'spear', name: 'Spear', cost: { wood: 2, stone: 1, fiber: 1 }, note: 'Pole jab hits much harder.' },
  { id: 'torch', name: 'Torch', cost: { wood: 1, fiber: 1 }, note: 'Lights the night. Wolves keep their distance.' },
  { id: 'campfire', name: 'Campfire', cost: { wood: 5, stone: 3 }, note: 'Rest to heal. Predators stay away.', place: true },
  { id: 'shelter', name: 'Lean-to shelter', cost: { wood: 10, fiber: 6 }, note: 'Rest inside to skip to morning.', place: true },
  { id: 'fence', name: 'Fence section', cost: { wood: 4 }, note: 'Blocks animals. Build a corral.', place: true },
];
const canAfford = r => Object.entries(r.cost).every(([k, v]) => SAVE.inv[k] >= v);
function craft(r) { if (!canAfford(r)) return; for (const [k, v] of Object.entries(r.cost)) SAVE.inv[k] -= v; SAVE.inv[r.id]++; live?.stat('crafted'); gainXP(CFG.xp.gain.craft, 'crafted'); audio.play('craft'); toast(`Crafted ${r.name}`); saveSoon(); refreshCraft(); buildHotbar(); }
function refreshCraft() {
  const inv = SAVE.inv;
  $('invGrid').innerHTML = ''; for (const k of ['wood', 'stone', 'fiber', 'berries']) { const d = document.createElement('div'); d.innerHTML = `<b></b>${k} <small>/ ${carryCap()}</small>`; d.firstChild.textContent = inv[k]; $('invGrid').appendChild(d); }
  const R = $('recipes'); R.innerHTML = '';
  for (const r of RECIPES) { const row = document.createElement('div'); row.className = 'recipe';
    row.innerHTML = `<div class="t"></div><div class="c"></div><button class="chip-btn on" type="button">Craft</button>`;
    row.querySelector('.t').textContent = r.name + (inv[r.id] ? `  ·  have ${inv[r.id]}` : '');
    row.querySelector('.c').textContent = Object.entries(r.cost).map(([k, v]) => `${v} ${k}`).join(' · ') + ' — ' + r.note;
    const b = row.querySelector('button'); b.disabled = !canAfford(r); b.onclick = () => craft(r); R.appendChild(row); }
  if (player?.spec.kind === 'human') buildHotbar();
}
function hotSlots() {
  const inv = SAVE.inv, s = [{ id: 'hands', label: 'Hands', icon: '✋' }];
  if (inv.axe) s.push({ id: 'axe', label: 'Axe', icon: 'A' }); if (inv.spear) s.push({ id: 'spear', label: 'Spear', icon: 'S' }); if (inv.torch) s.push({ id: 'torch', label: 'Torch', icon: 'T' });
  for (const k of ['campfire', 'shelter', 'fence']) if (inv[k]) s.push({ id: k, label: { campfire: 'Fire', shelter: 'Shelter', fence: 'Fence' }[k], icon: k[0].toUpperCase(), n: inv[k], place: true });
  return s;
}
function buildHotbar() {
  const hb = $('hotbar'), human = player?.spec.kind === 'human' && !player.mount; hb.hidden = !human; if (!human) return;
  hb.innerHTML = '';
  for (const s of hotSlots()) { const b = document.createElement('button'); b.type = 'button'; b.className = 'slot' + (equipped === s.id || buildGhost?.kind === s.id ? ' on' : ''); b.innerHTML = `<b></b>${s.label}${s.n ? `<em>${s.n}</em>` : ''}`; b.firstChild.textContent = s.icon; b.onclick = () => selectSlot(s.id); hb.appendChild(b); }
}
let torchLight = null, torchMesh = null;
function selectSlot(id) {
  audio.play('ui');
  if (['campfire', 'shelter', 'fence'].includes(id)) { if (buildGhost?.kind === id) cancelBuild(); else startBuild(id); }
  else { cancelBuild(); equipped = id; updateTorch(); }
  buildHotbar(); refreshActions();
}
function updateTorch() {
  const on = equipped === 'torch' && player?.spec.kind === 'human';
  if (on && !torchMesh) { torchMesh = new THREE.Group(); const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.5, 6), new THREE.MeshStandardMaterial({ color: 0x5a4030 })); stick.position.y = 0.1; const fl = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.18, 8), new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false })); fl.position.y = 0.42; torchLight = new THREE.PointLight(0xff9a40, 5, 12, 1.5); torchLight.position.y = 0.5; torchMesh.add(stick, fl, torchLight); }
  if (torchMesh) { if (torchMesh.parent) torchMesh.parent.remove(torchMesh); if (on) { player.b.handR.add(torchMesh); torchMesh.position.set(0.03, -0.06, 0); } }
}
function startBuild(kind) { cancelBuild(); const g = makeBuild(kind); g.traverse(o => { if (o.isMesh) { o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = 0.55; o.castShadow = false; } if (o.isLight) o.intensity = 0; }); scene.add(g); buildGhost = { kind, g }; $('ghost').hidden = false; }
function cancelBuild() { if (buildGhost) { scene.remove(buildGhost.g); buildGhost = null; } $('ghost').hidden = true; }
function updateGhost() { if (!buildGhost || !player) return; const f = player.forward(tv); const x = player.pos.x + f.x * 3, z = player.pos.z + f.z * 3; buildGhost.g.position.set(x, terrainH(x, z), z); buildGhost.g.rotation.y = player.yaw + Math.PI / 2; }
function placeGhost() { if (!buildGhost) return; const k = buildGhost.kind; if (SAVE.inv[k] <= 0) return cancelBuild(); const p = buildGhost.g.position; shareBuild(k, p.x, p.z, buildGhost.g.rotation.y); live?.stat('builds'); gainXP(CFG.xp.gain.build, 'built'); SAVE.inv[k]--; audio.play('craft'); fx.burst('dust', p.clone().setY(p.y + 0.1), { n: 14 }); toast(`Built ${k}`); if (SAVE.inv[k] <= 0) cancelBuild(); buildHotbar(); saveSoon(); }

// ---------- camera ----------
const camTarget = new THREE.Vector3(), camPos = new THREE.Vector3();
function updateCamera(dt) {
  if (story.on && storyCamera(dt)) return;
  const focus = followT || player?.mount || player, riding = !followT && !!player?.mount;
  if (camMode === 'free') {
    const m = moveVec(), fwd = new THREE.Vector3(-Math.sin(freeCam.yaw) * Math.cos(freeCam.pitch), Math.sin(freeCam.pitch), -Math.cos(freeCam.yaw) * Math.cos(freeCam.pitch));
    const sp = (input.run ? 22 : 8) * dt; freeCam.pos.addScaledVector(new THREE.Vector3(m.x, 0, m.z), sp * m.mag);
    if (input.jumpHeld) freeCam.pos.y += sp; if (input.down) freeCam.pos.y -= sp;
    freeCam.pos.y = Math.max(freeCam.pos.y, terrainH(freeCam.pos.x, freeCam.pos.z) + 0.6);
    camera.position.copy(freeCam.pos); camera.lookAt(tv.copy(freeCam.pos).add(fwd)); return;
  }
  if (!focus) return;
  const H = focus.spec.kind === 'bird' ? 0.5 : focus.height;
  if (!camDist) camDist = 2.6 + H * 2.6;
  camTarget.lerp(tv.copy(focus.spec.kind === 'bird' ? focus.pos : focus.center).add(tv2.set(0, H * 0.15 + (riding ? CFG.ride.camUp : 0), 0)), 1 - Math.exp(-10 * dt));
  if (camMode === 'orbit') camYaw += dt * 0.12;
  else if (focus.speed > 0.6 && simTime - lastManual > 1.6) { const behind = Math.atan2(-Math.cos(focus.yaw), Math.sin(focus.yaw)); camYaw += angDiff(behind, camYaw) * (1 - Math.exp(-1.2 * dt)); }
  // smoothing: input sets camYaw/camPitch directly; the view eases toward them, so touch drags and recentring never jitter
  if (!camS.ready) { camS.ready = true; camS.yaw = camYaw; camS.pitch = camPitch; camS.dist = camDist; camS.look.copy(camTarget); camS.fov = camera.fov; }
  const kr = 1 - Math.exp(-(TOUCH ? 16 : 22) * dt);
  camS.yaw += angDiff(camYaw, camS.yaw) * kr; camS.pitch += (camPitch - camS.pitch) * kr;
  // keep trunks out of the way: pull in in front of any tree between the target and the camera, ease back out afterwards
  const cp = Math.cos(camS.pitch), dirx = Math.sin(camS.yaw) * cp, dirz = Math.cos(camS.yaw) * cp;
  let D = camDist;
  for (const tr of world.nearTrees(camTarget.x + dirx * D * 0.5, camTarget.z + dirz * D * 0.5)) {
    const ox = tr.x - camTarget.x, oz = tr.z - camTarget.z, along = (ox * dirx + oz * dirz) / Math.max(1e-4, Math.hypot(dirx, dirz));
    if (along <= 0.3 || along > D) continue;
    const off = Math.abs(ox * dirz - oz * dirx) / Math.max(1e-4, Math.hypot(dirx, dirz));
    if (off < tr.r + 0.15 && tr.r > 0.12) D = Math.min(D, Math.max(1.6, along - tr.r - 0.35));
  }
  camS.dist += (D - camS.dist) * (1 - Math.exp(-(D < camS.dist ? 14 : 2.5) * dt));
  // light look-ahead in the direction of travel
  const la = clamp(focus.speed * 0.08, 0, 0.6), fw = focus.forward ? focus.forward(tv2) : tv2.set(0, 0, 0);
  camS.look.lerp(tv.copy(camTarget).addScaledVector(fw, la), 1 - Math.exp(-6 * dt));
  camPos.set(camS.look.x + Math.sin(camS.yaw) * cp * camS.dist, camS.look.y + Math.sin(camS.pitch) * camS.dist, camS.look.z + Math.cos(camS.yaw) * cp * camS.dist);
  const floorY = terrainH(camPos.x, camPos.z) + 0.4; camS.floor = camS.floor == null ? floorY : camS.floor + (floorY - camS.floor) * (1 - Math.exp(-10 * dt));
  camPos.y = Math.max(camPos.y, camS.floor);
  if (shake > 0) { const k = shake * 0.25; camPos.x += (Math.sin(simTime * 61) + Math.sin(simTime * 37)) * k * 0.5; camPos.y += Math.sin(simTime * 53) * k * 0.6; shake = Math.max(0, shake - dt * 2.2); }
  camera.position.copy(camPos); camera.lookAt(camS.look);
  // speed sense: the lens widens a touch at a full run
  const fov0 = innerWidth / innerHeight < 0.8 ? 62 : 50, runK = clamp((focus.speed - 4) / 6, 0, 1);
  camS.fov += (fov0 + (riding ? CFG.ride.fovGallop : 6) * runK - camS.fov) * (1 - Math.exp(-3 * dt)); if (Math.abs(camera.fov - camS.fov) > 0.01) { camera.fov = camS.fov; camera.updateProjectionMatrix(); }
}
const camS = { yaw: 2.4, pitch: 0.26, dist: 6, look: new THREE.Vector3(), floor: null, fov: 50 };

// ---------- UI ----------
const STATE_LABEL = { idle: 'Standing', graze: 'Grazing', wander: 'Wandering', flee: 'Fleeing', alert: 'On alert', chase: 'Chasing', rest: 'Resting', walk: 'Walking the trail', photo: 'Taking a photo', wary: 'Backing away', move: 'Moving', fight: 'Fighting', down: 'Knocked out', drink: 'Drinking', bed: 'Bedded down', spar: 'Sparring', ridden: 'Carrying a rider', come: 'Coming to you' };
function stateOf(c) {
  if (c.spec.kind === 'bird') return [c === player ? 'Flying' : flockMode === 'land' ? 'Feeding' : 'Flying', ''];
  if (c.ko) return ['Knocked out', 'flee'];
  if (c.mount) { const h = c.mount, s = h.speed; return [h.air > 0.05 ? 'Riding · leaping' : s < 0.2 ? 'Riding · standing' : 'Riding · ' + ['walk', 'trot', 'gallop'][h.gait], s > 6 ? 'alert' : '']; }
  if (c.air > 0.05) return ['Leaping', 'alert'];
  if (c.act) return [c.act.m.label, 'alert'];
  if (c === player && c.state !== 'photo' && c.state !== 'graze') { const s = c.speed, k = c.spec.kind; const g = k === 'human' ? (s > 2.4 ? 'Running' : s > 0.2 ? 'Walking' : 'Standing') : k === 'rabbit' ? (s > 0.3 ? 'Hopping' : 'Sitting') : s < 0.2 ? 'Standing' : ['Walking', 'Trotting', 'Galloping'][c.gait]; return [g, s > 6 ? 'alert' : '']; }
  const l = STATE_LABEL[c.state] || 'Standing';
  return [c.spec.role === 'predator' && c.state === 'graze' ? 'Sniffing around' : l, c.state === 'flee' || c.state === 'fight' ? 'flee' : c.state === 'alert' || c.state === 'chase' || c.state === 'spar' ? 'alert' : ''];
}
function setState(el, c) { const [t, cls] = stateOf(c); if (el.textContent !== t) el.textContent = t; el.className = 'state' + (cls ? ' ' + cls : ''); }
let cardFor = null;
function showCard(c) {
  cardFor = c; $('cardName').textContent = c.spec.name + (SAVE.journal[c.type] ? '' : ' (unscanned)'); $('cardLatin').textContent = c.spec.latin; $('card').hidden = false;
  $('cardPlay').hidden = c === player || c.ko; $('cardPlay').textContent = unlocked(c.type) ? 'Play as' : 'Scan to unlock'; $('cardPlay').disabled = !unlocked(c.type);
}
function hideCard() { $('card').hidden = true; cardFor = null; }
$('cardClose').onclick = hideCard;
$('cardFollow').onclick = () => { followT = cardFor === player ? null : cardFor; setCam('follow'); camDist = 0; hideCard(); refreshWho(); };
$('cardPlay').onclick = () => { if (unlocked(cardFor.type)) control(cardFor); hideCard(); };
function control(c) {
  if (!c || c.ko || c.rider) return; cancelBuild();
  if (player?.mount) dismountHorse(false);
  if (player) { player.state = player.spec.kind === 'human' ? 'walk' : 'idle'; player.timer = 1; if (player.spec.kind === 'human') { equipped = 'hands'; updateTorch(); } }
  player = c; applyPerks(c); followT = null; c.state = 'idle'; c.target = null; camDist = 0; if (camMode === 'free') setCam('follow');
  refreshWho(); buildPlayRow(); refreshActions(); buildHotbar(); $('craftBtn').hidden = c.spec.kind !== 'human';
}
function refreshWho() { const f = followT || player; if (!f) return; $('whoRole').textContent = followT ? 'Following' : 'Playing as'; $('whoName').textContent = f.spec.name; $('portraitTxt').textContent = f.spec.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase(); refreshGoals(); }
const MOVE_ICON = { punch: 'm-fist', lowkick: 'm-kick', knee: 'm-burst', pole: 'm-spear', charge: 'm-horns', butt: 'm-horns', kick: 'm-hoof', buck: 'm-hoof', rear: 'm-hoof', snort: 'm-wave', whinny: 'm-wave', bugle: 'm-wave', howl: 'm-wave', yip: 'm-wave', thump: 'm-wave', bite: 'm-fang', pounce: 'm-fang', dash: 'm-up', peck: 'm-up' };
function refreshActions() {
  if (!player) return; const mv = MOVES[player.type] || [], k = player.spec.kind, human = k === 'human';
  const set = (id, t, icon) => { const sp = $(id).firstChild; sp.innerHTML = icon ? '<svg aria-hidden="true"><use href="#' + icon + '"/></svg><em></em>' : '<em></em>'; sp.lastChild.textContent = t || '—'; };
  if (player.mount) { const hm = MOVES.horse; set('a0', hm[1].label, MOVE_ICON.rear); set('a1', hm[2].label, MOVE_ICON.whinny); $('a2').hidden = true; set('a3', hm[0].label, MOVE_ICON.buck); set('aj', 'Leap', 'm-up'); return; }
  set('a0', human && equipped === 'axe' ? 'Axe swing' : mv[0]?.label, human && equipped === 'axe' ? 'm-axe' : MOVE_ICON[mv[0]?.id]);
  set('a1', mv[1]?.label, MOVE_ICON[mv[1]?.id]);
  $('a2').hidden = !human; if (human) set('a2', SAVE.inv.spear ? 'Spear thrust' : mv[2]?.label, SAVE.inv.spear ? 'm-spear' : MOVE_ICON[mv[2]?.id]);
  set('a3', human ? (player.state === 'photo' ? 'Lower camera' : 'Photo') : mv[2]?.label, human ? 'i-camera' : MOVE_ICON[mv[2]?.id]);
  set('aj', k === 'bird' ? 'Climb' : k === 'hoofed' ? 'Leap' : 'Jump', 'm-up');
  if (k === 'bird') { set('a0', 'Dive', 'm-up'); set('a1', 'Dive', 'm-up'); set('a3', 'Dive', 'm-up'); }
}
function togglePanel(id, force) {
  for (const p of ['kit', 'journal', 'craft', 'live']) if (p !== id) $(p).hidden = true;
  const el = $(id), open = force ?? el.hidden; el.hidden = !open;
  document.body.classList.toggle('panelopen', open);
  if (open) { if (id === 'kit') buildPlayRow(); if (id === 'journal') buildJournal(); if (id === 'craft') refreshCraft(); if (id === 'live') refreshLive(); }
  for (const [p, b] of [['kit', 'kitBtn'], ['journal', 'journalBtn'], ['craft', 'craftBtn'], ['live', 'liveBtn']]) $(b).classList.toggle('on', !$(p).hidden);
}
function closePanels() { for (const p of ['kit', 'journal', 'craft', 'live']) $(p).hidden = true; document.body.classList.remove('panelopen'); for (const b of ['kitBtn', 'journalBtn', 'craftBtn', 'liveBtn']) $(b).classList.remove('on'); }
document.querySelectorAll('[data-close]').forEach(b => b.onclick = () => togglePanel(b.dataset.close, false));
let menuT = 0;
function setMenu(open) { document.body.classList.toggle('menuopen', open); $('menuBtn').setAttribute('aria-expanded', open); clearTimeout(menuT); if (open) menuT = setTimeout(() => setMenu(false), 6000); }
$('menuBtn').onclick = () => { audio.play('ui'); setMenu(!document.body.classList.contains('menuopen')); };
$('topbar').addEventListener('click', () => setTimeout(() => setMenu(false), 150));
$('kitBtn').onclick = () => togglePanel('kit'); $('journalBtn').onclick = () => togglePanel('journal'); $('craftBtn').onclick = () => togglePanel('craft'); $('liveBtn').onclick = () => togglePanel('live');
function buildPlayRow() {
  const row = $('playRow'); row.textContent = '';
  const groups = new Map(); for (const c of [...all, ...birds]) { if (c.ko) continue; if (!groups.has(c.type)) groups.set(c.type, []); groups.get(c.type).push(c); }
  for (const [t, list] of groups) {
    const b = document.createElement('button'); b.type = 'button'; const ok = unlocked(t); b.className = 'tag-btn' + (player && player.type === t ? ' on' : '') + (ok ? '' : ' locked');
    b.innerHTML = '<span></span><span class="n"></span>'; b.firstChild.textContent = (ok ? '' : '🔒 ') + CAT[t].name; b.lastChild.textContent = list.length;
    b.onclick = () => { if (!ok) { toast(`Scan a ${CAT[t].name} first`); return; } const i = player && player.type === t ? (list.indexOf(player) + 1) % list.length : 0; control(list[i]); if (innerWidth < 640) togglePanel('kit', false); };
    row.appendChild(b);
  }
}
function buildJournal() {
  const L = $('jList'); L.innerHTML = ''; $('jCount').textContent = scannedCount();
  const order = ['athlete', 'buck', 'wbuck', 'doe', 'fawn', 'elk', 'cow', 'horse', 'wolf', 'fox', 'rabbit', 'hiker', 'bird'];
  const head = document.createElement('p'); head.className = 'hint'; head.innerHTML = `<span class="count">${scannedCount()} / ${order.length}</span> species recorded`; L.appendChild(head);
  for (const t of order) {
    const known = !!SAVE.journal[t], d = document.createElement('div'); d.className = 'species' + (known ? '' : ' unknown');
    d.innerHTML = `<div class="t"></div><div class="l"></div>${known ? '<div class="f"></div><div class="row"></div>' : ''}`;
    d.querySelector('.t').textContent = known ? `${CAT[t].name} · ${SAVE.journal[t]} seen` : 'Unrecorded species';
    d.querySelector('.l').textContent = known ? CAT[t].latin : 'Find it and hold Scan';
    if (known) {
      d.querySelector('.f').textContent = FACTS[t].join(' ');
      const row = d.querySelector('.row');
      for (const [coat, label, need] of SKINS[t] || []) {
        const ok = skinUnlocked(need), b = document.createElement('button'); b.type = 'button';
        b.className = 'tag-btn' + ((SAVE.skins[t] || SKINS[t][0][0]) === coat ? ' on' : '') + (ok ? '' : ' locked');
        b.textContent = ok ? label : `🔒 ${label} · ${typeof need === 'number' ? `scan ${need} species` : 'scan ' + CAT[need].name}`;
        b.onclick = () => { if (!ok) return; SAVE.skins[t] = coat; saveSoon(); applySkin(t, coat); buildJournal(); };
        row.appendChild(b);
      }
      if (unlocked(t) && t !== 'bird') { const pb = document.createElement('button'); pb.type = 'button'; pb.className = 'tag-btn'; pb.textContent = 'Play as'; pb.onclick = () => { const c = all.find(c => c.type === t && !c.ko); if (c) { control(c); togglePanel('journal', false); } else toast('None nearby. Release one from the Field kit.'); }; row.appendChild(pb); }
    }
    L.appendChild(d);
  }
}
const GOALS = [
  { id: 'scan', who: 'any', t: 'Scan an animal', done: () => scannedCount() >= 1 },
  { id: 'wood', who: 'human', t: 'Gather 5 wood', done: () => SAVE.inv.wood >= 5, prog: () => `${Math.min(5, SAVE.inv.wood)}/5` },
  { id: 'axe', who: 'human', t: 'Craft a stone axe', done: () => SAVE.inv.axe > 0 },
  { id: 'fire', who: 'human', t: 'Build a campfire', done: () => builds.some(b => b.kind === 'campfire') },
  { id: 'drink', who: 'animal', t: 'Drink at the pond', done: () => !!FLAGS.drink },
  { id: 'graze', who: 'animal', t: 'Graze to refill food', done: () => !!FLAGS.graze },
  { id: 'scan3', who: 'any', t: 'Record 3 species', done: () => scannedCount() >= 3, prog: () => `${Math.min(3, scannedCount())}/3` },
  { id: 'night', who: 'any', t: 'Make it through a night', done: () => !!FLAGS.night },
];
SAVE.goals = store.get('goals', {}); const FLAGS = {};
let nightSeen = false, goalSig = '', goalT = 0;
function refreshGoals() {
  if (!player || !$('goalList')) return; const human = player.spec.kind === 'human';
  let changed = false;
  for (const g of GOALS) if (!SAVE.goals[g.id] && g.done()) { SAVE.goals[g.id] = 1; changed = true; if (window.__ready) { toast(`Goal complete: ${g.t}`, true); audio.play('unlock'); } }
  if (changed) store.set('goals', SAVE.goals);
  const q = human ? curQuest() : null; $('goals').classList.toggle('quest', !!q);
  if (q) { $('goals').hidden = !window.__ready; $('goals').querySelector('.gh').textContent = `Frontier · ${SAVE.quest.i + 1} of ${QUESTS.length}`;
    const L = $('goalList'), pr = questProg(q), sig = q.id; if (sig !== goalSig) { goalSig = sig; $('goals').classList.remove('fade'); clearTimeout(goalT); goalT = setTimeout(() => $('goals').classList.add('fade'), 9000); }
    if (!L.firstChild || L.firstChild.dataset.q !== q.id) { L.textContent = ''; const d = document.createElement('div'); d.className = 'goal cur'; d.dataset.q = q.id; d.innerHTML = '<span></span><small></small>'; d.firstChild.textContent = q.title; L.appendChild(d); }
    L.firstChild.lastChild.textContent = pr; return; }
  $('goals').querySelector('.gh').textContent = 'Field goals';
  const list = GOALS.filter(g => g.who === 'any' || (g.who === 'human') === human);
  const open = list.filter(g => !SAVE.goals[g.id]);
  $('goals').hidden = !open.length || !window.__ready;
  const L = $('goalList'); const sig = (open[0]?.id || '') + (open[0]?.prog ? open[0].prog() : ''); if (sig !== goalSig) { goalSig = sig; $('goals').classList.remove('fade'); clearTimeout(goalT); goalT = setTimeout(() => $('goals').classList.add('fade'), 7000); } L.textContent = '';
  const cur = open[0]; const show = [...list.filter(g => SAVE.goals[g.id]).slice(-1), ...open.slice(0, 3)];
  for (const g of show) { const d = document.createElement('div'); d.className = 'goal' + (SAVE.goals[g.id] ? ' done' : g === cur ? ' cur' : ''); d.innerHTML = '<span></span><small></small>'; d.firstChild.textContent = g.t; d.lastChild.textContent = !SAVE.goals[g.id] && g.prog ? g.prog() : ''; L.appendChild(d); }

}
function checkSkinUnlocks() { for (const [t, list] of Object.entries(SKINS)) for (const [coat, label, need] of list) if (need && typeof need === 'number' && scannedCount() === need) toast(`Skin unlocked: ${label} ${CAT[t].name}`); }
function applySkin(type, coat) {
  if (!player || player.type !== type) { toast('Skin saved. It applies when you play this species.'); return; }
  const old = player, c = spawn(type, old.pos.x, old.pos.z, { yaw: old.yaw, coat: coat === 'human' ? undefined : coat });
  if (!c) return; c.hp = old.hp; c.sta = old.sta; c.hunger = old.hunger;
  all.splice(all.indexOf(old), 1); old.dispose(); control(c); toast('Skin applied'); audio.play('unlock');
}
for (const name of Object.keys(SPAWNS)) { const b = document.createElement('button'); b.type = 'button'; b.className = 'tag-btn'; b.textContent = '+ ' + name; b.onclick = () => { SPAWNS[name](); setTimeout(buildPlayRow, 400); }; $('spawnRow').appendChild(b); }
const TOD = { Dawn: 6.3, Noon: 13, 'Golden hour': 17.6, Dusk: 19.4, Night: 22.5 };
for (const [n, h] of Object.entries(TOD)) { const b = document.createElement('button'); b.type = 'button'; b.className = 'tag-btn'; b.textContent = n; b.onclick = () => { $('tod').value = h; onTod(); }; $('todRow').appendChild(b); }
const fmtH = h => { const H = Math.floor(h) % 24, M = Math.floor((h - Math.floor(h)) * 60) % 60; return `${(H % 12) || 12}:${String(M).padStart(2, '0')} ${H < 12 ? 'am' : 'pm'}`; };
function onTod() { world.env.hour = +$('tod').value; $('todOut').textContent = fmtH(world.env.hour); world.applyTime(); }
$('tod').oninput = onTod;
$('mist').oninput = () => { world.env.mist = world.env.tgt.mist = +$('mist').value; $('mistOut').textContent = Math.round(world.env.mist * 100) + '%'; world.applyTime(); };
$('wind').oninput = () => { world.env.wind = +$('wind').value; const w = world.env.wind; $('windOut').textContent = w < 0.15 ? 'Still' : w < 0.55 ? 'Breeze' : w < 0.8 ? 'Windy' : 'Gusty'; };
const seg = (id, fn) => { for (const b of $(id).children) b.onclick = () => { for (const o of $(id).children) o.classList.toggle('on', o === b); fn(b.dataset.v); audio.play('ui'); }; };
seg('clockSeg', v => timeScale = +v);
seg('camSeg', v => setCam(v));
function setWeather(v, instant) {
  const E = world.env, T = E.tgt, winter = E.season === 'winter';
  Object.assign(T, { cloud: 0.35, rain: 0, snow: winter ? 1 : 0, fall: winter ? 0.2 : 0, mist: E.weather === 'fog' ? 0.09 : T.mist });
  if (v === 'cloudy') T.cloud = 0.85; if (v === 'rain') { T.rain = 1; T.cloud = 1; T.fall = 1; } if (v === 'fog') { T.mist = 0.9; $('mist').value = 0.9; $('mistOut').textContent = '90%'; T.cloud = 0.6; }
  if (v === 'snow') { T.snow = 1; T.cloud = 0.9; T.fall = 0.6; }
  if (v !== 'fog' && E.weather === 'fog') { $('mist').value = T.mist; $('mistOut').textContent = Math.round(T.mist * 100) + '%'; }
  wx.U.uSnow.value = v === 'snow' || winter ? 1 : 0;
  E.weather = v; if (instant) { for (const k of Object.keys(T)) E[k] = T[k]; E.wet = T.rain; } world.applyTime();
}
seg('wxSeg', setWeather);
seg('seasonSeg', v => { const E = world.env; E.season = v; E.autumn = v === 'autumn' ? 1 : 0; setWeather(E.weather || 'clear'); world.refreshEnv(); });
seg('fpsSeg', v => { fpsCap = +v; store.set('fpsCap', fpsCap); store.set('fpsCapSet', true); tuneGood = 0; tuneHold = 1; toast(fpsCap ? `Frame rate capped at ${fpsCap} fps` + ': steady and sharper, Auto keeps more detail' : 'Frame rate: as smooth as your device allows'); });
for (const b of $('fpsSeg').children) b.classList.toggle('on', +b.dataset.v === fpsCap);
seg('qualSeg', v => { store.set('quality', v); toast('Restarting with ' + v + ' graphics…'); setTimeout(() => location.reload(), 600); });
for (const b of $('qualSeg').children) b.classList.toggle('on', b.dataset.v === qualName);
function setCam(m) { camMode = m; for (const o of $('camSeg').children) o.classList.toggle('on', o.dataset.v === m); if (m === 'free') { freeCam.pos.copy(camera.position); const d = new THREE.Vector3(); camera.getWorldDirection(d); freeCam.yaw = Math.atan2(-d.x, -d.z); freeCam.pitch = Math.asin(d.y); } }
$('notice').onchange = e => ctx.notice = e.target.checked;
$('nightWolves').onchange = e => ctx.nightWolves = e.target.checked;
$('sound').onchange = e => { audio.start(); audio.setOn(e.target.checked); };
$('music').checked = store.get('music', true); audio.setMusic($('music').checked);
$('music').onchange = e => { audio.start(); audio.setMusic(e.target.checked); store.set('music', e.target.checked); };
function setPhoto(on) { document.body.classList.toggle('photo', on); $('shutter').hidden = !on; $('photoExit').hidden = !on; $('snap').hidden = !on; if (on) { closePanels(); hideCard(); } }
$('photoBtn').onclick = () => setPhoto(true); $('photoBtn2').onclick = () => setPhoto(true); $('photoExit').onclick = () => setPhoto(false);
$('shutter').onclick = () => { const f = $('flash'); f.style.opacity = 0.85; setTimeout(() => f.style.opacity = 0, 60); audio.play('shutter'); $('snap').textContent = 'Framed. Take a screenshot to keep it.'; };
function toast(msg, big) { const t = document.createElement('div'); t.textContent = msg; if (big) t.className = 'big'; $('toast').appendChild(t); setTimeout(() => t.remove(), big ? 3600 : 2200); while ($('toast').children.length > 3) $('toast').firstChild.remove(); }
function showKO() { $('ko').hidden = false; $('koMsg').textContent = `Your ${player.spec.name.toLowerCase()} was knocked out. Rest up and try again.`; }
$('koBtn').onclick = () => {
  $('ko').hidden = true; // wake where you fell, hurt; whoever knocked you out loses interest
  player.revive(); player.hp = Math.max(1, Math.round(player.maxHp * CFG.ko.wakeHp)); player.kv.set(0, 0, 0); player.hunger = Math.max(player.hunger, 50); SAVE.water = Math.max(SAVE.water, 20); thirstWarned = false; player.lastHit = simTime;
  for (const o of all) if (o.target === player) { o.target = null; o.state = 'flee'; o.fleeFrom = player; o.timer = CFG.ko.calmSec; o.cool = 40; }
};
document.body.classList.toggle('touch', TOUCH);
if (TOUCH) { $('stickBase').hidden = false; $('stickZone').hidden = false; $('actions').hidden = false; } else { $('actions').hidden = false; $('keys').hidden = false; setTimeout(() => $('keys').style.opacity = 0, 14000); }

// ---------- live: co-op players, shared builds, emotes, feedback, stats ----------
let live = null, sharedBuilds = false;
const peers = new Map(), localBuilds = [], netBuilds = new Map();
const COATS = new Set(Object.values(CAT).map(s => s.coat).concat(Object.values(SKINS).flat().map(s => s[0])));
const EMOTES = [['wave', 'Wave', '👋'], ['cheer', 'Cheer', '🎉'], ['follow', 'Follow me', '➜'], ['help', 'Help!', '❗']];
const num = (v, lo, hi, d = 0) => (typeof v === 'number' && isFinite(v) ? clamp(v, lo, hi) : d);
const normYaw = y => ((y % TAU) + TAU) % TAU;
function cleanNet(s) {
  if (!s || typeof s !== 'object' || typeof s.t !== 'string' || !CAT[s.t]) return null;
  const M = s.m && typeof s.m === 'object' && CAT[s.t].kind === 'human' ? s.m : null, V = M && Array.isArray(M.v) ? M.v : [];
  return { t: s.t, c: typeof s.c === 'string' && COATS.has(s.c) ? s.c : CAT[s.t].coat, x: num(s.x, -180, 180), z: num(s.z, -180, 180), y: num(s.y, 0, 8), r: num(s.r, -10, 20), s: num(s.s, 0, 30), a: typeof s.a === 'string' ? s.a.slice(0, 16) : '', k: s.k ? 1 : 0, g: num(s.g, 0, 2) | 0, hp: num(s.hp, 0, 1, 1),
    m: M ? { x: num(M.x, -180, 180), z: num(M.z, -180, 180), y: num(M.y, 0, 8), r: num(M.r, -10, 20), s: num(M.s, 0, 30), c: typeof M.c === 'string' && COATS.has(M.c) ? M.c : 'horse', v: [num(V[0], 0, 4) | 0, V[1] ? 1 : 0, num(V[2], 0, 15) | 0] } : null };
}
const horseNet = h => ({ x: +h.pos.x.toFixed(2), z: +h.pos.z.toFixed(2), y: +h.air.toFixed(2), r: +normYaw(h.yaw).toFixed(3), s: +h.speed.toFixed(2), c: h.coat, v: h.variant ? [h.variant.c, h.variant.blaze ? 1 : 0, h.variant.socks.reduce((a, b, i) => a | (b ? 1 << i : 0), 0)] : [0, 0, 0] });
const horseVariant = v => ({ c: v[0], blaze: !!v[1], socks: [0, 1, 2, 3].map(i => (v[2] >> i) & 1) });
let myAct = null, actSeq = 0, actIdx = -1;
function myNet() {
  const p = player; if (!p) return null;
  if (p.act && p.act !== myAct) { actSeq = (actSeq + 1) % 1000; const mv = MOVES[p.type] || []; actIdx = p.act.m === SPEAR_MOVE ? 3 : mv.indexOf(p.act.m); }
  myAct = p.act;
  return { t: p.type, c: p.coat || p.spec.coat, x: +p.pos.x.toFixed(2), z: +p.pos.z.toFixed(2), y: +p.air.toFixed(2), r: +normYaw(p.yaw).toFixed(3), s: +p.speed.toFixed(2), a: actIdx + ':' + actSeq, k: p.ko ? 1 : 0, g: p.state === 'graze' ? 1 : p.state === 'photo' ? 2 : 0, hp: +(p.hp / p.maxHp).toFixed(2), m: p.mount ? horseNet(p.mount) : 0 };
}
function onPeerChange(ch) {
  for (const P of [...ch.joined, ...ch.updated]) { if (P.isMe || P.kind !== 'viewer') continue; upsertPeer(P); }
  for (const P of ch.left) dropPeer(P.peer);
  refreshLiveBtn(); if (!$('live').hidden) refreshLive();
}
function upsertPeer(P) {
  const n = cleanNet(P.presence?.p);
  let e = peers.get(P.peer);
  if (!e) {
    const tag = document.createElement('div'); tag.className = 'ptag'; tag.hidden = true; tag.innerHTML = '<span></span><b></b>'; $('tags').appendChild(tag);
    e = { peer: P.peer, by: P.by || (typeof P.presence?.uid === 'string' ? P.presence.uid.slice(0, 80) : null), guest: P.guest, c: null, net: null, seen: '', tag, name: '', emote: '', emoteUntil: 0 };
    peers.set(P.peer, e); resolveNames().then(() => toast(`${e.name || 'A friend'} joined the valley`));
  }
  if (!n) return; const first = !e.net; e.net = n;
  if (!e.c || e.c.type !== n.t || e.c.coat !== n.c) makePeerBody(e);
  if (first && e.c) e.seen = n.a;
}
function dropPeer(id) { const e = peers.get(id); if (!e) return; if (e.c) forgetPeerBody(e.c); dropPeerHorse(e); e.tag.remove(); peers.delete(id); toast(`${e.name || 'A friend'} left`); }
function forgetPeerBody(c) { for (const o of all) { if (o.target === c) { o.target = null; o.state = 'rest'; o.timer = 4; } if (o.fleeFrom === c) o.fleeFrom = null; } c.dispose(); }
function makePeerBody(e) {
  const n = e.net, spec = CAT[n.t];
  if (spec.kind === 'bird') { if (e.c) { forgetPeerBody(e.c); e.c = null; } return; }
  if (!speciesReady(spec.mesh)) { if (!e.loading) { e.loading = true; loadSpecies(spec.mesh).then(() => { e.loading = false; if (peers.get(e.peer) === e && e.net) makePeerBody(e); }).catch(() => { e.loading = false; }); } return; }
  const old = e.c, c = new Creature(n.t, scene, { x: n.x, z: n.z, yaw: n.r, coat: n.c });
  c.initStats(); c.remote = e; c.pos.y = terrainH(n.x, n.z) + n.y; c.air = n.y; c.place(0);
  if (n.t === 'hiker') addHikerProps(c);
  if (old) forgetPeerBody(old); e.c = c; e.seen = n.a;
}
let names = {};
async function resolveNames() {
  if (!live) return;
  for (const e of peers.values()) if (!e.name) e.tag.lastChild.textContent = 'Hiker'; const ids = [...peers.values()].map(e => e.by).filter(Boolean); if (!ids.length) return;
  names = await live.names(ids);
  for (const e of peers.values()) { e.name = (e.by && names[e.by]?.name) || 'Hiker'; e.tag.lastChild.textContent = e.name; }
  if (!$('live').hidden) refreshLive();
}
// a friend on horseback: their horse is a remote body too; the rider sits in its saddle
function dropPeerHorse(e) { if (!e.h) return; if (e.c) e.c.unseat(e.h); if (e.h.tack?.reins) scene.remove(e.h.tack.reins); forgetPeerBody(e.h); e.h = null; }
function stepPeerHorse(e, dt, k) {
  const m = e.net.m, c = e.c;
  if (!m) { if (e.h) { dropPeerHorse(e); c.place(0); } return false; }
  if (!speciesReady('horse')) { loadSpecies('horse'); return false; }
  const key = m.c + '|' + m.v.join(',');
  if (!e.h || e.hKey !== key) { dropPeerHorse(e); e.h = new Creature('horse', scene, { x: m.x, z: m.z, yaw: m.r, coat: m.c === 'horse' ? undefined : m.c, variant: horseVariant(m.v) }); e.h.initStats(); e.h.remote = e; e.h.tamed = true; e.h.showTack(true); e.hKey = key; }
  const h = e.h, dx = m.x - h.pos.x, dz = m.z - h.pos.z;
  if (dx * dx + dz * dz > 64) { h.pos.x = m.x; h.pos.z = m.z; } else { h.pos.x += dx * k; h.pos.z += dz * k; }
  h.yaw = normYaw(h.yaw + angDiff(m.r, normYaw(h.yaw)) * k); h.wantYaw = h.yaw; h.speed += (m.s - h.speed) * k; h.wantSpeed = h.speed;
  h.air += (m.y - h.air) * k; h.pos.y = terrainH(h.pos.x, h.pos.z) + h.air;
  h.animate(dt, simTime); h.place(dt); h.setLOD(camera.position.distanceTo(h.pos) / LODK, LITE);
  c.seatOn(h, dt, simTime, 1); c.setLOD(camera.position.distanceTo(c.pos) / LODK, LITE);
  return true;
}
function stepPeers(dt) {
  const k = 1 - Math.exp(-10 * dt);
  for (const e of peers.values()) {
    const c = e.c, n = e.net; if (!c || !n) continue;
    if (stepPeerHorse(e, dt, k)) continue;
    const dx = n.x - c.pos.x, dz = n.z - c.pos.z;
    if (dx * dx + dz * dz > 64) { c.pos.x = n.x; c.pos.z = n.z; } else { c.pos.x += dx * k; c.pos.z += dz * k; }
    c.yaw = normYaw(c.yaw + angDiff(n.r, normYaw(c.yaw)) * k); c.wantYaw = c.yaw;
    c.speed += (n.s - c.speed) * k; c.wantSpeed = c.speed;
    c.air += (n.y - c.air) * k; c.pos.y = terrainH(c.pos.x, c.pos.z) + c.air;
    c.state = n.g === 1 ? 'graze' : n.g === 2 ? 'photo' : 'idle';
    if (n.k && !c.ko) c.knockOut(); else if (!n.k && c.ko) c.revive();
    if (n.a !== e.seen) {
      e.seen = n.a; const i = parseInt(n.a, 10);
      if (i >= 0 && i <= 3 && !c.ko) { c.act = null; c.cds = [0, 0, 0]; c.sta = 100; c.startAction(i === 3 ? 2 : i, false, i === 3 ? SPEAR_MOVE : undefined); }
    }
    // their swings land on the animals in YOUR valley, never on you
    c.tickCombat(dt, resolveHit);
    if (c.ko) { c.koPose(dt); c.place(dt); }
    else { c.animate(dt, simTime); if (c.overlay(dt, simTime)) c.groundContact(c._lift || 0); if (c.onAnim) c.onAnim(dt, simTime); c.place(dt); }
    c.setLOD(camera.position.distanceTo(c.pos) / LODK, LITE);
  }
}
function updateTags() {
  const now = performance.now(); if (peers.size) camera.updateMatrixWorld();
  for (const e of peers.values()) {
    const c = e.c, el = e.tag;
    if (!c || !c.group.visible || document.body.classList.contains('photo')) { el.hidden = true; continue; }
    const d = camera.position.distanceTo(c.pos);
    if (c.b?.head) { c.b.head.getWorldPosition(tv); tv.y += (c.spec.antlers ? 0.62 : c.spec.kind === 'human' ? 0.32 : 0.36) * c.S * c.size; } else tv.copy(c.pos).setY(c.pos.y + c.height + 0.3);
    tv.project(camera);
    if (tv.z > 1 || d > 80) { el.hidden = true; continue; }
    el.hidden = false;
    el.style.transform = `translate(${((tv.x + 1) / 2 * innerWidth).toFixed(1)}px, ${((1 - tv.y) / 2 * innerHeight).toFixed(1)}px) translate(-50%, -100%)`;
    el.style.opacity = d > 50 ? 0.6 : 1;
    const em = now < e.emoteUntil ? e.emote : '';
    if (el.firstChild.textContent !== em) el.firstChild.textContent = em;
  }
}
let lastStatMin = performance.now();
function livePulse(now) {
  if (!live) return;
  const s = myNet(); if (s) live.sendPresence(s, now);
  if (now - lastStatMin > 60000) { const m = (now - lastStatMin) / 60000; lastStatMin = now; live.statMinutes(player?.type || 'none', m, fpsShown, qualName, TOUCH ? 'touch' : 'desktop'); live.statPerf(perfSnap(m)); live.flushStats(); }
}
function refreshLiveBtn() {
  const n = live?.room ? [...peers.values()].length : 0, on = !!live?.room;
  $('liveBtn').classList.toggle('live', on);
  $('liveLabel').textContent = on ? `${n + 1} online` : 'Solo';
}
function refreshLive() {
  const on = !!live?.room, L = $('peerList'); L.textContent = '';
  $('liveHint').textContent = !live ? 'Connecting…' : on ? (peers.size ? 'Everyone with this link open is here with you. Animals are simulated on each device; players, emotes and builds are shared.' : 'You are the only one here right now. Share this link with a friend: they appear here the moment they open it.') : 'Playing solo. Sign in to Claude and open the shared link to see other players.';
  const rows = [['You', player?.spec.name || '', true], ...[...peers.values()].map(e => [e.name || 'Hiker', e.net ? CAT[e.net.t].name + (e.net.k ? ' · knocked out' : '') : 'Arriving…', false])];
  if (on) for (const [nm, what, me] of rows) { const d = document.createElement('div'); d.className = 'peer'; d.innerHTML = '<span></span><small></small>'; d.firstChild.textContent = nm; d.lastChild.textContent = what; if (me) d.style.color = 'var(--amber)'; L.appendChild(d); }
  $('emoteRow').hidden = !on;
}
function showEmote(e, k) { const E = EMOTES.find(x => x[0] === k); if (!E) return; e.emote = `${E[2]} ${E[1]}`; e.emoteUntil = performance.now() + 3200; audio.play('ui'); }
for (const [k, label, icon] of EMOTES) { const b = document.createElement('button'); b.type = 'button'; b.className = 'tag-btn'; b.textContent = `${icon} ${label}`; b.onclick = () => { if (!live?.room) return; live.emit('emote', { k }); toast(`You: ${icon} ${label}`); if (innerWidth < 640) togglePanel('live', false); }; $('emoteRow').appendChild(b); }
// shared builds: one doc per build in db 'builds'; falls back to this device
function shareBuild(kind, x, z, yaw) {
  if (sharedBuilds && live.canWrite) {
    const b = placeBuild(kind, x, z, yaw, false); b.pendingNet = true;
    live.addBuild({ kind, x: +x.toFixed(2), z: +z.toFixed(2), yaw: +yaw.toFixed(3) }).then(id => { b.pendingNet = false; if (!id) { SAVE.builds.push({ kind, x, z, yaw }); saveSoon(); localBuilds.push(b); } else if (!netBuilds.has(id)) netBuilds.set(id, b); else if (netBuilds.get(id) !== b) removeBuild(b); });
  } else localBuilds.push(placeBuild(kind, x, z, yaw, true));
}
function onNetBuild(id, d) {
  if (netBuilds.has(id) || !['campfire', 'shelter', 'fence'].includes(d.kind)) return;
  const x = num(d.x, -180, 180), z = num(d.z, -180, 180), yaw = num(d.yaw, -10, 20);
  const mine = builds.find(b => b.pendingNet && b.kind === d.kind && Math.abs(b.x - x) < 0.05 && Math.abs(b.z - z) < 0.05);
  if (mine) { mine.pendingNet = false; netBuilds.set(id, mine); return; }
  netBuilds.set(id, placeBuild(d.kind, x, z, yaw, false));
}
function onNetBuildGone(id) { const b = netBuilds.get(id); if (b) { removeBuild(b); netBuilds.delete(id); } }
// feedback
let fbKind = 'bug';
for (const b of $('fbSeg').children) b.onclick = () => { fbKind = b.dataset.v; for (const o of $('fbSeg').children) o.classList.toggle('on', o === b); };
$('fbSend').onclick = async () => {
  const text = $('fbText').value.trim(); if (text.length < 3) { $('fbMsg').textContent = 'Add a few words first.'; return; }
  if (!live?.db) { $('fbMsg').textContent = 'Feedback needs you signed in to Claude with access to this game.'; return; }
  $('fbSend').disabled = true; $('fbMsg').textContent = 'Sending…';
  const r = await live.sendFeedback({ kind: fbKind, text: text.slice(0, 1200), species: player?.type || '', x: +(player?.pos.x || 0).toFixed(1), z: +(player?.pos.z || 0).toFixed(1), hour: +world.env.hour.toFixed(1), weather: world.env.weather, season: world.env.season, quality: qualName, fps: fpsShown, device: TOUCH ? 'touch' : 'desktop', w: innerWidth, h: innerHeight });
  $('fbSend').disabled = false;
  if (r.ok) { $('fbText').value = ''; $('fbMsg').textContent = 'Sent. Thank you!'; live.stat('feedback'); toast('Feedback sent'); }
  else $('fbMsg').textContent = r.why === 'offline' ? 'Feedback needs you signed in to Claude.' : 'Could not send. You may need Contributor access to this game.';
};
// what's new
const fillNews = el => { el.textContent = ''; for (const t of WHATS_NEW) { const li = document.createElement('li'); li.textContent = t; el.appendChild(li); } };
fillNews($('newsList')); fillNews($('newsList2')); $('verOut').textContent = 'v' + VERSION; $('newsVer').textContent = 'Version ' + VERSION;
function touchHint() {
  if (!TOUCH || store.get('tHint', 0)) return; store.set('tHint', 1);
  const h = document.createElement('div'); h.id = 'tHint';
  h.innerHTML = '<div><i></i>Drag here to move</div><div><i></i>Drag here to look<br><small>Tap the round buttons to act</small></div>';
  document.body.appendChild(h); const bye = () => { h.style.opacity = 0; setTimeout(() => h.remove(), 900); };
  setTimeout(bye, 6500); addEventListener('touchstart', () => setTimeout(bye, 1200), { once: true });
}
function maybeNews() { if (store.get('seenVersion', '') !== VERSION) $('newsCard').hidden = false; }
$('newsOk').onclick = () => { $('newsCard').hidden = true; store.set('seenVersion', VERSION); audio.play('ui'); };
async function startLive() {
  try { live = await createLive(); } catch (e) { live = null; refreshLiveBtn(); refreshLive(); return; }
  if (live.room) { live.onPeers(onPeerChange); live.on('emote', m => { const e = [...peers.values()].find(p => p.peer === m.peer); if (e && m.data && typeof m.data.k === 'string') showEmote(e, m.data.k); }); }
  if (live.db) {
    sharedBuilds = live.watchBuilds(onNetBuild, onNetBuildGone);
    // move this device's saved builds into the shared valley once
    if (sharedBuilds && live.canWrite && SAVE.builds.length) {
      const list = SAVE.builds.slice(); SAVE.builds = []; saveSoon();
      for (const b of list) { const lb = localBuilds.find(o => o.kind === b.kind && o.x === b.x && o.z === b.z); if (lb) { removeBuild(lb); localBuilds.splice(localBuilds.indexOf(lb), 1); } shareBuild(b.kind, b.x, b.z, b.yaw); }
    }
    live.flushStats();
  }
  refreshLiveBtn(); if (!$('live').hidden) refreshLive();
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && live) { const m = (performance.now() - lastStatMin) / 60000; lastStatMin = performance.now(); live.statMinutes(player?.type || 'none', m, fpsShown, qualName, TOUCH ? 'touch' : 'desktop'); live.statPerf(perfSnap(m)); live.flushStats(); } });
}

// ---------- minimap ----------
const mapCtx = $('map').getContext('2d');
function drawMap() {
  const W = 224, R = 112, sc = 1.7, f = followT || player; if (!f) return;
  const yaw = f.spec.kind === 'bird' ? (f.yawB ?? f.yaw) : f.yaw;
  // heading-up: the creature's forward is always screen-up
  const fx = Math.cos(yaw), fz = -Math.sin(yaw), rx = -fz, rz = fx;
  const P = (x, z) => { const dx = x - f.pos.x, dz = z - f.pos.z; return [(dx * rx + dz * rz) * sc, -(dx * fx + dz * fz) * sc]; };
  const g = mapCtx; g.clearRect(0, 0, W, W); g.save(); g.beginPath(); g.arc(R, R, R - 1, 0, TAU); g.clip();
  g.fillStyle = 'rgba(46,58,30,.85)'; g.fillRect(0, 0, W, W); g.translate(R, R);
  const ring = (fnx, fnz, step) => { g.beginPath(); for (let a = 0; a <= TAU + 0.01; a += step) { const [x, y] = P(fnx(a), fnz(a)); a === 0 ? g.moveTo(x, y) : g.lineTo(x, y); } g.stroke(); };
  g.strokeStyle = 'rgba(20,32,16,.9)'; g.lineWidth = 26; ring(a => Math.cos(a) * 75, a => Math.sin(a) * 75, 0.1);
  g.strokeStyle = 'rgba(160,130,90,.85)'; g.lineWidth = 2.2; ring(a => Math.cos(a) * TRAIL.a, a => Math.sin(a) * TRAIL.b, 0.08);
  { const [x, y] = P(POND.x, POND.z); g.fillStyle = 'rgba(110,160,190,.9)'; g.beginPath(); g.arc(x, y, POND.r * sc, 0, TAU); g.fill(); }
  for (const b of builds) { const [x, y] = P(b.x, b.z); g.fillStyle = b.kind === 'campfire' ? '#ffa040' : '#c9a06a'; g.fillRect(x - 3, y - 3, 6, 6); }
  for (const c of [...all, ...birds]) { if (c === f || c.ko) continue; const [x, y] = P(c.pos.x, c.pos.z); if (Math.hypot(x, y) > R) continue; const r = c.spec.role;
    g.fillStyle = r === 'predator' || r === 'hunter' ? '#e0694a' : r === 'human' ? '#e6a647' : r === 'bird' ? 'rgba(220,230,240,.7)' : '#cfe8b8'; g.beginPath(); g.arc(x, y, r === 'bird' ? 1.6 : 2.6, 0, TAU); g.fill(); }
  for (const e of peers.values()) { const n = e.net; if (!n) continue; const [x, y] = P(n.x, n.z); const l = Math.hypot(x, y), k = l > R - 8 ? (R - 8) / l : 1;
    g.fillStyle = '#7fe08a'; g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.5; g.beginPath(); g.arc(x * k, y * k, 4, 0, TAU); g.fill(); g.stroke(); }
  { const t = player?.spec.kind === 'human' && f === player ? questTarget(curQuest()) : null; // quest marker, pinned to the rim when far
    if (t) { let [x, y] = P(t.x, t.z); const l = Math.hypot(x, y), k = l > R - 9 ? (R - 9) / l : 1; x *= k; y *= k; g.save(); g.translate(x, y); g.rotate(Math.PI / 4); g.fillStyle = '#f0c060'; g.strokeStyle = 'rgba(0,0,0,.65)'; g.lineWidth = 2; g.fillRect(-5, -5, 10, 10); g.strokeRect(-5, -5, 10, 10); g.restore(); } }
  if (CAMP) { const [x, y] = P(CAMP.x, CAMP.z); if (Math.hypot(x, y) < R - 4) { g.fillStyle = SAVE.quest.lit ? '#ff9a40' : '#c9a06a'; g.beginPath(); g.moveTo(x, y - 6); g.lineTo(x + 5, y + 4); g.lineTo(x - 5, y + 4); g.closePath(); g.fill(); } }
  // camera view cone
  const cy = camYaw, cdx = -Math.sin(cy), cdz = -Math.cos(cy), ca = Math.atan2(-(cdx * fx + cdz * fz), cdx * rx + cdz * rz);
  g.fillStyle = 'rgba(242,236,220,.08)'; g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, R, ca - 0.45, ca + 0.45); g.closePath(); g.fill();
  g.restore();
  // player arrow (always up) + north marker on the rim
  g.save(); g.translate(R, R); g.fillStyle = '#e6a647'; g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, -9); g.lineTo(6, 7); g.lineTo(0, 3.5); g.lineTo(-6, 7); g.closePath(); g.stroke(); g.fill(); g.restore();
  const nx = 0 * rx + -1 * rz, ny = -(0 * fx + -1 * fz), nl = Math.hypot(nx, ny) || 1;
  g.fillStyle = 'rgba(242,236,220,.9)'; g.font = '700 17px system-ui'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('N', R + nx / nl * (R - 14), R + ny / nl * (R - 14));
}

// ---------- loop ----------
let last = performance.now(), frames = 0, fpsAcc = 0, fpsN = 0, fpsShown = 0, stepT = 0, dustT = 0;
let thirstWarned = false, vitalT = 5;
function survival(dt) {
  if (!player || player.ko) return;
  const p = player, resting = !p.act && p.speed < 0.3;
  p.sta = Math.min(100, p.sta + dt * (resting ? 22 : input.run ? 0 : 10));
  p.hunger = Math.max(0, p.hunger - dt * 0.2 * (input.run ? 1.6 : 1));
  const T = CFG.thirst, hard = p.mount ? p.mount._galloping : input.run && p.speed > 3;
  SAVE.water = Math.max(0, SAVE.water - dt * T.drain * (hard ? T.sprintK : 1) * (isNight() ? T.nightK : 1));
  if (SAVE.water < T.low && !thirstWarned) { thirstWarned = true; toast('Thirsty. Drink at the pond.', true); }
  if (p.hunger <= 0) p.hp -= dt * 0.8;
  if (SAVE.water <= 0) p.hp -= dt * T.dmg;
  else if (simTime - p.lastHit > 6 && p.hunger > 35 && SAVE.water > T.low) p.hp = Math.min(p.maxHp, p.hp + dt * 0.9);
  if ((vitalT -= dt) < 0) { vitalT = 5; store.set('vitals', { water: +SAVE.water.toFixed(1), hunger: +p.hunger.toFixed(1) }); }
  if (p.hp <= 0 && !p.ko) { p.hp = 0; p.knockOut(); setTimeout(showKO, 900); }
  // shelter skips the night
  for (const b of builds) if (b.kind === 'shelter' && d2(b, p.pos) < 2 && isNight() && p.speed < 0.2 && rnd() < dt * 0.3) { $('tod').value = 6.4; onTod(); toast('You rested until dawn'); p.hp = p.maxHp; }
}
function ambientFX(dt) {
  dustT -= dt; stepT -= dt;
  const near = all.filter(c => !c.ko && c.group.visible && camera.position.distanceTo(c.pos) < 28);
  if (dustT < 0) { dustT = 0.12; for (const c of near) { if (c.speed > 5.5 && c.air === 0 && c.spec.kind !== 'human') fx.burst('dust', tv.copy(c.pos).setY(c.pos.y + 0.05), { n: 3, k: 0.7 * c.S }); if (pondD(c.pos.x, c.pos.z) < POND.r + 0.4 && c.speed > 1) { fx.burst('splash', tv.copy(c.pos).setY(POND.y + 0.05), { n: 4 }); audio.play('splash', vol(c) * 0.4); } } }
  const P = player?.mount || player;
  if (P && !P.ko && P.speed > 0.5 && P.air === 0 && stepT < 0) { const k = P.spec.kind; stepT = (k === 'human' ? 1.0 : 1.4 * P.S) / (P.speed + 0.6) * (P === player ? 1 : 0.55); audio.play(k === 'hoofed' ? 'hoof' : k === 'bird' ? 'chirp' : 'step', 0.5 + Math.min(0.5, P.speed / 12)); }
  for (const b of builds) if (b.kind === 'campfire') { const fl = b.g.userData.flame; fl.scale.set(1 + 0.12 * Math.sin(simTime * 13), 1 + 0.2 * Math.sin(simTime * 9 + 1), 1); b.g.userData.light.intensity = 5 + 1.4 * Math.sin(simTime * 17) + rnd(); if (rnd() < dt * 3) fx.burst('ember', tv.set(b.x, b.g.position.y + 0.6, b.z)); if (rnd() < dt * 1.5) fx.burst('smoke', tv.set(b.x, b.g.position.y + 0.9, b.z)); if (rnd() < dt * 6 && camera.position.distanceTo(b.g.position) < 12) audio.play('fire', 0.6); }
  if (CAMP?.fire) { const f = CAMP.fire; f.children.forEach((c, i) => { if (c.isMesh) c.scale.set(1 + 0.15 * Math.sin(simTime * (11 + i * 2) + i), 1 + 0.25 * Math.sin(simTime * (8 + i) + i * 2), 1); }); CAMP.light.intensity = 12 + 3 * Math.sin(simTime * 13) + rnd() * 2; const gp = CAMP.g.position; if (rnd() < dt * 6) fx.burst('smoke', tv.set(CAMP.x + (rnd() - 0.5) * 0.4, gp.y + 2.2, CAMP.z)); if (rnd() < dt * 4) fx.burst('ember', tv.set(CAMP.x, gp.y + 1.2, CAMP.z)); if (rnd() < dt * 4 && camera.position.distanceTo(gp) < 18) audio.play('fire', 0.8); }
  if (CAMP?.flag) CAMP.flag.rotation.y = 0.25 * Math.sin(simTime * 2.1) + 0.1 * Math.sin(simTime * 5.3);
  if (torchLight) torchLight.intensity = 4.5 + Math.sin(simTime * 15) * 0.8;
}
function simulate(dt) {
  simTime += dt; frames++;
  if ($('clockRun').checked) { world.env.hour += dt / 60 * 0.4; if (world.env.hour > 23.5) world.env.hour = 5; if ((frames & 15) === 0) { $('tod').value = world.env.hour; $('todOut').textContent = fmtH(world.env.hour); world.applyTime(); } }
  drivePlayer(dt); survival(dt);
  const camP = camera.position;
  for (const c of all) {
    const far = c !== player && camP.distanceTo(c.pos) > 70;
    if (c !== player && !c.rider && !c.ko && !window.__zoo && (!far || (frames + c.id) % 4 === 0)) think(c, far ? dt * 4 : dt);
    c.tickCombat(dt, resolveHit);
    if (c.mount) continue; // seated after its horse has moved (below)
    if (far && (frames + c.id) % 3 !== 0) { c._acc = (c._acc || 0) + dt; continue; }
    c.step(dt + (c._acc || 0), simTime, worldProxy); c._acc = 0;
  }
  if (player?.mount) { const p = player, h = p.mount;
    if (p.ko || h.ko || !all.includes(h)) dismountHorse(true);
    else { p._rideW = Math.min(1, p._rideW + dt / CFG.ride.mountTime); p.seatOn(h, dt, simTime, p._rideW); } }
  // remove long-down creatures far from camera, respawn later
  for (const c of all) if (c.tamed && c.ko && c.koT > 25) { c.revive(); c.hp = Math.round(c.maxHp * 0.5); c.state = 'idle'; c.timer = 4; }
  for (let i = all.length - 1; i >= 0; i--) { const c = all[i]; if (c.ko && c !== player && !c.tamed && c.koT > 90 && camP.distanceTo(c.pos) > 25) { all.splice(i, 1); c.dispose(); const t = c.type; setTimeout(() => spawn(t, ...spot(50)), 30000); } }
  updateBirds(dt, simTime); stepPeers(dt);
  flushPending();
  updateCamera(dt); updateGhost(); updateContext(dt); updateHorses(dt); questTick(dt);
  const focus = followT || player;
  world.update(simTime, story.on ? storyFocus : camMode === 'free' ? camP : (focus ? focus.pos : camP));
  wx.U.uTime.value = simTime; wx.U.uCam.value.copy(camP); wx.U.uWind.value = world.env.wind; wx.U.uAmt.value = world.env.fall; wx.U.uFlash.value = world.env.flash;
  wx.U.uLight.value.copy(world.skyU.uHor.value).multiplyScalar(0.35 + 0.65 * (world.env._day || 0)).lerp(world.skyU.uSunCol.value, 0.15 * (world.env._day || 0));
  fx.update(dt); ambientFX(dt);
  for (const c of all) c.setLOD(camP.distanceTo(c.pos) / LODK, LITE); for (const b of birds) b.setLOD(camP.distanceTo(b.pos), LITE);
  hurtT = Math.max(0, hurtT - dt * 1.8); if (grade) grade.uniforms.uHurt.value = hurtT * 0.6; else $('hurt').style.opacity = hurtT;
  const E = world.env;
  { // music follows the moment: menu, fights, rain, night, golden hour, day
    const fight = player && (simTime - Math.max(player.lastHit ?? -99, player.lastAtk ?? -99) < 7 || all.some(c => c.state === 'chase' && c.target === player && !c.ko && d2(c.pos, player.pos) < 30));
    const h = E.hour, warm = (h > 16.8 && h < 19.7) || (h > 5.4 && h < 7.8);
    const camp = CAMP?.fire && player && Math.hypot(CAMP.x - player.pos.x, CAMP.z - player.pos.z) < 16, riding = player?.mount && player.mount.speed > 3.5;
    audio.mood = story.on ? 'story' : !player || $('loading') ? 'menu' : fight ? 'combat' : riding ? 'ride' : camp ? 'camp' : E.rain > 0.45 ? 'rain' : world.skyU.uDay.value < 0.25 ? 'night' : warm ? 'golden' : 'day'; }
  audio.update(dt, { wind: E.wind, rain: E.rain, snow: E.snow, day: world.skyU.uDay.value, water: player ? clamp(1 - (pondD(player.pos.x, player.pos.z) - POND.r) / 14, 0, 1) : 0 });
}
const RING_R = { rHp: 50.3, rSta: 53.7, rFood: 57.1, rWater: 60.5 }, ringLast = {};
function ring(id, k) { k = clamp(k, 0, 1); if (Math.abs((ringLast[id] ?? -1) - k) < 0.004) return; ringLast[id] = k; const el = $(id), C = TAU * RING_R[id];
  el.style.strokeDasharray = C.toFixed(1); el.style.strokeDashoffset = (C * (1 - k)).toFixed(1); el.classList.toggle('low', k < 0.25); }
function hud(dt) {
  const f = followT || player; if (!f) return; camera.updateMatrixWorld();
  setState($('whoState'), f);
  if (player) { const sta = player.mount ? player.mount.sta : player.sta; $('hpBar').style.width = (player.hp / player.maxHp * 100) + '%'; $('staBar').style.width = sta + '%'; $('foodBar').style.width = player.hunger + '%';
    ring('rHp', player.hp / player.maxHp); ring('rSta', sta / 100); ring('rFood', player.hunger / 100); ring('rWater', SAVE.water / 100); $('waterBar').style.width = SAVE.water + '%'; $('rSta').classList.toggle('horse', !!player.mount);
    const w1 = $('whoLine1'), w2 = $('whoLine2'), nm = (followT ? 'Following · ' : '') + f.spec.name, st = stateOf(f)[0]; if (w1.textContent !== nm) w1.textContent = nm; if (w2.textContent !== st) w2.textContent = st; }
  if (cardFor) { setState($('cardState'), cardFor); $('cardHp').textContent = `Health ${Math.ceil(cardFor.hp ?? 0)} / ${cardFor.maxHp ?? 0}`; }
  if (player?.mount) { const h = player.mount; for (const [i, id] of [[1, 'a0'], [2, 'a1'], [0, 'a3']]) { const m = MOVES.horse[i]; $(id).style.setProperty('--cd', (h.cds[i] / m.cd).toFixed(3)); $(id).classList.toggle('low', h.sta < m.sta * 0.5); } }
  else if (player) for (const [i, id] of [[0, 'a0'], [1, 'a1'], [2, player.spec.kind === 'human' ? 'a2' : 'a3']]) { const m = MOVES[player.type]?.[i]; if (!m) continue; $(id).style.setProperty('--cd', (player.cds[i] / m.cd).toFixed(3)); $(id).classList.toggle('low', player.sta < m.sta * 0.5); }
  targetT -= dt; const tb = $('tbar');
  if (targetShown && targetT > 0 && !targetShown.ko && targetShown.group.visible) { tv.copy(targetShown.pos).setY(targetShown.pos.y + targetShown.height * 1.05).project(camera); if (tv.z < 1) { tb.hidden = false; tb.style.left = ((tv.x + 1) / 2 * innerWidth) + 'px'; tb.style.top = ((1 - tv.y) / 2 * innerHeight) + 'px'; $('tName').textContent = targetShown.spec.name; $('tHp').style.width = (targetShown.hp / targetShown.maxHp * 100) + '%'; } else tb.hidden = true; } else tb.hidden = true;
  if ((frames & 3) === 0) drawMap();
  if (player && (frames & 31) === 0) {
    const fine = player.hp >= player.maxHp * 0.97 && player.sta > 95 && player.hunger > 60 && SAVE.water > 60 && simTime - player.lastHit > 6 && !player.act;
    document.body.classList.toggle('calm', fine && !document.body.classList.contains('panelopen'));
    $('menuPip').hidden = !(live?.room && peers.size);
    if (isNight() && !player.ko) nightSeen = true; else if (nightSeen && !isNight() && !player.ko) { nightSeen = false; FLAGS.night = 1; }
    refreshGoals();
  }
  updateCtxMark(); updateWaypoint();
  updateTags(); livePulse(performance.now());
}
// ---------- auto quality: hold ~60fps by trading resolution first, then detail ----------
const DPR = Math.min(devicePixelRatio || 1, 2);
const TUNE = [ // each step is cheaper than the last
  { pr: 1.0, grass: 1, flowers: true, reflect: true, rays: true, trees: 1 },
  { pr: 0.86, grass: 1, flowers: true, reflect: true, rays: true, reflEvery: 2, trees: 0.9 },
  { pr: 0.75, grass: 0.8, flowers: true, reflect: true, rays: true, reflEvery: 2, trees: 0.8 },
  { pr: 0.66, grass: 0.7, flowers: true, reflect: false, rays: true, trees: 0.7 },
  { pr: 0.58, grass: 0.55, flowers: false, reflect: false, rays: false, trees: 0.6 },
  { pr: 0.5, grass: 0.4, flowers: false, reflect: false, rays: false, trees: 0.5 },
];
let tuneLvl = store.get('tuneLvl3', TOUCH ? 2 : 1), tuneAcc = 0, tuneN = 0, tuneGood = 0, tuneHold = 3;
function applyTune() {
  const L = TUNE[tuneLvl];
  renderer.setPixelRatio(Math.max(1, Math.min(DPR, QUALITY.pr) * L.pr)); resize();
  world.setDetail({ grass: L.grass, flowers: L.flowers, reflect: L.reflect, reflEvery: L.reflEvery || QUALITY.reflEvery || 1, trees: L.trees });
  if (rays) rays.enabled = L.rays;
}
function autoTune(rawDt) {
  if (!QUALITY.auto || !world || document.hidden || rawDt > 0.25) return;
  tuneAcc += rawDt; tuneN++;
  if (tuneAcc < 2) return;
  const fps = tuneN / tuneAcc; tuneAcc = 0; tuneN = 0;
  if (tuneHold > 0) { tuneHold--; return; } // let shaders compile and the scene settle
  const tgt = fpsCap || 60;
  if (TOUCH && !fpsCap && tuneLvl === TUNE.length - 1 && fps < 36 && !store.get('fpsCapSet', false)) { fpsCap = 30; tuneLvl = 2; applyTune(); return; }
  if (fps < tgt * 0.83 && tuneLvl < TUNE.length - 1) { tuneLvl++; tuneGood = 0; tuneHold = 1; applyTune(); store.set('tuneLvl3', tuneLvl); }
  else if (fps > tgt * 0.975 && tuneLvl > 0) { if (++tuneGood >= 4) { tuneLvl--; tuneGood = 0; tuneHold = 1; applyTune(); store.set('tuneLvl3', tuneLvl); } }
  else tuneGood = 0;
}
// ---------- Bluetooth / USB controllers (standard mapping: Xbox, PlayStation, Backbone, Kishi) ----------
const padPrev = [];
function pollPad(dt) {
  const pads = navigator.getGamepads ? navigator.getGamepads() : []; let gp = null;
  for (const g of pads) if (g && g.connected && g.mapping === 'standard') { gp = g; break; }
  if (!gp) { if (input.pad.on) { input.pad.on = false; input.pad.x = input.pad.y = 0; input.pad.run = false; } return; }
  if (!input.pad.on) { input.pad.on = true; toast('Controller connected: left stick moves, right stick looks, A jumps, X/B/RB use skills, Y scans and uses'); }
  const dz = v => Math.abs(v) < 0.14 ? 0 : (v - Math.sign(v) * 0.14) / 0.86, B = i => !!gp.buttons[i]?.pressed, edge = i => B(i) && !padPrev[i];
  input.pad.x = dz(gp.axes[0] || 0); input.pad.y = -dz(gp.axes[1] || 0);
  input.pad.run = B(10) || B(6) || (gp.buttons[6]?.value || 0) > 0.4;
  const lx = dz(gp.axes[2] || 0), ly = dz(gp.axes[3] || 0);
  if (lx || ly) { const k = 2.8 * dt; if (camMode === 'free') { freeCam.yaw -= lx * k; freeCam.pitch = clamp(freeCam.pitch - ly * k, -1.3, 1.2); } else { camYaw -= lx * k; camPitch = clamp(camPitch + ly * k * 0.7, -0.15, 1.35); } lastManual = simTime; }
  if (edge(0)) { audio.start(); doJump(); } input.jumpHeld = B(0) || input.keys.has('Space');
  if (edge(2)) doAct(1); if (edge(1)) doAct(2); if (edge(5)) doAct(3);
  if (edge(3)) ctxTap();
  input.ctxHeld = B(3) || input.keys.has('KeyF') || input.keys.has('KeyE');
  input.pad.down = B(11) || B(4);
  if (edge(9)) togglePanel('kit'); if (edge(8)) togglePanel('journal');
  if (edge(12)) setCam({ follow: 'orbit', orbit: 'free', free: 'follow' }[camMode]);
  if (edge(13)) setPhoto(!document.body.classList.contains('photo'));
  if (edge(14) || edge(15)) { const sl = hotSlots(); if (sl.length) { const i = sl.findIndex(x => x.id === equipped); selectSlot(sl[(i + (edge(15) ? 1 : -1) + sl.length) % sl.length].id); } }
  for (let i = 0; i < gp.buttons.length; i++) padPrev[i] = !!gp.buttons[i]?.pressed;
}
// frame-rate modes (like the console port on iPhone): Max, 40 fps balanced, 30 fps for the sharpest detail
let rafMs = 16.67, rafN = 0, rafPrev = 0, rafSkip = 0;
// frame-time log: median/95th percentile and hitches (frames over 1.7x the target interval), reported per minute to the stats doc
const FT = new Float32Array(900); let ftN = 0, ftHitch = 0, ftLast = 0;
function perfSnap(min) {
  const n = Math.min(ftN, FT.length), a = Array.from(FT.subarray(0, n)).sort((x, y) => x - y), q = f => a[Math.min(n - 1, Math.floor(n * f))] || 0;
  let gpu = ''; try { const gl = renderer.getContext(), ext = gl.getExtension('WEBGL_debug_renderer_info'); gpu = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER)).slice(0, 60); } catch (e) {}
  const out = { fps: q(0.5) ? Math.round(1000 / q(0.5)) : fpsShown, p95ms: Math.round(q(0.95) * 10) / 10, stutterPerMin: Math.round(ftHitch / Math.max(0.2, min) * 10) / 10, tune: tuneLvl, cap: fpsCap,
    res: renderer.domElement.width + 'x' + renderer.domElement.height, dpr: devicePixelRatio, gpu, quality: qualName, device: TOUCH ? 'touch' : 'desktop', minutes: min };
  ftHitch = 0; return out;
}
addEventListener('error', e => { try { live?.statError?.(e.message + ' @' + (e.filename || '').split('/').pop() + ':' + e.lineno); } catch (_) {} });
addEventListener('unhandledrejection', e => { try { live?.statError?.('promise: ' + (e.reason?.message || e.reason)); } catch (_) {} });
function frame(now) {
  if (rafPrev) { const d = now - rafPrev; if (d > 4 && d < 40) { rafMs += (d - rafMs) * 0.05; rafN++; } } rafPrev = now;
  if (fpsCap) { const every = Math.max(1, Math.round(1000 / fpsCap / rafMs)); if (++rafSkip % every) { requestAnimationFrame(frame); return; } }
  pollPad(Math.min(0.05, (now - last) / 1000));
  if (ftLast && !document.hidden) { const ft = now - ftLast; if (ft < 500) { FT[ftN++ % FT.length] = ft; if (ft > 1.7 * (fpsCap ? 1000 / fpsCap : Math.max(rafMs, 16.7))) ftHitch++; } } ftLast = now;
  const rawDt = (now - last) / 1000, dt = Math.min(0.05, rawDt); last = now;
  autoTune(rawDt);
  let simDt = dt; if (hitStop > 0) { hitStop -= rawDt; simDt = dt * 0.08; }
  fpsAcc += rawDt; fpsN++; if (fpsAcc > 1) { fpsShown = Math.round(fpsN / fpsAcc); fpsAcc = 0; fpsN = 0; $('fpsLine').textContent = QUALITY.auto ? `${fpsShown} fps · Auto is tuning detail for this device (step ${tuneLvl + 1} of ${TUNE.length})` : `${fpsShown} fps on ${qualName} graphics. Try Auto if it feels choppy.`; }
  if (timeScale === 0) { updateCamera(dt); world.update(simTime, (followT || player)?.pos || camera.position); }
  else simulate(simDt * timeScale);
  hud(dt); draw();
  requestAnimationFrame(frame);
}

// QA hooks
// QA: one tick of the side-by-side walk loop (hiker + buck walking together, tracking side camera)
window.__step = (dt, render = true) => { const W = window.__walk; if (!W) return; const { h, b } = W; W.t += dt; simTime += dt;
  for (const c of [h, b]) { c.wantSpeed = c.speed = 1.35; c.wantYaw = c.yaw; c.step(dt, simTime, world); }
  world.update(simTime, h.pos); const mx = (h.pos.x + b.pos.x) / 2, mz = (h.pos.z + b.pos.z) / 2, my = (h.pos.y + b.pos.y) / 2;
  camera.position.set(mx + 0.6, my + 1.45, mz + 6.4); camera.lookAt(mx, my + 0.95, mz - 0.6); if (render) draw(); };
window.__dbg = { get composer() { return composer; }, set composer(v) { composer = v; }, draw: () => draw() };
window.__sim = (sec, dt = 1 / 30) => { for (let t = 0; t < sec; t += dt) simulate(dt); hud(dt); drawMap(); draw(); };
window.__frame = (i, ang = 0.5, k = 1, up = 0.25) => { const c = all[i]; const ctr = c.center; const H = c.height, d = (1.4 + H * 1.9) * k; camera.position.set(ctr.x + Math.sin(ang) * d, ctr.y + H * up + 0.2, ctr.z + Math.cos(ang) * d); camera.lookAt(ctr); world.update(simTime, c.pos); hud(0); draw(); return c.type; };
window.__cam = (p, l) => { camera.position.set(...p); camera.lookAt(...l); draw(); };
window.__THREE = THREE;
window.__api = { CFG, audio, playStory, nextStory, endStory, get storyOn() { return story.on; }, get CAMP() { return CAMP; }, questTarget, curQuest, lightSignal, gainXP, xpNeed, carryCap, mountHorse, dismountHorse, restoreHorses, saveHorses, tameHorse, tame: h => { h.tamed = true; h.horseName = h.horseName || 'Dusty'; h.showTack(true); h.leader = null; return h; }, get ctxNowKind() { return ctxNow?.kind; }, ctxTap, scene, renderer, camera, get all() { return all; }, get birds() { return birds; }, get player() { return player; }, control, setCam, spawn, SPAWNS, get world() { return world; }, setTod: h => { $('tod').value = h; onTod(); }, input, SAVE, setWeather, playerAction, togglePanel, refreshCraft, placeBuild, completeContext, get ctxNow() { return ctxNow; }, get live() { return live; }, peers, onPeerChange, shareBuild, set camYaw(v) { camYaw = v; }, set camPitch(v) { camPitch = v; }, set camDist(v) { camDist = v; } };

(async () => {
  const bar = $('loadBar'); bar.style.width = '10%'; $('loadVer').textContent = 'v' + VERSION;
  try { $('loadMsg').textContent = 'Sculpting deer…'; await loadSpecies('deer'); bar.style.width = '45%'; $('loadMsg').textContent = 'Waiting for hikers…'; await loadSpecies('athlete'); bar.style.width = '65%'; }
  catch (e) { $('loadMsg').textContent = 'The creature files did not load. Reload the page to try again.'; return; }
  let ASSETS;
  try { $('loadMsg').textContent = 'Loading photo textures, trees and skies…'; ASSETS = await loadAssets(renderer, k => { bar.style.width = (65 + k * 25).toFixed(0) + '%'; }, { aniso: QUALITY.aniso || 8 }); }
  catch (e) { console.error(e); $('loadMsg').textContent = 'Some game files did not load. Check your connection and reload.'; return; }
  $('loadMsg').textContent = 'Planting the forest…';
  await new Promise(r => setTimeout(r, 30));
  world = createWorld(scene, renderer, camera, LITE, QUALITY, ASSETS);
  world.env.season = 'summer'; world.env.weather = 'clear'; world.env.tgt.mist = world.env.mist;
  bindCreatureEnv(world.U); world.onThunder = v => audio.play('thunder', 0.4 + 0.6 * v);
  fx = createFX(scene, LITE ? 300 : 700); wx = createWeather(scene, LITE ? 1800 : 5000);
  resize(); addEventListener('resize', resize); if (QUALITY.auto && !Q.has('qa')) applyTune();
  for (const b of SAVE.builds) localBuilds.push(placeBuild(b.kind, b.x, b.z, b.yaw, false));
  buildCamp();
  if (Q.has('zoo')) {
    await Promise.all(['elk', 'horse', 'wolf', 'rabbit'].map(loadSpecies));
    ['buck', 'wbuck', 'doe', 'fawn', 'elk', 'cow', 'horse', 'wolf', 'fox', 'rabbit', 'hiker'].forEach((t, i) => { const c = spawn(t, -14 + i * 2.8, 0, { yaw: 0 }); c.state = 'idle'; });
    player = all[0]; window.__zoo = true; simulate(0.016);
  } else populate();
  if (Q.has('all')) await Promise.all(['elk', 'horse', 'wolf', 'rabbit'].map(loadSpecies)).then(() => new Promise(r => setTimeout(r, 50)));
  applyPerks(player); refreshLevel(); onTod(); refreshWho(); buildPlayRow(); buildJournal(); refreshActions(); buildHotbar(); $('craftBtn').hidden = player?.spec.kind !== 'human';
  await warmShaders();
  bar.style.width = '100%';
  if (Q.has('qa') || Q.has('zoo')) { setTimeout(() => $('loading').remove(), 200); }
  else {
    $('loadMsg').textContent = 'Choose your character'; $('loading').querySelector('.bar2').remove();
    const row = document.createElement('div'); row.className = 'pick';
    for (const [t, label, sub] of [['athlete', 'Male hiker', 'Hybrid athlete · fists, kicks, crafting'], ['buck', 'Black Buck', 'Melanistic whitetail · antlers, speed, leaps']]) {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'pickBtn'; b.innerHTML = '<b></b><span></span>'; b.firstChild.textContent = label; b.lastChild.textContent = sub;
      b.onclick = () => { audio.start(); const c = all.find(c => c.type === t); if (c) control(c); $('loading').remove(); if (!store.get('storySeen', 0)) { store.set('seenVersion', VERSION); playStory(() => touchHint()); } else { maybeNews(); touchHint(); } };
      row.appendChild(b);
    }
    $('loading').appendChild(row);
    const note = document.createElement('div'); note.className = 's'; note.textContent = 'Scan other animals to unlock them later.'; $('loading').appendChild(note);
  }
  startLive();
  window.__ready = true; refreshGoals();
  if (!SAVE.journal.buck) setTimeout(() => toast('Tip: hold Scan near animals to fill your journal and unlock them'), 2500);
  if (Q.has('qa')) return;
  requestAnimationFrame(t => { last = t; frame(t); });
})();
