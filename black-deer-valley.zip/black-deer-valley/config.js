// Black Deer Valley v0.6 Frontier: every gameplay tuning number lives here.
export const CFG = {
  ride: {
    reach: 2.5,          // m: how close the hiker must be to a tamed horse to see "Ride"
    mountTime: 0.45,     // s: vault into the saddle
    speeds: [1.8, 4.6, 11.5], // m/s: walk, trot, gallop
    gallopDrain: 9,      // horse stamina per second at a gallop (100 = full)
    regenTrot: 3,        // horse stamina back per second while trotting
    regenRest: 10,       // per second while walking or standing
    gallopMin: 6,        // stamina needed to start a gallop
    windedUntil: 35,     // after running out, no gallop until stamina is back to this
    jumpCost: 12,        // horse stamina per leap
    camDist: 8.0,        // m: camera distance while riding (on foot is about 7)
    camUp: 1.05,         // m: camera aims this much higher while riding
    fovGallop: 7,        // degrees the lens widens at full gallop
  },
  tame: {
    reach: 4,            // m: walk this close to a wild horse to see "Calm"
    holdSec: 10,         // s of holding Calm to fill the trust ring
    decay: 0.03,         // trust lost per second while not calming (1 = full ring)
    calmSpeed: 2.2,      // m/s: slower than this counts as walking; faster spooks
    spookDist: 7,        // m: running or attacking this close spooks the horse (trust back to zero)
    walkThreat: 0.12,    // how wary wild horses are of a walking hiker (0 = not at all, 0.45 = like other grazers)
    whistleMin: 10,      // m: farther than this, the button whistles your horse over
    stayRadius: 6,       // m: a tamed horse grazes within this of where you left it
    names: ['Dusty', 'Juniper', 'Copper', 'Willow', 'Ranger', 'Sage', 'Maple', 'Bandit', 'Scout', 'Ember', 'Aspen', 'Cody'],
  },
  thirst: {
    drain: 0.22,         // water lost per second (100 = full; about 7.5 minutes from full to empty)
    sprintK: 2.2,        // drains this many times faster while sprinting or galloping
    nightK: 0.75,        // cooler nights: slower
    dmg: 0.9,            // health lost per second at zero water
    low: 25,             // warn below this
    drinkTo: 100,        // a drink at the pond fills water back to this
  },
  xp: {
    base: 120,           // XP from level 1 to 2
    growth: 1.3,         // each level needs base * level^growth
    maxLevel: 20,
    gain: { scanNew: 40, scan: 4, tame: 120, craft: 15, build: 20 }, // quests carry their own XP (see quests)
    perks: [             // a perk at every level-up, in this order, repeating
      { id: 'hp', name: 'Tough', text: '+8% max health' },
      { id: 'sta', name: 'Endurance', text: 'sprinting and jumping cost 10% less stamina' },
      { id: 'carry', name: 'Pack mule', text: '+10 carry space for each material' },
    ],
    hpPer: 0.08, staPer: 0.1, carryBase: 40, carryPer: 10,
  },
  quests: [            // the Frontier chain, in order
    { id: 'herd', title: 'Find the wild herd', hint: 'Wild horses graze at the west edge of the meadow. Get close and scan one.', xp: 30 },
    { id: 'tame', title: 'Tame a horse', hint: 'Walk up slowly and hold Calm. Running or fighting spooks them.', xp: 40 },
    { id: 'pond', title: 'Ride to the pond and drink', hint: 'Ride your horse to the pond, step down and drink.', xp: 50 },
    { id: 'wood', title: 'Gather wood for a signal fire', need: 8, hint: 'Chop trees or pick up fallen logs.', xp: 50 },
    { id: 'signal', title: 'Light the signal fire at the ridge camp', hint: 'Carry the wood up to the ridge camp and light the fire.', xp: 150 },
  ],
  quest: {
    herdNear: 12,        // m: this close to a wild horse also counts as finding the herd
    pondRide: 6,         // m from the pond's edge that counts as riding there
    campReach: 3.2,      // m: light the signal fire from this close
    wpHide: 4,           // m: the on-screen waypoint hides this close to the goal
  },
  story: {
    cardSec: 7.5,        // s each card stays up before moving on by itself
    cards: [
      { shot: 'valley', title: 'Past the last road', text: 'Black Deer Valley runs wild. No towns, no signal. Just grass, timber and the animals that own it.' },
      { shot: 'herd', title: 'The wild herd', text: 'A band of wild horses grazes the west meadow. Earn the trust of one and the whole valley opens up.' },
      { shot: 'pond', title: 'Stay alive', text: 'Keep your water, food and strength up. The pond runs fresh. After dark, the wolves come down from the trees.' },
      { shot: 'camp', title: 'The signal', text: 'An old camp waits on the ridge. Light its signal fire and let the valley know someone is here to stay.' },
    ],
  },
  music: {
    dir: 'music/',       // recorded tracks live here; any that are missing fall back to the built-in synth score
    // mood -> file (AAC .m4a, about 96 kbps, under 2 MB each). Empty until the recordings are added, e.g.
    // { menu: 'menu.m4a', day: 'day.m4a', night: 'night.m4a', combat: 'danger.m4a', ride: 'ride.m4a', camp: 'camp.m4a', story: 'story.m4a' }
    tracks: {},
    gain: { menu: 0.9, day: 0.85, night: 0.9, combat: 0.8, ride: 0.85, camp: 0.9, story: 0.9 }, // even out loudness
    useFor: { golden: 'day', rain: 'night' },          // moods without their own recording borrow one
    synthFor: { ride: 'day', camp: 'golden', story: 'menu' }, // moods without a recording or a synth part borrow a synth mood
    fade: 2,             // s crossfade between moods
    loopXf: 1.5,         // s overlap where a track loops back to its start
    on: true,            // set false to skip loading recordings at all
  },
  ko: {
    wakeHp: 0.25,        // knocked out: wake where you fell with this share of health
    calmSec: 12,         // s: attackers back off for this long after you wake
  },
};
