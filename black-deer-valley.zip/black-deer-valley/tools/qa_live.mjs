import { chromium } from 'playwright';
import fs from 'fs';
const dir = process.cwd(); const [,, out, w, h, q, script, mock] = process.argv;
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const T = !!process.env.TOUCH; const page = await browser.newPage({ viewport: { width: +w, height: +h }, hasTouch: T, isMobile: T, deviceScaleFactor: T ? 2 : 1 });
page.on('pageerror', e => console.log('PAGEERR', e.message, e.stack?.split('\n').slice(0, 3).join(' | ')));
page.on('console', m => { if (m.type() === 'error' || m.text().startsWith('QA')) console.log('CONSOLE', m.type(), m.text().slice(0, 400)); });
if (mock === '1') await page.addInitScript({ path: dir + '/mock_claude.js' });
await page.route('https://cdn.jsdelivr.net/npm/three@0.160.0/**', r => r.fulfill({ path: dir + '/node_modules/three/' + r.request().url().split('three@0.160.0/')[1], contentType: 'application/javascript' }));
await page.route('https://fonts.googleapis.com/**', r => r.fulfill({ body: '', contentType: 'text/css' }));
const root = process.env.ROOT || dir;
fs.writeFileSync(root + '/_qa.html', '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>' + fs.readFileSync(root + '/index.html', 'utf8') + '</body></html>');
await page.goto('http://127.0.0.1:' + (process.env.PORT || 8765) + '/_qa.html?qa&' + (q || ''), { timeout: 0 });
await page.waitForFunction(() => window.__ready, null, { timeout: 0 });
fs.mkdirSync(out, { recursive: true });
let i = 0;
for (const st of JSON.parse(script || '[]')) {
  const r = await page.evaluate(st.js);
  if (r !== undefined) console.log('QA', st.name, JSON.stringify(r).slice(0, 600));
  if (!st.noshot) await page.screenshot({ path: `${out}/s${String(i++).padStart(2, '0')}_${st.name}.png`, timeout: 180000 });
}
await browser.close();
