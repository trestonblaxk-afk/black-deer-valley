// Generic SDF creature builder: sculpt -> surface nets -> skin weights -> color slots -> packed LODs.
// usage: node species.mjs [name ...]   (writes data/<name>.js)
import fs from 'fs';
import path from 'path';
const dir = path.dirname(new URL(import.meta.url).pathname);
fs.mkdirSync(dir + '/data', { recursive: true });

const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const len = a => Math.sqrt(dot(a, a));
function sdRoundCone(p, a, b, r1, r2) {
  const ba = sub(b, a), l2 = dot(ba, ba), rr = r1 - r2, a2 = l2 - rr * rr, il2 = 1 / l2;
  const pa = sub(p, a), y = dot(pa, ba), z = y - l2;
  const xv = [pa[0] * l2 - ba[0] * y, pa[1] * l2 - ba[1] * y, pa[2] * l2 - ba[2] * y];
  const x2 = dot(xv, xv), y2 = y * y * l2, z2 = z * z * l2;
  const k = Math.sign(rr) * rr * rr * x2;
  if (Math.sign(z) * a2 * z2 > k) return Math.sqrt(x2 + z2) * il2 - r2;
  if (Math.sign(y) * a2 * y2 < k) return Math.sqrt(x2 + y2) * il2 - r1;
  return (Math.sqrt(x2 * a2 * il2) + y * rr) * il2 - r1;
}
function sdEllipsoid(p, c, r, rotZ = 0, rotY = 0) {
  let x = p[0] - c[0], y = p[1] - c[1], z = p[2] - c[2];
  if (rotY) { const cs = Math.cos(-rotY), sn = Math.sin(-rotY); [x, z] = [x * cs + z * sn, -x * sn + z * cs]; }
  if (rotZ) { const cs = Math.cos(-rotZ), sn = Math.sin(-rotZ); [x, y] = [x * cs - y * sn, x * sn + y * cs]; }
  const k0 = Math.sqrt((x / r[0]) ** 2 + (y / r[1]) ** 2 + (z / r[2]) ** 2);
  const k1 = Math.sqrt((x / r[0] ** 2) ** 2 + (y / r[1] ** 2) ** 2 + (z / r[2] ** 2) ** 2);
  return k0 * (k0 - 1) / Math.max(k1, 1e-9);
}
function smin(a, b, k) { if (k <= 0) return Math.min(a, b); const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * 0.25; }

function Rig() {
  const r = { bones: [], B: {}, prims: [], slots: [], attach: {} };
  r.bone = (name, parent, head) => { r.B[name] = r.bones.length; r.bones.push({ name, parent: parent == null ? -1 : r.B[parent], head }); };
  const slot = s => { let i = r.slots.indexOf(s); if (i < 0) { i = r.slots.length; r.slots.push(s); } return i; };
  r.E = (bn, c, rad, k, rot = 0, sl = 'coat', rotY = 0) => r.prims.push({ b: r.B[bn], k, s: slot(sl), f: p => sdEllipsoid(p, c, rad, rot, rotY), bb: [c, Math.max(...rad)] });
  r.C = (bn, a, b, r1, r2, k, sl = 'coat') => r.prims.push({ b: r.B[bn], k, s: slot(sl), f: p => sdRoundCone(p, a, b, r1, r2), bb: [[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2], len(sub(a, b)) / 2 + Math.max(r1, r2)] });
  // carve: smooth subtraction applied in sculpt order (later unions can add back, e.g. eyelids over a socket)
  r.X = (bn, c, rad, k, rot = 0, rotY = 0) => r.prims.push({ b: r.B[bn], k, neg: true, s: 0, f: p => sdEllipsoid(p, c, rad, rot, rotY), bb: [c, Math.max(...rad)] });
  return r;
}

// ---------------- species ----------------
// Hoofed quadruped (deer template), scalable into elk / horse
function hoofed(o = {}) {
  const S = o.S || 1, LR = o.legR || 1, TR = o.torsoR || 1, NR = o.neckR || 1, HL = o.headLen || 1, HR = o.headR || 1;
  const P = v => v.map(x => x * S);
  const r = Rig();
  r.bone('root', null, P([0, 1.0, 0]));
  r.bone('hips', 'root', P([0, 1.0, 0]));
  r.bone('chest', 'root', P([0, 1.0, 0]));
  r.bone('neck1', 'chest', P([0.52, 1.07, 0]));
  r.bone('neck2', 'neck1', P(o.neck2 || [0.69, 1.29, 0]));
  r.bone('head', 'neck2', P(o.headJ || [0.81, 1.47, 0]));
  r.bone('tail1', 'hips', P([-0.655, 1.04, 0]));
  r.bone('tail2', 'tail1', P(o.tailLong ? [-0.72, 0.85, 0] : [-0.735, 1.13, 0]));
  for (const [Sd, s] of [['L', 1], ['R', -1]]) {
    r.bone('scap' + Sd, 'chest', P([0.45, 1.12, 0.11 * s]));
    r.bone('hum' + Sd, 'scap' + Sd, P([0.52, 0.87, 0.135 * s]));
    r.bone('rad' + Sd, 'hum' + Sd, P([0.42, 0.66, 0.125 * s]));
    r.bone('canF' + Sd, 'rad' + Sd, P([0.45, 0.345, 0.11 * s]));
    r.bone('pasF' + Sd, 'canF' + Sd, P([0.452, 0.088, 0.11 * s]));
    r.bone('fem' + Sd, 'hips', P([-0.4, 0.95, 0.11 * s]));
    r.bone('tib' + Sd, 'fem' + Sd, P([-0.27, 0.665, 0.14 * s]));
    r.bone('canH' + Sd, 'tib' + Sd, P([-0.54, 0.43, 0.115 * s]));
    r.bone('pasH' + Sd, 'canH' + Sd, P([-0.505, 0.088, 0.11 * s]));
  }
  const E = (b, c, rad, k, rot, sl) => r.E(b, P(c), rad.map(x => x * S), k * S, rot, sl);
  const C = (b, a, bb, r1, r2, k, sl) => r.C(b, P(a), P(bb), r1 * S, r2 * S, k * S, sl);
  const T = (v, m) => [v[0], v[1] * m, v[2] * m];
  E('chest', [0.24, 0.93, 0], T([0.33, 0.24, 0.172], TR), 0.0);
  E('chest', [0.43, 0.83, 0], T([0.15, 0.15, 0.135], TR), 0.12);
  E('chest', [0.36, 1.05, 0], T([0.25, 0.12, 0.12], TR), 0.13, -0.08);
  E('root', [-0.1, 0.95, 0], T([0.34, 0.17, 0.16], TR), 0.15);
  E('root', [-0.18, 1.04, 0], T([0.3, 0.1, 0.13], TR), 0.13);
  E('hips', [-0.44, 0.97, 0], T([0.24, 0.195, 0.16], TR), 0.14);
  E('hips', [-0.47, 1.06, 0], T([0.19, 0.085, 0.125], TR), 0.12, 0.06);
  const nk = o.neckSlot || 'coat';
  C('neck1', [0.48, 1.0, 0], o.neck2 || [0.7, 1.31, 0], 0.165 * NR, 0.105 * NR, 0.1, nk);
  C('neck2', o.neck2 || [0.7, 1.31, 0], o.headJ || [0.81, 1.47, 0], 0.105 * NR, 0.08 * NR, 0.05, nk);
  E('neck1', [0.64, 1.15, 0], [0.095 * NR, 0.15 * NR, 0.09 * NR], 0.07, -0.55, nk);
  const hj = o.headJ || [0.81, 1.47, 0], hd = [hj[0] - 0.81, hj[1] - 1.47];
  const H = (v) => [v[0] + hd[0], v[1] + hd[1], v[2]];
  const mz = (x0, y0, x1, y1) => [x0 + (x1 - x0) * HL, y0 + (y1 - y0) * HL];
  E('head', H([0.845, 1.495, 0]), [0.105 * HR, 0.078 * HR, 0.072 * HR], 0.045, -0.4);
  const m1 = mz(0.895, 1.47, 1.055, 1.385);
  C('head', H([0.895, 1.47, 0]), H([m1[0], m1[1], 0]), 0.062 * HR, 0.038 * HR * (o.muzzleR || 1), 0.04);
  E('head', H([0.905 + (HL - 1) * 0.05, 1.43 - (HL - 1) * 0.02, 0]), [0.085 * HR * (o.jawR || 1), 0.045 * HR * (o.jawR || 1), 0.055 * HR], 0.035, -0.45);
  const m2 = mz(0.895, 1.47, 1.035, 1.378);
  E('head', H([m2[0], m2[1], 0]), [0.042 * HR * (o.muzzleR || 1), 0.04 * HR * (o.muzzleR || 1), 0.036 * HR * (o.muzzleR || 1)], 0.025, -0.4, 'muzzle');
  r.attach.nose = P(H([m1[0] + 0.03 * HR, m1[1] - 0.005, 0]));
  r.attach.eye = P(H([0.885, 1.51, 0.066 * HR]));
  r.attach.ear = P(H([0.8, 1.552, 0.052 * HR]));
  r.attach.antler = P(H([0.825, 1.563, 0.0435]));
  if (o.tailLong) { // horse: long hanging hair tail
    C('tail1', [-0.655, 1.06, 0], [-0.72, 0.85, 0], 0.055, 0.075, 0.04, 'mane');
    C('tail2', [-0.72, 0.85, 0], [-0.745, 0.42, 0], 0.08, 0.035, 0.03, 'mane');
  } else {
    E('tail1', [-0.7, 1.085, 0], [0.042 * (o.tailR || 1), 0.095 * (o.tailL || 1), 0.06 * (o.tailR || 1)], 0.04, 0.55, 'tail');
    E('tail2', [-0.775, 1.2, 0], [0.034 * (o.tailR || 1), 0.1 * (o.tailL || 1), 0.056 * (o.tailR || 1)], 0.03, 0.4, 'tail');
  }
  if (o.mane) { // crest of mane along the neck top + forelock
    for (let i = 0; i <= 9; i++) { const u = i / 9; const x = 0.47 + (hj[0] - 0.04 - 0.47) * u, y = 1.12 + (hj[1] + 0.06 - 1.12) * u;
      E(u < 0.5 ? 'neck1' : 'neck2', [x - 0.03, y + 0.025, 0], [0.075, 0.06, o.horse ? 0.04 : 0.035], 0.04, -0.9, 'mane'); }
    if (o.horse) E('head', H([0.82, 1.56, 0]), [0.05, 0.035, 0.04], 0.03, -0.2, 'mane'); // forelock
  }
  if (o.horse) { // horse masses: deep barrel, rounded croup, thick neck base, muscled shoulders, forearms and gaskins, a broad jowl
    E('root', [0.02, 0.84, 0], T([0.34, 0.16, 0.17], TR), 0.16);
    E('chest', [0.3, 0.83, 0], T([0.2, 0.17, 0.155], TR), 0.12);
    E('hips', [-0.45, 1.03, 0], T([0.23, 0.13, 0.175], TR), 0.12);
    E('hips', [-0.56, 0.96, 0], T([0.13, 0.13, 0.15], TR), 0.1);
    E('neck1', [0.55, 1.06, 0], [0.15 * NR, 0.18 * NR, 0.115 * NR], 0.09, -0.75);
    E('neck1', [0.6, 1.17, 0], [0.11 * NR, 0.12 * NR, 0.085 * NR], 0.07, -0.7);
    E('head', H([0.84, 1.45, 0]), [0.075 * HR, 0.07 * HR, 0.07 * HR], 0.04, -0.3);
    for (const s of [1, -1]) { const Sd = s > 0 ? 'L' : 'R';
      E('scap' + Sd, [0.5, 0.97, 0.15 * s], [0.12, 0.15, 0.055], 0.06, 0.35);
      E('hum' + Sd, [0.47, 0.73, 0.135 * s], [0.055 * LR, 0.1 * LR, 0.05 * LR], 0.04, 0.2);
      E('fem' + Sd, [-0.43, 0.86, 0.15 * s], [0.12, 0.15, 0.06], 0.06, -0.3);
      E('tib' + Sd, [-0.33, 0.6, 0.14 * s], [0.05 * LR, 0.085 * LR, 0.045 * LR], 0.04, 0.35); }
  }
  if (o.ruff) for (let i = 0; i < 3; i++) E('neck1', [0.58 + i * 0.05, 1.08 + i * 0.09, 0], [0.11 * NR, 0.13 * NR, 0.1 * NR], 0.06, -0.5, 'mane');
  for (const s of [1, -1]) {
    const Sd = s > 0 ? 'L' : 'R', z = v => v * s;
    E('scap' + Sd, [0.47, 0.99, z(0.12)], [0.11, 0.18 * TR, 0.075], 0.06, 0.28);
    C('hum' + Sd, [0.52, 0.88, z(0.135)], [0.42, 0.665, z(0.125)], 0.085 * LR, 0.056 * LR, 0.05);
    C('rad' + Sd, [0.42, 0.665, z(0.125)], [0.45, 0.35, z(0.11)], 0.052 * LR, 0.027 * LR, 0.03, 'leg');
    E('canF' + Sd, [0.451, 0.345, z(0.11)], [0.029 * LR, 0.034 * LR, 0.026 * LR], 0.012, 0, 'leg');
    C('canF' + Sd, [0.451, 0.34, z(0.11)], [0.452, 0.09, z(0.11)], 0.021 * LR, 0.019 * LR, 0.012, 'leg');
    E('pasF' + Sd, [0.449, 0.087, z(0.11)], [0.027 * LR, 0.029 * LR, 0.024 * LR], 0.01, 0, o.feathers ? 'mane' : 'leg');
    C('pasF' + Sd, [0.452, 0.085, z(0.11)], [0.468, 0.048, z(0.11)], 0.02 * LR, 0.022 * LR, 0.01, 'leg');
    E('hips', [-0.43, 0.9, z(0.1)], [0.14, 0.17 * TR, 0.1 * TR], 0.08, -0.2);
    E('fem' + Sd, [-0.37, 0.8, z(0.12)], [0.1 * TR, 0.14 * TR, 0.08 * TR], 0.06, -0.25);
    C('fem' + Sd, [-0.36, 0.86, z(0.12)], [-0.27, 0.665, z(0.14)], 0.1 * LR, 0.064 * LR, 0.05);
    C('tib' + Sd, [-0.27, 0.665, z(0.14)], [-0.535, 0.44, z(0.115)], 0.06 * LR, 0.028 * LR, 0.035, 'leg');
    E('canH' + Sd, [-0.552, 0.44, z(0.115)], [0.032 * LR, 0.034 * LR, 0.024 * LR], 0.014, 0, 'leg');
    C('canH' + Sd, [-0.538, 0.43, z(0.115)], [-0.506, 0.09, z(0.11)], 0.024 * LR, 0.019 * LR, 0.012, 'leg');
    E('pasH' + Sd, [-0.504, 0.087, z(0.11)], [0.027 * LR, 0.029 * LR, 0.024 * LR], 0.01, 0, 'leg');
    C('pasH' + Sd, [-0.505, 0.085, z(0.11)], [-0.488, 0.048, z(0.11)], 0.02 * LR, 0.022 * LR, 0.01, 'leg');
  }
  r.kind = 'hoofed'; r.S = S;
  return r;
}

// Canine (wolf; fox = scaled wolf at runtime), digitigrade
function canine() {
  const r = Rig();
  r.bone('root', null, [0, 0.72, 0]);
  r.bone('hips', 'root', [0, 0.72, 0]);
  r.bone('chest', 'root', [0, 0.72, 0]);
  r.bone('neck1', 'chest', [0.38, 0.76, 0]);
  r.bone('neck2', 'neck1', [0.5, 0.86, 0]);
  r.bone('head', 'neck2', [0.6, 0.93, 0]);
  r.bone('tail1', 'hips', [-0.45, 0.74, 0]);
  r.bone('tail2', 'tail1', [-0.6, 0.6, 0]);
  for (const [Sd, s] of [['L', 1], ['R', -1]]) {
    r.bone('scap' + Sd, 'chest', [0.32, 0.82, 0.08 * s]);
    r.bone('hum' + Sd, 'scap' + Sd, [0.37, 0.6, 0.1 * s]);
    r.bone('rad' + Sd, 'hum' + Sd, [0.3, 0.43, 0.095 * s]);
    r.bone('canF' + Sd, 'rad' + Sd, [0.33, 0.12, 0.085 * s]);
    r.bone('pasF' + Sd, 'canF' + Sd, [0.345, 0.04, 0.085 * s]);
    r.bone('fem' + Sd, 'hips', [-0.33, 0.7, 0.08 * s]);
    r.bone('tib' + Sd, 'fem' + Sd, [-0.22, 0.47, 0.1 * s]);
    r.bone('canH' + Sd, 'tib' + Sd, [-0.4, 0.22, 0.085 * s]);
    r.bone('pasH' + Sd, 'canH' + Sd, [-0.37, 0.045, 0.085 * s]);
  }
  const { E, C } = r;
  E('chest', [0.16, 0.66, 0], [0.24, 0.17, 0.125], 0);
  E('chest', [0.3, 0.6, 0], [0.11, 0.12, 0.1], 0.08, 0, 'chestfur');
  E('chest', [0.26, 0.76, 0], [0.17, 0.08, 0.09], 0.09);
  E('root', [-0.08, 0.7, 0], [0.24, 0.1, 0.1], 0.12);
  E('root', [-0.1, 0.74, 0], [0.22, 0.06, 0.09], 0.1);
  E('hips', [-0.32, 0.7, 0], [0.15, 0.12, 0.11], 0.1);
  // neck & ruff
  C('neck1', [0.32, 0.7, 0], [0.5, 0.86, 0], 0.13, 0.085, 0.08);
  E('neck1', [0.4, 0.8, 0], [0.12, 0.14, 0.13], 0.08, -0.6, 'ruff');
  C('neck2', [0.5, 0.86, 0], [0.6, 0.93, 0], 0.085, 0.075, 0.04);
  // head
  E('head', [0.63, 0.95, 0], [0.085, 0.075, 0.07], 0.03, -0.1);
  E('head', [0.62, 0.9, 0], [0.07, 0.05, 0.075], 0.03, 0, 'cheek');
  C('head', [0.68, 0.935, 0], [0.82, 0.905, 0], 0.045, 0.024, 0.03, 'muzzle');
  E('head', [0.72, 0.895, 0], [0.07, 0.025, 0.035], 0.02, -0.15, 'muzzle');
  E('head', [0.825, 0.905, 0], [0.018, 0.016, 0.017], 0.008, 0, 'nose');
  for (const s of [1, -1]) C('head', [0.615, 0.99, 0.042 * s], [0.6, 1.075, 0.058 * s], 0.03, 0.004, 0.015, 'ear');
  r.attach.eye = [0.69, 0.965, 0.042];
  // tail: bushy brush
  C('tail1', [-0.44, 0.74, 0], [-0.6, 0.6, 0], 0.03, 0.055, 0.03, 'coat');
  C('tail2', [-0.6, 0.6, 0], [-0.7, 0.42, 0], 0.058, 0.025, 0.03, 'tailtip');
  for (const s of [1, -1]) {
    const Sd = s > 0 ? 'L' : 'R', z = v => v * s;
    E('scap' + Sd, [0.33, 0.73, z(0.09)], [0.08, 0.13, 0.06], 0.05, 0.25);
    C('hum' + Sd, [0.37, 0.63, z(0.1)], [0.3, 0.43, z(0.095)], 0.06, 0.04, 0.04);
    C('rad' + Sd, [0.3, 0.43, z(0.095)], [0.33, 0.12, z(0.085)], 0.034, 0.022, 0.025, 'leg');
    C('canF' + Sd, [0.33, 0.12, z(0.085)], [0.345, 0.045, z(0.085)], 0.022, 0.02, 0.012, 'leg');
    E('pasF' + Sd, [0.37, 0.025, z(0.085)], [0.042, 0.025, 0.03], 0.015, 0, 'paw');
    E('hips', [-0.31, 0.62, z(0.08)], [0.1, 0.13, 0.075], 0.06, -0.2);
    C('fem' + Sd, [-0.3, 0.64, z(0.09)], [-0.22, 0.47, z(0.1)], 0.07, 0.045, 0.04);
    C('tib' + Sd, [-0.22, 0.47, z(0.1)], [-0.4, 0.22, z(0.085)], 0.045, 0.022, 0.03, 'leg');
    C('canH' + Sd, [-0.4, 0.22, z(0.085)], [-0.37, 0.05, z(0.085)], 0.022, 0.019, 0.012, 'leg');
    E('pasH' + Sd, [-0.345, 0.025, z(0.085)], [0.042, 0.025, 0.03], 0.015, 0, 'paw');
  }
  r.kind = 'canine'; r.S = 1;
  return r;
}

// Rabbit (same bone names; hop gait)
function rabbit() {
  const r = Rig();
  r.bone('root', null, [0, 0.16, 0]);
  r.bone('hips', 'root', [0, 0.16, 0]);
  r.bone('chest', 'root', [0, 0.16, 0]);
  r.bone('neck1', 'chest', [0.09, 0.19, 0]);
  r.bone('neck2', 'neck1', [0.12, 0.22, 0]);
  r.bone('head', 'neck2', [0.14, 0.24, 0]);
  r.bone('tail1', 'hips', [-0.13, 0.17, 0]);
  r.bone('tail2', 'tail1', [-0.15, 0.18, 0]);
  for (const [Sd, s] of [['L', 1], ['R', -1]]) {
    r.bone('scap' + Sd, 'chest', [0.08, 0.17, 0.035 * s]);
    r.bone('hum' + Sd, 'scap' + Sd, [0.09, 0.12, 0.04 * s]);
    r.bone('rad' + Sd, 'hum' + Sd, [0.08, 0.08, 0.04 * s]);
    r.bone('canF' + Sd, 'rad' + Sd, [0.095, 0.025, 0.035 * s]);
    r.bone('pasF' + Sd, 'canF' + Sd, [0.105, 0.012, 0.035 * s]);
    r.bone('fem' + Sd, 'hips', [-0.08, 0.15, 0.05 * s]);
    r.bone('tib' + Sd, 'fem' + Sd, [-0.02, 0.09, 0.055 * s]);
    r.bone('canH' + Sd, 'tib' + Sd, [-0.1, 0.03, 0.05 * s]);
    r.bone('pasH' + Sd, 'canH' + Sd, [-0.03, 0.012, 0.05 * s]);
  }
  const { E, C } = r;
  E('hips', [-0.06, 0.15, 0], [0.11, 0.1, 0.085], 0);
  E('chest', [0.05, 0.15, 0], [0.08, 0.075, 0.065], 0.05);
  E('chest', [0.07, 0.12, 0], [0.05, 0.05, 0.05], 0.03, 0, 'belly');
  C('neck1', [0.07, 0.18, 0], [0.13, 0.22, 0], 0.045, 0.04, 0.03);
  E('head', [0.155, 0.235, 0], [0.05, 0.042, 0.038], 0.02, -0.25);
  E('head', [0.195, 0.222, 0], [0.025, 0.022, 0.025], 0.012, -0.3, 'muzzle');
  r.attach.eye = [0.17, 0.25, 0.031]; r.attach.ear = [0.135, 0.27, 0.018];
  E('tail1', [-0.155, 0.17, 0], [0.025, 0.025, 0.025], 0.01, 0, 'tail');
  for (const s of [1, -1]) {
    const Sd = s > 0 ? 'L' : 'R', z = v => v * s;
    C('hum' + Sd, [0.09, 0.13, z(0.04)], [0.08, 0.08, z(0.04)], 0.018, 0.012, 0.015);
    C('rad' + Sd, [0.08, 0.08, z(0.04)], [0.095, 0.025, z(0.035)], 0.011, 0.009, 0.01);
    E('pasF' + Sd, [0.105, 0.012, z(0.035)], [0.018, 0.01, 0.01], 0.006, 0, 'paw');
    E('fem' + Sd, [-0.06, 0.12, z(0.055)], [0.055, 0.05, 0.03], 0.03, -0.3);
    C('tib' + Sd, [-0.02, 0.09, z(0.055)], [-0.1, 0.03, z(0.05)], 0.02, 0.012, 0.012);
    C('canH' + Sd, [-0.1, 0.03, z(0.05)], [-0.03, 0.012, z(0.05)], 0.013, 0.011, 0.008, 'paw');
  }
  r.kind = 'rabbit'; r.S = 1;
  return r;
}

// Human hiker (biped), facing +X
function human() {
  const r = Rig();
  r.bone('root', null, [0, 0.98, 0]);
  r.bone('spine', 'root', [0, 1.1, 0]);
  r.bone('chest', 'spine', [0, 1.3, 0]);
  r.bone('neck', 'chest', [0.01, 1.48, 0]);
  r.bone('head', 'neck', [0.02, 1.6, 0]);
  for (const [Sd, s] of [['L', 1], ['R', -1]]) {
    r.bone('thigh' + Sd, 'root', [0, 0.94, 0.095 * s]);
    r.bone('shin' + Sd, 'thigh' + Sd, [0.0, 0.52, 0.1 * s]);
    r.bone('foot' + Sd, 'shin' + Sd, [-0.01, 0.09, 0.1 * s]);
    r.bone('clav' + Sd, 'chest', [0, 1.42, 0.05 * s]);
    r.bone('arm' + Sd, 'clav' + Sd, [-0.01, 1.42, 0.19 * s]);
    r.bone('fore' + Sd, 'arm' + Sd, [-0.02, 1.14, 0.215 * s]);
    r.bone('hand' + Sd, 'fore' + Sd, [-0.005, 0.89, 0.225 * s]);
  }
  const { E, C } = r;
  E('root', [0, 0.96, 0], [0.12, 0.11, 0.175], 0.0, 0, 'pants');
  E('spine', [0.0, 1.09, 0], [0.11, 0.1, 0.155], 0.05, 0, 'shirt');
  E('chest', [0.01, 1.3, 0], [0.12, 0.16, 0.18], 0.06, 0, 'shirt');
  E('chest', [0.0, 1.4, 0], [0.09, 0.07, 0.19], 0.05, 0, 'shirt');
  C('neck', [0.01, 1.44, 0], [0.025, 1.6, 0], 0.055, 0.048, 0.025, 'skin');
  E('head', [0.03, 1.665, 0], [0.098, 0.118, 0.083], 0.02, 0, 'skin');
  E('head', [0.06, 1.615, 0], [0.068, 0.058, 0.064], 0.03, 0, 'skin');
  E('head', [0.122, 1.66, 0], [0.018, 0.028, 0.014], 0.012, -0.3, 'skin');
  E('head', [0.0, 1.705, 0], [0.105, 0.09, 0.09], 0.012, 0.2, 'hair');
  for (const s of [1, -1]) E('head', [0.02, 1.665, 0.085 * s], [0.018, 0.028, 0.012], 0.01, 0, 'skin');
  r.attach.eye = [0.112, 1.685, 0.035];
  E('chest', [-0.165, 1.25, 0], [0.085, 0.2, 0.15], 0.015, 0, 'pack');
  E('chest', [-0.2, 1.06, 0], [0.07, 0.06, 0.13], 0.01, 0, 'pack2');
  for (const s of [1, -1]) {
    const Sd = s > 0 ? 'L' : 'R', z = v => v * s;
    C('clav' + Sd, [0, 1.43, z(0.05)], [-0.01, 1.42, z(0.19)], 0.06, 0.058, 0.04, 'shirt');
    C('arm' + Sd, [-0.01, 1.42, z(0.19)], [-0.02, 1.14, z(0.215)], 0.05, 0.042, 0.03, 'shirt');
    C('fore' + Sd, [-0.02, 1.14, z(0.215)], [-0.005, 0.9, z(0.225)], 0.04, 0.031, 0.02, 'skin');
    E('hand' + Sd, [0.0, 0.83, z(0.225)], [0.03, 0.06, 0.02], 0.015, 0, 'skin');
    C('thigh' + Sd, [0, 0.94, z(0.095)], [0, 0.52, z(0.1)], 0.085, 0.056, 0.035, 'pants');
    C('shin' + Sd, [0, 0.52, z(0.1)], [-0.01, 0.13, z(0.1)], 0.054, 0.038, 0.025, 'pants');
    C('foot' + Sd, [-0.01, 0.15, z(0.1)], [-0.01, 0.06, z(0.1)], 0.05, 0.048, 0.02, 'boots');
    E('foot' + Sd, [0.035, 0.045, z(0.1)], [0.115, 0.045, 0.05], 0.025, 0, 'boots');
  }
  r.kind = 'human'; r.S = 1;
  return r;
}


// Player hiker from the v0.7 hiking design: charcoal shirt (sleeves pushed), olive softshell vest, tan hiking pants, black mid boots, wool socks, daypack
function athlete() {
  // Hybrid athlete from the character sheet: 5'11" lean V-taper, compression top, baggy joggers with cuffs, white socks, chunky runners,
  // full beard, curly top with locs tied back. Sculpted in rest pose (facing +x, left side +z).
  const r = Rig();
  r.bone('root', null, [0, 1.0, 0]);
  r.bone('spine', 'root', [0, 1.12, 0]);
  r.bone('chest', 'spine', [0, 1.32, 0]);
  r.bone('neck', 'chest', [0.012, 1.5, 0]);
  r.bone('head', 'neck', [0.022, 1.62, 0]);
  for (const [Sd, s] of [['L', 1], ['R', -1]]) {
    r.bone('thigh' + Sd, 'root', [0, 0.96, 0.095 * s]);
    r.bone('shin' + Sd, 'thigh' + Sd, [0.0, 0.53, 0.1 * s]);
    r.bone('foot' + Sd, 'shin' + Sd, [-0.01, 0.095, 0.1 * s]);
    r.bone('clav' + Sd, 'chest', [0, 1.44, 0.05 * s]);
    r.bone('arm' + Sd, 'clav' + Sd, [-0.01, 1.44, 0.205 * s]);
    r.bone('fore' + Sd, 'arm' + Sd, [-0.02, 1.155, 0.23 * s]);
    r.bone('hand' + Sd, 'fore' + Sd, [-0.005, 0.9, 0.24 * s]);
  }
  const { E, C, X } = r;
  // ---- torso: compression top shows the muscle under it ----
  E('root', [0, 0.975, 0], [0.105, 0.1, 0.158], 0, 0, 'pants');
  E('root', [-0.045, 0.93, 0], [0.07, 0.075, 0.14], 0.03, 0, 'pants');               // seat
  E('spine', [0.0, 1.1, 0], [0.09, 0.1, 0.132], 0.045, 0, 'shirt');                  // waist
  E('chest', [0.01, 1.3, 0], [0.11, 0.16, 0.17], 0.06, 0, 'vest');                   // rib cage under the softshell vest
  E('chest', [0.0, 1.26, 0], [0.122, 0.17, 0.176], 0.03, 0, 'vest');                  // vest shell sits a few mm proud
  E('spine', [0.0, 1.06, 0], [0.098, 0.03, 0.14], 0.02, 0, 'vest');                   // vest hem
  for (const s of [1, -1]) {
    E('chest', [0.072, 1.352, 0.068 * s], [0.045, 0.058, 0.074], 0.028, -0.1, 'vest'); // pecs
    E('chest', [-0.032, 1.29, 0.128 * s], [0.06, 0.135, 0.055], 0.04, 0.12 * s, 'vest'); // lats (V-taper)
    E('chest', [-0.025, 1.462, 0.085 * s], [0.045, 0.035, 0.07], 0.035, 0, 'shirt');  // traps
    E('spine', [0.05, 1.11, 0.105 * s], [0.035, 0.07, 0.03], 0.03, 0, 'shirt');       // obliques
    E('chest', [-0.085, 1.33, 0.045 * s], [0.03, 0.09, 0.04], 0.03, 0, 'vest');      // upper back
  }
  E('chest', [0.0, 1.415, 0], [0.08, 0.065, 0.19], 0.05, 0, 'vest');
  for (const s of [1, -1]) C('chest', [0.075, 1.47, 0.05 * s], [0.06, 1.485, 0.085 * s], 0.014, 0.012, 0.01, 'vest'); // vest collar
  C('chest', [0.02, 1.47, 0], [0.02, 1.5, 0], 0.062, 0.058, 0.01, 'shirt');         // crew neck collar
  C('neck', [0.012, 1.45, 0], [0.026, 1.6, 0], 0.054, 0.048, 0.025, 'skin');
  E('neck', [0.045, 1.545, 0], [0.012, 0.018, 0.012], 0.012, 0, 'skin');             // Adam's apple
  for (const s of [1, -1]) C('neck', [-0.005, 1.6, 0.04 * s], [0.04, 1.49, 0.015 * s], 0.014, 0.012, 0.015, 'skin'); // neck cords
  // ---- head ----
  E('head', [0.022, 1.7, 0], [0.096, 0.112, 0.079], 0.02, 0, 'skin');                // cranium
  E('head', [-0.012, 1.72, 0], [0.085, 0.095, 0.077], 0.02, 0, 'skin');              // back of skull
  E('head', [0.07, 1.735, 0], [0.05, 0.045, 0.068], 0.02, 0, 'skin');                // forehead
  E('head', [0.106, 1.718, 0], [0.016, 0.011, 0.06], 0.01, 0, 'skin');               // brow ridge
  for (const s of [1, -1]) {
    E('head', [0.088, 1.675, 0.057 * s], [0.026, 0.017, 0.024], 0.016, 0, 'skin');   // cheekbones
    C('head', [0.005, 1.63, 0.062 * s], [0.092, 1.585, 0.034 * s], 0.026, 0.02, 0.02, 'skin'); // jaw line
    X('head', [0.12, 1.699, 0.033 * s], [0.0125, 0.0105, 0.0165], 0.006);              // eye socket
    E('head', [0.117, 1.7065, 0.033 * s], [0.0105, 0.0055, 0.0158], 0.004, 0.18, 'lid'); // upper lid
    E('head', [0.1155, 1.6905, 0.033 * s], [0.0085, 0.0035, 0.0135], 0.004, -0.1, 'lid'); // lower lid
    E('head', [0.121, 1.7215, 0.033 * s], [0.007, 0.0042, 0.019], 0.003, -0.08 * s, 'brow'); // eyebrow
    E('head', [0.133, 1.6555, 0.0155 * s], [0.0105, 0.0085, 0.009], 0.005, 0, 'skin'); // nose wings
    X('head', [0.1395, 1.6485, 0.008 * s], [0.0052, 0.0028, 0.0038], 0.002);           // nostrils
    E('head', [0.011, 1.686, 0.087 * s], [0.013, 0.029, 0.0085], 0.004, 0.1, 'skin');  // ears
    X('head', [0.015, 1.686, 0.095 * s], [0.0075, 0.017, 0.0045], 0.003);              // ear hollow
  }
  C('head', [0.118, 1.712, 0], [0.141, 1.665, 0], 0.0068, 0.0098, 0.006, 'skin');    // nose bridge
  E('head', [0.142, 1.661, 0], [0.0125, 0.0115, 0.0145], 0.006, 0, 'skin');          // nose tip
  E('head', [0.1285, 1.632, 0], [0.0095, 0.0068, 0.022], 0.004, 0, 'lips');          // upper lip
  E('head', [0.1255, 1.6195, 0], [0.0105, 0.0075, 0.0195], 0.004, 0, 'lips');        // lower lip
  X('head', [0.1365, 1.6262, 0], [0.006, 0.0012, 0.0205], 0.0018);                   // mouth line
  E('head', [0.113, 1.588, 0], [0.022, 0.022, 0.026], 0.015, 0, 'skin');             // chin
  // ---- hair + beard (fur shells are grown on these slots up close) ----
  E('head', [-0.002, 1.748, 0], [0.104, 0.084, 0.09], 0.012, 0.25, 'hair');          // curly top
  E('head', [0.055, 1.79, 0], [0.06, 0.035, 0.07], 0.02, 0, 'hair');
  E('head', [0.07, 1.6, 0], [0.062, 0.05, 0.066], 0.02, 0.25, 'beard');              // full beard over the jaw
  E('head', [0.108, 1.566, 0], [0.034, 0.042, 0.034], 0.02, 0.35, 'beard');          // pointed chin beard
  E('head', [0.122, 1.6425, 0], [0.0085, 0.006, 0.027], 0.004, 0, 'beard');          // moustache
  for (const s of [1, -1]) E('head', [0.045, 1.645, 0.066 * s], [0.03, 0.05, 0.018], 0.014, 0, 'beard'); // sideburns into beard
  r.attach.eye = [0.11, 1.705, 0.034];
  r.attach.eyeC = [0.1115, 1.699, 0.033];
  r.attach.ear = [0.02, 1.672, 0.09];
  // ---- trail pack + straps ----
  E('chest', [-0.17, 1.26, 0], [0.085, 0.215, 0.15], 0.012, 0, 'pack');
  E('chest', [-0.215, 1.12, 0], [0.06, 0.065, 0.13], 0.01, 0, 'pack');
  C('chest', [-0.19, 1.07, -0.15], [-0.19, 1.27, -0.15], 0.032, 0.03, 0.004, 'bottle'); // water bottle, right side pocket
  for (const s of [1, -1]) C('chest', [0.02, 1.44, 0.11 * s], [0.1, 1.2, 0.12 * s], 0.012, 0.012, 0.004, 'strap');
  C('spine', [0.09, 1.08, -0.13], [0.09, 1.08, 0.13], 0.011, 0.011, 0.004, 'strap');
  // ---- arms + legs ----
  for (const s of [1, -1]) {
    const Sd = s > 0 ? 'L' : 'R', z = v => v * s;
    C('clav' + Sd, [0, 1.445, z(0.05)], [-0.01, 1.44, z(0.2)], 0.058, 0.056, 0.04, 'shirt');
    E('arm' + Sd, [-0.002, 1.415, z(0.21)], [0.067, 0.07, 0.068], 0.03, 0, 'shirt');         // deltoid
    C('arm' + Sd, [-0.01, 1.42, z(0.205)], [-0.02, 1.155, z(0.23)], 0.05, 0.036, 0.03, 'shirt');
    E('arm' + Sd, [0.024, 1.29, z(0.22)], [0.038, 0.075, 0.039], 0.022, 0, 'shirt');          // biceps
    E('arm' + Sd, [-0.042, 1.32, z(0.222)], [0.033, 0.08, 0.036], 0.022, 0, 'shirt');         // triceps
    C('fore' + Sd, [-0.02, 1.155, z(0.23)], [-0.005, 0.91, z(0.24)], 0.043, 0.027, 0.02, 'skin');
    E('fore' + Sd, [0.0, 1.085, z(0.232)], [0.035, 0.065, 0.038], 0.02, 0, 'skin');           // forearm muscle
    E('arm' + Sd, [-0.018, 1.175, z(0.228)], [0.05, 0.03, 0.05], 0.012, 0, 'sleeve');         // sleeve pushed up, bunched above the elbow
    E('arm' + Sd, [-0.016, 1.21, z(0.226)], [0.048, 0.022, 0.048], 0.012, 0.15 * s, 'sleeve');
    E('hand' + Sd, [0.0, 0.85, z(0.24)], [0.027, 0.052, 0.018], 0.014, 0, 'skin');            // palm (fingers are attached separately)
    if (s > 0) E('fore' + Sd, [-0.006, 0.925, z(0.24)], [0.034, 0.016, 0.034], 0.004, 0, 'watch');
    // joggers: roomy through the thigh, gathered at the cuff with bunching above it
    C('thigh' + Sd, [0, 0.96, z(0.095)], [0, 0.53, z(0.1)], 0.094, 0.07, 0.035, 'pants');
    E('thigh' + Sd, [0.03, 0.72, z(0.1)], [0.05, 0.12, 0.06], 0.04, 0, 'pants');              // quad mass under the fabric
    C('shin' + Sd, [0, 0.53, z(0.1)], [-0.008, 0.17, z(0.1)], 0.068, 0.056, 0.025, 'pants');
    E('thigh' + Sd, [-0.005, 0.72, z(0.162)], [0.05, 0.075, 0.022], 0.012, 0, 'pocket');     // cargo pocket on the outer thigh
    E('shin' + Sd, [0.045, 0.53, z(0.1)], [0.03, 0.04, 0.055], 0.02, 0, 'pants');            // articulated knee
    for (const [y, rr] of [[0.25, 0.064], [0.31, 0.063]]) E('shin' + Sd, [-0.006, y, z(0.1)], [rr, 0.012, rr], 0.012, 0.06 * s, 'pants'); // soft stacking over the boot
    // black leather mid boot: shaft, padded collar, toe box, heel, chunky lugged sole; wool sock folded over the collar
    C('foot' + Sd, [-0.012, 0.2, z(0.1)], [-0.01, 0.07, z(0.1)], 0.05, 0.05, 0.012, 'shoes');
    E('foot' + Sd, [-0.012, 0.205, z(0.1)], [0.054, 0.018, 0.054], 0.01, 0, 'socks');
    E('foot' + Sd, [0.05, 0.06, z(0.1)], [0.128, 0.05, 0.056], 0.018, 0, 'shoes');
    E('foot' + Sd, [0.135, 0.045, z(0.1)], [0.052, 0.036, 0.05], 0.02, 0, 'shoes');
    E('foot' + Sd, [-0.06, 0.075, z(0.1)], [0.042, 0.055, 0.05], 0.015, 0, 'shoes');
    E('foot' + Sd, [0.04, 0.018, z(0.1)], [0.148, 0.02, 0.062], 0.006, 0, 'sole');
  }
  r.kind = 'human'; r.S = 1;
  return r;
}

const SPECIES = {
  deer: { make: () => hoofed(), cells: [0.007, 0.022, 0.0506] },
  elk: { make: () => hoofed({ S: 1.38, torsoR: 1.08, neckR: 1.2, legR: 1.05, ruff: true, neckSlot: 'mane', tailR: 0.7, tailL: 0.55, headLen: 1.12 }), cells: [0.014, 0.04, 0.092] },
  horse: { make: () => hoofed({ S: 1.55, torsoR: 1.2, neckR: 1.55, legR: 1.45, headLen: 1.7, headR: 1.15, muzzleR: 1.4, jawR: 1.5, mane: true, horse: true, tailLong: true, neck2: [0.64, 1.26, 0], headJ: [0.73, 1.41, 0] }), cells: [0.016, 0.046, 0.1058] },
  wolf: { make: canine, cells: [0.0085, 0.025, 0.0575] },
  rabbit: { make: rabbit, cells: [0.004, 0.011, 0.0253] },
  human: { make: human, cells: [0.008, 0.024, 0.0552] },
  athlete: { make: athlete, cells: [0.0072, 0.019, 0.0437], detail: { H: 0.0027, box: [[-0.14, 1.52, -0.135], [0.19, 1.86, 0.135]], clip: [[-0.13, 1.548, -0.125], [0.18, 1.85, 0.125]] } },
};

function build(rig, H, opt = {}) {
  const { prims } = rig, pos = prims.filter(p => !p.neg);
  function sdf(p) {
    let d = 1e9;
    for (const pr of prims) {
      const far = len(sub(p, pr.bb[0])) - pr.bb[1];
      if (pr.neg) { if (far > pr.k + 1e-4) continue; d = -smin(-d, pr.f(p), pr.k); continue; }
      if (far - d > pr.k + 1e-4) continue;
      d = smin(d, pr.f(p), pr.k);
    }
    return d;
  }
  const grad = (p, e = H * 0.18) => { const g = [sdf([p[0] + e, p[1], p[2]]) - sdf([p[0] - e, p[1], p[2]]), sdf([p[0], p[1] + e, p[2]]) - sdf([p[0], p[1] - e, p[2]]), sdf([p[0], p[1], p[2] + e]) - sdf([p[0], p[1], p[2] - e])]; const l = len(g) || 1; return g.map(v => v / l); };
  const min = [1e9, 1e9, 1e9], max = [-1e9, -1e9, -1e9];
  for (const pr of pos) for (let c = 0; c < 3; c++) { min[c] = Math.min(min[c], pr.bb[0][c] - pr.bb[1] - 2 * H); max[c] = Math.max(max[c], pr.bb[0][c] + pr.bb[1] + 2 * H); }
  if (opt.box) for (let c = 0; c < 3; c++) { min[c] = Math.max(min[c], opt.box[0][c]); max[c] = Math.min(max[c], opt.box[1][c]); } // detail piece: only this region
  const nx = Math.ceil((max[0] - min[0]) / H) + 1, ny = Math.ceil((max[1] - min[1]) / H) + 1, nz = Math.ceil((max[2] - min[2]) / H) + 1;
  const field = new Float32Array(nx * ny * nz), idx = (i, j, k) => (k * ny + j) * nx + i;
  for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) field[idx(i, j, k)] = sdf([min[0] + i * H, min[1] + j * H, min[2] + k * H]);
  const vmap = new Int32Array((nx - 1) * (ny - 1) * (nz - 1)).fill(-1), cidx = (i, j, k) => (k * (ny - 1) + j) * (nx - 1) + i;
  const verts = [], corners = [[0,0,0],[1,0,0],[0,1,0],[1,1,0],[0,0,1],[1,0,1],[0,1,1],[1,1,1]], edges = [[0,1],[2,3],[4,5],[6,7],[0,2],[1,3],[4,6],[5,7],[0,4],[1,5],[2,6],[3,7]];
  for (let k = 0; k < nz - 1; k++) for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const v = corners.map(c => field[idx(i + c[0], j + c[1], k + c[2])]);
    let inside = 0; for (const x of v) if (x < 0) inside++;
    if (inside === 0 || inside === 8) continue;
    let sx = 0, sy = 0, sz = 0, n = 0;
    for (const [a, b] of edges) { if ((v[a] < 0) === (v[b] < 0)) continue; const t = v[a] / (v[a] - v[b]), ca = corners[a], cb = corners[b];
      sx += ca[0] + (cb[0] - ca[0]) * t; sy += ca[1] + (cb[1] - ca[1]) * t; sz += ca[2] + (cb[2] - ca[2]) * t; n++; }
    vmap[cidx(i, j, k)] = verts.length;
    verts.push([min[0] + (i + sx / n) * H, min[1] + (j + sy / n) * H, min[2] + (k + sz / n) * H]);
  }
  const tris = [];
  const quad = (a, b, c, d, flip) => { if (a < 0 || b < 0 || c < 0 || d < 0) return; if (flip) tris.push(a, c, b, a, d, c); else tris.push(a, b, c, a, c, d); };
  for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {
    const f0 = field[idx(i, j, k)] < 0;
    if ((field[idx(i + 1, j, k)] < 0) !== f0) quad(vmap[cidx(i, j - 1, k - 1)], vmap[cidx(i, j, k - 1)], vmap[cidx(i, j, k)], vmap[cidx(i, j - 1, k)], !f0);
    if ((field[idx(i, j + 1, k)] < 0) !== f0) quad(vmap[cidx(i - 1, j, k - 1)], vmap[cidx(i - 1, j, k)], vmap[cidx(i, j, k)], vmap[cidx(i, j, k - 1)], !f0);
    if ((field[idx(i, j, k + 1)] < 0) !== f0) quad(vmap[cidx(i - 1, j - 1, k)], vmap[cidx(i, j - 1, k)], vmap[cidx(i, j, k)], vmap[cidx(i - 1, j, k)], !f0);
  }
  if (opt.clip) { const [a, b] = opt.clip, inside = v => v[0] > a[0] && v[1] > a[1] && v[2] > a[2] && v[0] < b[0] && v[1] < b[1] && v[2] < b[2];
    const keep = []; for (let t = 0; t < tris.length; t += 3) if (!(inside(verts[tris[t]]) && inside(verts[tris[t + 1]]) && inside(verts[tris[t + 2]]))) keep.push(tris[t], tris[t + 1], tris[t + 2]);
    // compact: drop vertices no triangle uses any more
    const used = new Int32Array(verts.length).fill(-1), nv = []; for (const t of keep) if (used[t] < 0) { used[t] = nv.length; nv.push(verts[t]); }
    tris.length = 0; for (const t of keep) tris.push(used[t]); verts.length = 0; for (const v of nv) verts.push(v); }
  const normals = verts.map(p => { for (let it = 0; it < 3; it++) { const d = sdf(p), g = grad(p); p[0] -= g[0] * d; p[1] -= g[1] * d; p[2] -= g[2] * d; } return grad(p); });
  let agree = 0;
  for (let t = 0; t < tris.length; t += 3) { const a = verts[tris[t]], u = sub(verts[tris[t + 1]], a), v = sub(verts[tris[t + 2]], a);
    agree += Math.sign(dot([u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]], normals[tris[t]])); }
  if (agree < 0) for (let t = 0; t < tris.length; t += 3) { const x = tris[t + 1]; tris[t + 1] = tris[t + 2]; tris[t + 2] = x; }
  const n = verts.length, SI = new Uint8Array(n * 4), SW = new Uint8Array(n * 4), SL = new Uint8Array(n * 3);
  const SIG = 0.02 * (rig.S || 1) * (rig.kind === 'rabbit' ? 0.3 : rig.kind === 'human' ? 0.6 : 1), SIGC = SIG * 0.35;
  verts.forEach((p, vi) => {
    const ds = pos.map(pr => pr.f(p)); const dmin = Math.min(...ds);
    const per = new Map(), cs = new Map();
    pos.forEach((pr, i) => { const w = Math.exp(-(ds[i] - dmin) / SIG); if (w > 1e-3) per.set(pr.b, (per.get(pr.b) || 0) + w);
      const wc = Math.exp(-(ds[i] - dmin) / SIGC); if (wc > 1e-3) cs.set(pr.s, (cs.get(pr.s) || 0) + wc); });
    const top = [...per.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4), sum = top.reduce((s, x) => s + x[1], 0);
    const q = top.map(([, w]) => Math.floor(w / sum * 255)); q[0] += 255 - q.reduce((a, b) => a + b, 0);
    top.forEach(([b], j) => { SI[vi * 4 + j] = b; SW[vi * 4 + j] = q[j]; });
    const ct = [...cs.entries()].sort((a, b) => b[1] - a[1]);
    const a = ct[0], b = ct[1] || ct[0];
    SL[vi * 3] = a[0]; SL[vi * 3 + 1] = b[0]; SL[vi * 3 + 2] = Math.round(255 * b[1] / (a[1] + b[1]));
  });
  const sc = sub(max, min), Pq = new Int16Array(n * 3), Nq = new Int8Array(n * 4);
  verts.forEach((p, i) => { for (let c = 0; c < 3; c++) { Pq[i * 3 + c] = Math.round(((p[c] - min[c]) / sc[c]) * 65535 - 32768); Nq[i * 4 + c] = Math.round(normals[i][c] * 127); } });
  const I = n < 65536 ? new Uint16Array(tris) : new Uint32Array(tris);
  const b64 = a => Buffer.from(a.buffer, a.byteOffset, a.byteLength).toString('base64');
  return { lo: min, sc, count: n, idx32: !(I instanceof Uint16Array), P: b64(Pq), N: b64(Nq), I: b64(I), SI: b64(SI), SW: b64(SW), SL: b64(SL), sdf };
}

const names = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(SPECIES);
for (const name of names) {
  const t0 = Date.now(), sp = SPECIES[name], rig = sp.make();
  const lods = sp.cells.map((H, i) => build(rig, H, i === 0 && sp.detail ? { clip: sp.detail.clip } : {}));
  if (sp.detail) { const L = build(rig, sp.detail.H, { box: sp.detail.box }); L.part = 'head'; lods.push(L); }
  const sdf = lods[0].sdf;
  // snap attachment points onto the surface (march inward along +z / +y)
  const snap = (p, dirv) => { const l = len(dirv); dirv = dirv.map(v => v / l); let q = p.map((v, i) => v + dirv[i] * 0.3 * (rig.S || 1));
    for (let i = 0; i < 300; i++) { const d = sdf(q); if (d < 0.0003) break; q = q.map((v, k) => v - dirv[k] * d); } return q.map(v => +v.toFixed(4)); };
  const attach = {};
  if (rig.attach.eye) attach.eye = snap([rig.attach.eye[0], rig.attach.eye[1], 0], [0, 0, 1]);
  if (rig.attach.eyeC) attach.eyeC = rig.attach.eyeC; // sculpted socket centre (eyeball goes here)
  if (rig.attach.ear) attach.ear = snap([rig.attach.ear[0], rig.attach.ear[1] - 0.05 * (rig.S || 1), rig.attach.ear[2]], [0, 1, 0.3]);
  if (rig.attach.antler) attach.antler = snap([rig.attach.antler[0], rig.attach.antler[1] - 0.05 * rig.S, rig.attach.antler[2]], [0, 1, 0.15]);
  if (rig.attach.nose) attach.nose = snap([rig.attach.nose[0] - 0.1 * rig.S, rig.attach.nose[1], 0], [1, -0.3, 0]);
  lods.forEach(l => delete l.sdf);
  const out = { name, kind: rig.kind, S: rig.S, bones: rig.bones, slots: rig.slots, attach, lods };
  fs.writeFileSync(`${dir}/data/${name}.js`, `(window.SP=window.SP||{})[${JSON.stringify(name)}]=` + JSON.stringify(out) + ';');
  console.log(name, lods.map(l => l.count).join('/'), 'verts', ((fs.statSync(`${dir}/data/${name}.js`).size) / 1e6).toFixed(2), 'MB', ((Date.now() - t0) / 1000).toFixed(1) + 's', JSON.stringify(attach));
}
