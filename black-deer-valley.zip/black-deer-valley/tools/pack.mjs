// data/*.js (JSON+base64) -> data/<name>.bin (raw typed arrays) + data/<name>.json (meta + offsets)
import fs from 'fs';
for (const f of fs.readdirSync('data').filter(f => f.endsWith('.js'))) {
  const src = fs.readFileSync('data/' + f, 'utf8'); const D = JSON.parse(src.slice(src.indexOf(']=') + 2, -1));
  const parts = []; let off = 0;
  const add = b64 => { const b = Buffer.from(b64, 'base64'); const pad = (4 - (off % 4)) % 4; if (pad) { parts.push(Buffer.alloc(pad)); off += pad; } const o = off; parts.push(b); off += b.length; return [o, b.length]; };
  const meta = { ...D, lods: D.lods.map(L => { const o = { lo: L.lo, sc: L.sc, count: L.count, idx32: L.idx32, part: L.part }; for (const k of ['P', 'N', 'I', 'SI', 'SW', 'SL']) o[k] = add(L[k]); return o; }) };
  fs.writeFileSync('data/' + D.name + '.bin', Buffer.concat(parts)); fs.writeFileSync('data/' + D.name + '.json', JSON.stringify(meta));
  console.log(D.name, (off / 1e6).toFixed(2) + 'MB bin', (fs.statSync('data/' + f).size / 1e6).toFixed(2) + 'MB before');
}
