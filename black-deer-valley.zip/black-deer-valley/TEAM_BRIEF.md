# Hiker 3D model brief

**Goal:** a real textured, rigged 3D hiker that matches `docs/hiker-character-sheet.jpg`, replacing the code-built blocky one.

## Design (from the sheet)
- Man, medium-brown skin, full beard, locs: top knot with the rest hanging, no earrings
- Charcoal long-sleeve shirt, sleeves pushed up; olive zip softshell vest
- Tan cargo pants, grey wool socks folded over black lace-up hiking boots
- Black daypack with chest strap, side water bottle; black smartwatch on left wrist
- No brand logos

## Specs
- 1.80 m tall, facing -Y, A-pose, feet on the ground plane
- Up to 25k triangles, one 2K texture set (base colour, normal, roughness/metal)
- Separate meshes for backpack and hair
- Mixamo auto-rig; clips without skin: idle, walk, jog, sprint, jump, jab-cross, low kick, knocked out, get up, sitting (riding), drink
- Export one `hiker.glb` (+Y up, all animations) and send it back

## How the game uses it
`creatures.js` drives bones named root, spine, chest, neck, head, thighL/R, shinL/R, footL/R, clavL/R, armL/R, foreL/R, handL/R. A Mixamo-to-these-names map is planned (v0.7 plan). If `hiker.glb` is missing the old hiker still loads.
