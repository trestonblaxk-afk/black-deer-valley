// Adaptive score, synthesized live (no files): plucked guitar, cello, pads, music box, slide, piano, drums.
// Six moods crossfade by time of day, weather and combat; phrases breathe with rests so it never wears thin.
export function createMusic(ctx, out) {
  const SR = ctx.sampleRate, rnd = Math.random;
  const bus = ctx.createGain(); bus.gain.value = 0.55;
  // room: generated impulse response (2.6 s, darker tail)
  const verb = ctx.createConvolver(); {
    const n = Math.floor(SR * 2.6), ir = ctx.createBuffer(2, n, SR);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let lp = 0; for (let i = 0; i < n; i++) { const t = i / n; lp += (rnd() * 2 - 1 - lp) * (0.5 - 0.42 * t); d[i] = lp * Math.pow(1 - t, 2.4); } }
    verb.buffer = ir; }
  const wet = ctx.createGain(); wet.gain.value = 0.42; const dry = ctx.createGain(); dry.gain.value = 0.8;
  const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3; comp.attack.value = 0.02; comp.release.value = 0.3;
  bus.connect(dry).connect(comp); bus.connect(verb).connect(wet).connect(comp); comp.connect(out);
  const hz = m => 440 * Math.pow(2, (m - 69) / 12);

  // ---- plucked strings: Karplus-Strong rendered once per pitch, then replayed (cheap on phones) ----
  const pluckCache = new Map();
  function pluckBuf(m, bright = 0.5) {
    const key = m + '|' + bright; if (pluckCache.has(key)) return pluckCache.get(key);
    const f = hz(m), N = Math.max(2, Math.round(SR / f)), len = Math.floor(SR * 3.2), b = ctx.createBuffer(1, len, SR), d = b.getChannelData(0);
    const ring = new Float32Array(N); for (let i = 0; i < N; i++) ring[i] = (rnd() * 2 - 1) * (0.6 + 0.4 * Math.sin(i / N * Math.PI));
    const damp = 0.4975 + bright * 0.0022; let p = 0, prev = 0;
    for (let i = 0; i < len; i++) { const cur = ring[p], nxt = ring[(p + 1) % N], v = damp * (cur + nxt); ring[p] = v; p = (p + 1) % N; prev += (v - prev) * (0.35 + bright * 0.5); d[i] = prev; }
    pluckCache.set(key, b); return b;
  }
  function pluck(dest, m, at, vel = 0.5, bright = 0.5, pan = 0) {
    const s = ctx.createBufferSource(); s.buffer = pluckBuf(m, bright); const g = ctx.createGain(); g.gain.value = vel * 0.55;
    const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null; s.connect(g); if (p) { p.pan.value = pan; g.connect(p).connect(dest); } else g.connect(dest);
    s.start(at); s.stop(at + 3.2);
  }
  function tone(dest, type, m, at, dur, vel, { a = 0.01, r = 0.3, lp = 4000, vib = 0, glideFrom = null, det = 0 } = {}) {
    const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    o.type = type; o.detune.value = det; f.type = 'lowpass'; f.frequency.value = lp; f.Q.value = 0.5;
    if (glideFrom != null) { o.frequency.setValueAtTime(hz(glideFrom), at); o.frequency.exponentialRampToValueAtTime(hz(m), at + 0.18); } else o.frequency.setValueAtTime(hz(m), at);
    if (vib) { const l = ctx.createOscillator(), lg = ctx.createGain(); l.frequency.value = 5.2; lg.gain.value = hz(m) * vib; l.connect(lg).connect(o.frequency); l.start(at + 0.25); l.stop(at + dur + r + 0.05); }
    g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(vel, at + a); g.gain.setValueAtTime(vel, at + Math.max(a, dur - 0.02)); g.gain.exponentialRampToValueAtTime(0.0001, at + dur + r);
    o.connect(f).connect(g).connect(dest); o.start(at); o.stop(at + dur + r + 0.05);
  }
  function piano(dest, m, at, vel) { // struck: fundamental + a few partials, fast decay
    for (const [h, v, d] of [[1, 1, 2.2], [2, 0.35, 1.2], [3, 0.12, 0.7], [4.02, 0.05, 0.4]]) { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = hz(m) * h; g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(vel * v * 0.3, at + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, at + d); o.connect(g).connect(dest); o.start(at); o.stop(at + d + 0.05); }
  }
  let noise = null; function noiseBuf() { if (noise) return noise; const b = ctx.createBuffer(1, SR, SR), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = rnd() * 2 - 1; return noise = b; }
  function drum(dest, at, { f0 = 90, f1 = 42, dur = 0.5, vel = 0.6, noiseAmt = 0.3, nf = 900 } = {}) {
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(f0, at); o.frequency.exponentialRampToValueAtTime(f1, at + dur * 0.6);
    g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(vel, at + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, at + dur); o.connect(g).connect(dest); o.start(at); o.stop(at + dur + 0.05);
    if (noiseAmt) { const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), ng = ctx.createGain(); s.buffer = noiseBuf(); f.type = 'bandpass'; f.frequency.value = nf; f.Q.value = 0.8;
      ng.gain.setValueAtTime(0.0001, at); ng.gain.exponentialRampToValueAtTime(vel * noiseAmt, at + 0.003); ng.gain.exponentialRampToValueAtTime(0.0001, at + 0.12); s.connect(f).connect(ng).connect(dest); s.start(at); s.stop(at + 0.2); }
  }

  // ---- harmony ----
  const SCALES = { major: [0, 2, 4, 5, 7, 9, 11], minor: [0, 2, 3, 5, 7, 8, 10], dorian: [0, 2, 3, 5, 7, 9, 10] };
  const deg = (root, scale, d, oct = 0) => { const s = SCALES[scale], n = s.length; const o = Math.floor(d / n); return root + s[((d % n) + n) % n] + 12 * (o + oct); };
  const triad = (root, scale, d) => [deg(root, scale, d), deg(root, scale, d + 2), deg(root, scale, d + 4)];

  // ---- moods (keys and tempos follow the soundtrack plan in the Roadmap) ----
  const MOODS = {
    menu:   { root: 50, scale: 'minor', bpm: 70, prog: [0, 5, 3, 4], bars: 2, rest: [1, 3] },
    day:    { root: 55, scale: 'major', bpm: 84, prog: [0, 4, 5, 3], bars: 2, rest: [2, 6] },
    golden: { root: 48, scale: 'major', bpm: 76, prog: [0, 3, 5, 4], bars: 2, rest: [2, 6] },
    night:  { root: 45, scale: 'minor', bpm: 60, prog: [0, 5, 3, 6], bars: 2, rest: [3, 8] },
    rain:   { root: 52, scale: 'dorian', bpm: 66, prog: [0, 3, 6, 4], bars: 2, rest: [2, 6] },
    combat: { root: 50, scale: 'minor', bpm: 132, prog: [0, 0, 5, 6], bars: 1, rest: [0, 0] },
  };
  const TRIM = { combat: 0.6, night: 1.5, menu: 1.2, day: 1.15, golden: 1.1, rain: 1.15 }; // even out loudness between moods
  const lanes = {};
  for (const k in MOODS) { const g = ctx.createGain(); g.gain.value = 0; g.connect(bus); lanes[k] = { g, target: 0, step: 0, bar: 0, next: 0, restUntil: 0, phrase: 0, motif: null }; }
  let current = null;

  function playStep(k, L, at, spb) {
    const M = MOODS[k], dest = L.g, s16 = L.step % 16, barIdx = Math.floor(L.step / 16), chordDeg = M.prog[Math.floor(barIdx / M.bars) % M.prog.length];
    const ch = triad(M.root, M.scale, chordDeg), bass = deg(M.root, M.scale, chordDeg, -1);
    if (!L.motif || (s16 === 0 && barIdx % 8 === 0)) L.motif = Array.from({ length: 8 }, () => (rnd() * 5 | 0) + (rnd() < 0.3 ? 7 : 0)); // a fresh melodic cell every 8 bars
    const pick = i => ch[i % 3] + 12 * Math.floor(i / 3);
    if (k === 'menu') {
      if (s16 === 0) tone(dest, 'sawtooth', bass, at, spb * 15, 0.08, { a: 1.2, r: 2, lp: 600, vib: 0.004 }); // cello drone
      if (s16 % 2 === 0) pluck(dest, pick([0, 2, 1, 3, 2, 4, 3, 1][(s16 / 2) | 0]) + 12, at, 0.38, 0.35, (rnd() - 0.5) * 0.6);
      if (s16 === 8 && rnd() < 0.5) piano(dest, ch[2] + 24, at, 0.35);
    } else if (k === 'day') {
      if (s16 === 0) { for (const m of ch) tone(dest, 'triangle', m, at, spb * 15, 0.03, { a: 1.5, r: 2.5, lp: 1800 }); pluck(dest, bass, at, 0.55, 0.3); }
      if ([0, 3, 6, 8, 10, 13].includes(s16)) pluck(dest, pick([0, 1, 2, 3, 2, 1][[0, 3, 6, 8, 10, 13].indexOf(s16)]) + 12, at, 0.33 + rnd() * 0.1, 0.55, (rnd() - 0.5) * 0.7);
      if (L.phrase % 2 === 1 && s16 % 4 === 2 && rnd() < 0.6) pluck(dest, deg(M.root, M.scale, L.motif[(s16 / 4) | 0], 2), at, 0.28, 0.8, 0.4); // mandolin-like line
      if (s16 % 8 === 4) drum(dest, at, { f0: 220, f1: 160, dur: 0.12, vel: 0.08, noiseAmt: 0.6, nf: 3000 }); // soft shaker
    } else if (k === 'golden') {
      if (s16 === 0) { for (const m of ch) tone(dest, 'sine', m + 12, at, spb * 15, 0.035, { a: 2, r: 3, lp: 2400, det: (rnd() - 0.5) * 8 }); pluck(dest, bass, at, 0.5, 0.25); }
      if (s16 % 4 === 0) pluck(dest, pick([0, 2, 1, 3][s16 / 4]) + 12, at, 0.3, 0.4, (rnd() - 0.5) * 0.5);
      if ((s16 === 4 || s16 === 12) && rnd() < 0.7) { const m = deg(M.root, M.scale, L.motif[s16 / 4 | 0], 1); tone(dest, 'triangle', m, at, spb * 3.5, 0.07, { a: 0.08, r: 0.8, lp: 1600, vib: 0.006, glideFrom: m - 2 }); } // slide guitar
    } else if (k === 'night') {
      if (s16 === 0) { for (const m of ch) tone(dest, 'sawtooth', m, at, spb * 15, 0.018, { a: 2.5, r: 3, lp: 700, det: (rnd() - 0.5) * 12 }); tone(dest, 'sawtooth', bass - 12, at, spb * 15, 0.05, { a: 2, r: 3, lp: 300 }); }
      if (s16 % 6 === 0 && rnd() < 0.45) piano(dest, deg(M.root, M.scale, L.motif[(s16 / 2) % 8], 3), at, 0.16); // far-off music box
    } else if (k === 'rain') {
      if (s16 === 0) { tone(dest, 'sawtooth', bass, at, spb * 15, 0.06, { a: 1, r: 2, lp: 500, vib: 0.003 }); for (const m of ch) tone(dest, 'triangle', m, at, spb * 15, 0.02, { a: 2, r: 2, lp: 1200 }); }
      if ([0, 6, 10].includes(s16)) piano(dest, pick([0, 2, 4][[0, 6, 10].indexOf(s16)]) + 12, at, 0.3);
      if (s16 === 14 && rnd() < 0.5) piano(dest, deg(M.root, M.scale, L.motif[0], 2), at, 0.22);
      if (s16 % 8 === 4) drum(dest, at, { f0: 300, f1: 200, dur: 0.08, vel: 0.05, noiseAmt: 1, nf: 2500 }); // brushed snare
    } else if (k === 'combat') {
      if (s16 % 4 === 0) drum(dest, at, { f0: 95, f1: 45, dur: 0.45, vel: 0.5, noiseAmt: 0.25, nf: 700 }); // taiko
      if (s16 === 6 || s16 === 10 || s16 === 14) drum(dest, at, { f0: 140, f1: 90, dur: 0.2, vel: 0.3, noiseAmt: 0.5, nf: 1200 });
      if (s16 % 2 === 1) drum(dest, at, { f0: 400, f1: 300, dur: 0.05, vel: 0.07, noiseAmt: 1, nf: 4500 });
      if (s16 % 2 === 0) tone(dest, 'sawtooth', bass + (s16 % 8 === 6 ? 1 : 0), at, spb * 0.4, 0.09, { a: 0.005, r: 0.08, lp: 900 }); // staccato low strings
      if (s16 === 0 && barIdx % 2 === 0) tone(dest, 'square', ch[0], at, spb * 1.5, 0.05, { a: 0.003, r: 0.25, lp: 1400 }); // guitar stab
      if (s16 === 8 && barIdx % 4 === 3) for (const m of ch) tone(dest, 'sawtooth', m + 12, at, spb * 6, 0.03, { a: 0.4, r: 0.6, lp: 2000 });
    }
  }

  const LOOK = 0.12;
  function schedule() {
    const now = ctx.currentTime;
    for (const k in lanes) {
      const L = lanes[k], M = MOODS[k], spb = 60 / M.bpm / 4; // seconds per 16th
      // fade
      if (L.target < 0.01 && L.g.gain.value < 0.01) { L.next = 0; continue; }
      if (!L.next || L.next < now) L.next = now + 0.05;
      while (L.next < now + LOOK) {
        if (L.restUntil > L.next) { L.next = L.restUntil; break; }
        playStep(k, L, L.next, spb);
        L.step++; L.next += spb * (L.step % 2 ? 1.04 : 0.96); // a little swing
        if (L.step % (16 * M.bars * M.prog.length) === 0) { L.phrase++; if (M.rest[1] > 0 && L.phrase % 2 === 0) { L.restUntil = L.next + M.rest[0] + rnd() * (M.rest[1] - M.rest[0]); L.step = 0; } }
      }
    }
  }
  const timer = setInterval(() => { try { schedule(); } catch (e) {} }, 50);
  return {
    set mood(k) { if (k === current) return; current = k; for (const n in lanes) { lanes[n].target = n === k ? (TRIM[n] || 1) : 0; lanes[n].g.gain.setTargetAtTime(lanes[n].target, ctx.currentTime, k === 'combat' || n === 'combat' ? 0.6 : 2.2); } if (k && lanes[k].restUntil > ctx.currentTime + 4) lanes[k].restUntil = ctx.currentTime + 1.5; },
    get mood() { return current; },
    set volume(v) { bus.gain.setTargetAtTime(v, ctx.currentTime, 0.3); },
    stop() { clearInterval(timer); },
  };
}
