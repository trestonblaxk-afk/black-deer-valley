// Creatures: decode rigs, coats, accessories, locomotion (quadruped / rabbit / human), birds
import * as THREE from 'three';
import { TAU, clamp, lerp, sstep, rnd, terrainH } from './world.js';

export const CAT = {
  buck:   { mesh: 'deer', name: 'Black Buck', latin: 'Odocoileus virginianus', kind: 'hoofed', coat: 'black', antlers: 'whitetail', role: 'prey', group: 'deer', speeds: [1.4, 3.4, 9.5], size: 1 },
  wbuck:  { mesh: 'deer', name: 'White-tailed Buck', latin: 'Odocoileus virginianus', kind: 'hoofed', coat: 'whitetail', antlers: 'whitetail', role: 'prey', group: 'deer', speeds: [1.4, 3.4, 9.5], size: 1 },
  doe:    { mesh: 'deer', name: 'White-tailed Doe', latin: 'Odocoileus virginianus', kind: 'hoofed', coat: 'whitetail', role: 'prey', group: 'deer', speeds: [1.3, 3.2, 9], size: 0.9 },
  fawn:   { mesh: 'deer', name: 'Fawn', latin: 'Odocoileus virginianus', kind: 'hoofed', coat: 'fawn', role: 'prey', group: 'deer', speeds: [1.1, 2.8, 7.5], size: 0.6 },
  elk:    { mesh: 'elk', name: 'Bull Elk', latin: 'Cervus canadensis', kind: 'hoofed', coat: 'elk', antlers: 'elk', role: 'prey', group: 'elk', speeds: [1.5, 3.8, 10], size: 1 },
  cow:    { mesh: 'elk', name: 'Cow Elk', latin: 'Cervus canadensis', kind: 'hoofed', coat: 'elk', role: 'prey', group: 'elk', speeds: [1.5, 3.8, 10], size: 0.92 },
  horse:  { mesh: 'horse', name: 'Wild Horse', latin: 'Equus ferus caballus', kind: 'hoofed', coat: 'horse', role: 'grazer', group: 'horse', speeds: [1.6, 4.2, 12], size: 1, solidHoof: true },
  wolf:   { mesh: 'wolf', name: 'Gray Wolf', latin: 'Canis lupus', kind: 'canine', coat: 'wolf', role: 'predator', group: 'wolf', speeds: [1.3, 3.6, 11], size: 1 },
  fox:    { mesh: 'wolf', name: 'Red Fox', latin: 'Vulpes vulpes', kind: 'canine', coat: 'fox', role: 'hunter', group: 'fox', speeds: [1.0, 2.8, 8.5], size: 0.6 },
  rabbit: { mesh: 'rabbit', name: 'Cottontail', latin: 'Sylvilagus floridanus', kind: 'rabbit', coat: 'rabbit', role: 'small', group: 'rabbit', speeds: [0.6, 2.2, 7], size: 1 },
  athlete: { mesh: 'athlete', name: 'Male hiker', latin: 'Hybrid athlete · 5′11″ · lean build', kind: 'human', coat: 'athlete', role: 'human', group: 'hiker', speeds: [1.5, 3.1, 6.4], size: 1 },
  hiker:  { mesh: 'athlete', name: 'Hiker', latin: 'Homo sapiens · with camera', kind: 'human', coat: 'human', role: 'human', group: 'hiker', speeds: [1.35, 2.6, 4.6], size: 1 },
  bird:   { mesh: null, name: 'Barn Swallow', latin: 'Hirundo rustica', kind: 'bird', role: 'bird', group: 'bird', speeds: [8, 10, 14], size: 1 },
};

// ---------- load + decode (binary, lazy) ----------
const RAW = {}, LOADING = {};
export function loadSpecies(name) {
  if (!LOADING[name]) LOADING[name] = Promise.all([fetch(`data/${name}.json`).then(r => r.json()), fetch(`data/${name}.wasm`).then(r => r.arrayBuffer())]).then(([meta, bin]) => { RAW[name] = { meta, bin }; });
  return LOADING[name];
}
export const speciesReady = name => !name || !!RAW[name];
const cache = {};
function decodeSpecies(name) {
  if (cache[name]) return cache[name];
  const { meta: D, bin } = RAW[name];
  const view = (T, [o, l]) => new T(bin, o, l / T.BYTES_PER_ELEMENT);
  const lods = D.lods.map(L => {
    const Pq = view(Int16Array, L.P), Nq = view(Int8Array, L.N), n = L.count;
    const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) for (let c = 0; c < 3; c++) { pos[i * 3 + c] = L.lo[c] + ((Pq[i * 3 + c] + 32768) / 65535) * L.sc[c]; nor[i * 3 + c] = Nq[i * 4 + c] / 127; }
    const attrs = {
      position: new THREE.BufferAttribute(pos, 3), normal: new THREE.BufferAttribute(nor, 3),
      skinIndex: new THREE.BufferAttribute(view(Uint8Array, L.SI), 4),
      skinWeight: new THREE.BufferAttribute(view(Uint8Array, L.SW), 4, true),
    };
    const index = new THREE.BufferAttribute(L.idx32 ? view(Uint32Array, L.I) : view(Uint16Array, L.I), 1);
    return { n, attrs, index, SL: view(Uint8Array, L.SL), pos, nor };
  });
  cache[name] = { D, lods };
  return cache[name];
}
const COLOR_CACHE = new Map();

// ---------- coats ----------
const hx = (h) => new THREE.Color(h);
const hash3 = (x, y, z) => { const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return s - Math.floor(s); };
const HORSE_COATS = [
  { body: 0x5e321a, mane: 0x0d0b0a, leg: 0x15110f },
  { body: 0x8a4421, mane: 0x9a4a24, leg: 0x6a341a },
  { body: 0xc9974e, mane: 0xefe2c4, leg: 0xc0904a },
  { body: 0x161412, mane: 0x0c0b0a, leg: 0x100f0e },
  { body: 0xb5b2aa, mane: 0xdedbd4, leg: 0x6a6762 },
];
const HUMAN = {
  skin: [0xf1c7a5, 0xd9a37c, 0xa86f4c, 0x7a4b31, 0x5a3622], hair: [0x2a1e16, 0x5b3a22, 0xa87b4f, 0xd8c19a, 0x1a1a1a, 0x8b8b8b],
  shirt: [0xb5482e, 0x2f5d50, 0x3b5f8f, 0xd9a441, 0x7b2e3a, 0xe8e1d0], pants: [0x7a6a4f, 0x3a4656, 0x4f5a3a, 0x2b2b2b],
  boots: [0x5a3b24, 0x3b2a1e, 0x6b5a45], pack: [0xd2691e, 0x2e7d6b, 0xb33a3a, 0x4a5f8a, 0xc9a227],
};
const pick = a => a[(rnd() * a.length) | 0];
function coatFn(type, D, variant) {
  const S = D.S || 1, eye = D.attach.eye;
  const out = new THREE.Color();
  if (type === 'black') { const back = hx(0x0b0908), flank = hx(0x17120e), belly = hx(0x241d18), leg = hx(0x1b1612), muz = hx(0x34302c);
    return (p, n, s) => { const [x, y, z] = p; if (s === 'muzzle') return out.copy(muz); if (s === 'leg') return out.copy(leg);
      out.copy(flank).lerp(back, sstep(1.0, 1.14, y / S)).lerp(belly, sstep(0.9, 0.78, y / S));
      const h = hash3(Math.floor(x * 40), Math.floor(y * 40), Math.floor(z * 40)); out.multiplyScalar(0.88 + 0.24 * h);
      if (eye) out.lerp(hx(0x3a322c), sstep(0.034, 0.022, Math.hypot(x - eye[0], y - eye[1])) * 0.6);
      return out; }; }
  if (type === 'whitetail' || type === 'fawn') {
    const base = type === 'fawn' ? hx(0x9a6236) : hx(0x86684c), dark = type === 'fawn' ? hx(0x6e4426) : hx(0x584436), white = hx(0xe8e2d6), leg = hx(0x8e6c50), muz = hx(0x2a2420), tan = hx(0xa07a54);
    return (p, n, s) => {
      const [x, y, z] = p;
      if (s === 'muzzle') return out.copy(muz).lerp(white, sstep(1.39, 1.41, y) * 0.0 + (x < 1.0 ? 0.5 : 0));
      if (s === 'tail') return out.copy(dark).lerp(white, sstep(0.0, -0.4, n[0] + n[1] * 0.6));
      out.copy(base).lerp(tan, sstep(1.0, 0.9, y) * 0.6).lerp(dark, sstep(1.0, 1.14, y));
      { const h = hash3(Math.floor(x * 30), Math.floor(y * 30), Math.floor(z * 30)); out.multiplyScalar(0.92 + 0.16 * h); }
      if (s === 'leg') { out.copy(leg); out.lerp(white, sstep(0.09, 0.06, Math.abs(z)) * 0.35); }
      if (x > -0.55 && x < 0.45) out.lerp(white, sstep(0.88, 0.76, y) * (s === 'leg' ? sstep(0.09, 0.06, Math.abs(z)) * 0.6 : 0.92));
      if (x > 0.7) out.lerp(white, sstep(0.05, 0.025, Math.hypot(x - 0.76, y - 1.36)) * sstep(0.05, 0.02, Math.abs(z)) * 0.85);
      if (eye) out.lerp(white, sstep(0.032, 0.02, Math.hypot(x - eye[0], y - eye[1])) * 0.8);
      if (x < -0.6 && y < 0.98) out.lerp(white, 0.85);
      if (type === 'fawn' && y > 0.9 && y < 1.12 && x > -0.55 && x < 0.42 && s === 'coat') {
        const cx = Math.floor(x / 0.05), cy = Math.floor(y / 0.045), h = hash3(cx, cy, Math.sign(z));
        const dx = x - (cx + 0.5) * 0.05, dy = y - (cy + 0.5) * 0.045;
        if (h > 0.45 && Math.hypot(dx, dy) < 0.012) out.lerp(white, 0.9);
      }
      return out;
    };
  }
  if (type === 'elk') {
    const body = hx(0xb08657), neck = hx(0x4b3424), leg = hx(0x3b2a1f), rump = hx(0xe1c99a);
    return (p, n, s) => { const [x, y] = [p[0] / S, p[1] / S];
      if (s === 'mane' || s === 'muzzle') return out.copy(neck);
      if (s === 'leg') return out.copy(leg);
      out.copy(body); if (x > 0.42 || y < 0.82) out.lerp(neck, Math.max(sstep(0.42, 0.6, x), sstep(0.82, 0.74, y) * 0.8));
      if (x < -0.5 && y > 0.82) out.lerp(rump, sstep(-0.5, -0.62, x));
      if (s === 'tail') out.copy(rump);
      return out; };
  }
  if (type === 'horse') {
    const c = HORSE_COATS[variant?.c ?? 0], body = hx(c.body), mane = hx(c.mane), leg = hx(c.leg), white = hx(0xf2efe8);
    const blaze = !!variant?.blaze, socks = variant?.socks || [0, 0, 0, 0];
    return (p, n, s) => { const [x, y, z] = [p[0] / S, p[1] / S, p[2] / S];
      if (s === 'mane') return out.copy(mane);
      out.copy(body);
      if (s === 'leg' || y < 0.4) out.lerp(leg, sstep(0.55, 0.4, y));
      if (s === 'muzzle') out.lerp(hx(0x2a201a), 0.6);
      if (blaze && x > 0.86 && Math.abs(z) < 0.022 && y > 1.36) out.copy(white);
      const legi = (x > 0 ? 0 : 2) + (z > 0 ? 0 : 1);
      if (socks[legi] && y < 0.2 && Math.abs(z) > 0.05) out.copy(white);
      return out; };
  }
  if (type === 'wolf') {
    const back = hx(0x3e3b37), side = hx(0x6f6a62), cream = hx(0xb9b1a2), black = hx(0x1e1c1a);
    return (p, n, s) => { const [x, y] = p;
      if (s === 'tailtip') return out.copy(black);
      if (s === 'nose') return out.copy(black);
      if (s === 'chestfur' || s === 'cheek' || s === 'paw') return out.copy(cream);
      if (s === 'muzzle') return out.copy(cream).lerp(side, sstep(0.9, 0.95, y));
      if (s === 'ear') return out.copy(side).lerp(black, sstep(1.03, 1.07, y));
      if (s === 'leg') return out.copy(cream).lerp(side, 0.3);
      out.copy(side).lerp(back, sstep(0.7, 0.8, y) * (x > -0.4 && x < 0.45 ? 1 : 0.4));
      out.lerp(cream, sstep(0.64, 0.58, y));
      if (s === 'ruff') out.lerp(cream, 0.3);
      return out; };
  }
  if (type === 'fox') {
    const orange = hx(0xc4581d), deep = hx(0x9c3f12), white = hx(0xf3eee6), black = hx(0x1a1412);
    return (p, n, s) => { const [x, y] = p;
      if (s === 'tailtip') return out.copy(orange).lerp(white, sstep(0.52, 0.45, y));
      if (s === 'nose') return out.copy(black);
      if (s === 'leg' || s === 'paw') return out.copy(black);
      if (s === 'ear') return out.copy(black);
      if (s === 'chestfur' || s === 'cheek') return out.copy(white);
      if (s === 'muzzle') return out.copy(orange).lerp(white, sstep(0.915, 0.9, y));
      out.copy(orange).lerp(deep, sstep(0.72, 0.8, y)); out.lerp(white, sstep(0.63, 0.58, y));
      return out; };
  }
  if (type === 'rabbit') {
    const brown = hx(0x8a7660), dark = hx(0x5e4e3e), white = hx(0xefe8dc);
    return (p, n, s) => { const [x, y] = p;
      if (s === 'tail' || s === 'belly') return out.copy(white);
      if (s === 'muzzle') return out.copy(brown).lerp(white, 0.4);
      out.copy(brown).lerp(dark, sstep(0.19, 0.24, y) * 0.6); out.lerp(white, sstep(0.1, 0.07, y));
      return out; };
  }
  if (type === 'athlete') {
    const C = { lips: hx(0x5a3426), shirt: hx(0x47484c), sleeve: hx(0x404145), vest: hx(0x777a58), pants: hx(0x9a8664), pocket: hx(0x8c7a5a), cuff: hx(0x9a8664), bottle: hx(0x4d5a60), laces: hx(0x76767a), skin: hx(0x7e4e33), lid: hx(0x6e432c), hair: hx(0x17110d), beard: hx(0x1a130f), brow: hx(0x140f0c), pack: hx(0x1e1e21), strap: hx(0x2c2c30), watch: hx(0x141414), socks: hx(0xb3a993), shoes: hx(0x1b1918), sole: hx(0x2b2a28) };
    const sole = C.sole;
    return (p, n, s) => { const [x, y, z] = p;
      if (s === 'vest' && x > 0.05 && Math.abs(z) < 0.006 && y > 1.06 && y < 1.48) return out.copy(C.strap);            // centre zip
      if (s === 'vest' && x > 0.05 && Math.abs(z) < 0.004) return out.copy(C.shirt);
      if (s === 'shoes') { if (y < 0.03) return out.copy(sole);
        if (x > 0.02 && x < 0.13 && Math.abs(z - Math.sign(z) * 0.1) < 0.03 && y > 0.07 && ((y * 70) % 1) < 0.35) return out.copy(C.laces); } // laces
      if (s === 'pants' && y < 0.6 && y > 0.45 && x > 0.03) return out.copy(C.pants).multiplyScalar(0.92);               // knee panel
      return out.copy(C[s] || C.shirt); };
  }
  if (type === 'human') {
    const pal = variant;
    if (D.name === 'athlete') { // NPC hikers share the detailed body; each gets its own outfit, skin and hair
      const M = { shirt: pal.shirt, pants: pal.pants, cuff: pal.pants, skin: pal.skin, lid: new THREE.Color(pal.skin).multiplyScalar(0.86).getHex(), lips: new THREE.Color(pal.skin).multiplyScalar(0.72).getHex(),
        hair: pal.hair, beard: pal.hair, brow: pal.hair, shoes: pal.boots, sole: 0x2b2a28, socks: 0xb3a993, pack: pal.pack, strap: pal.pack2, watch: 0x141414,
        sleeve: pal.shirt, vest: new THREE.Color(pal.pants).multiplyScalar(0.8).getHex(), pocket: pal.pants, bottle: 0x4d5a60, laces: 0x76767a };
      return (p, n, s) => out.set(M[s] ?? pal.shirt);
    }
    return (p, n, s) => out.set(pal[s] ?? 0x888888);
  }
  return () => out.set(0x888888);
}

// ---------- materials ----------
const NOISE = `
varying vec3 vRest;
float hash3(vec3 p){ p = fract(p*0.3183099+.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float vnoise(vec3 x){ vec3 i=floor(x), f=fract(x); f=f*f*(3.0-2.0*f);
  return mix(mix(mix(hash3(i),hash3(i+vec3(1,0,0)),f.x), mix(hash3(i+vec3(0,1,0)),hash3(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(hash3(i+vec3(0,0,1)),hash3(i+vec3(1,0,1)),f.x), mix(hash3(i+vec3(0,1,1)),hash3(i+vec3(1,1,1)),f.x),f.y), f.z); }`;
// shared lighting state (bound to the world's uniforms by bindCreatureEnv before any creature spawns)
export const CENV = { sunV: { value: new THREE.Vector3(0, 1, 0) }, sunCol: { value: new THREE.Color(1, 0.8, 0.6) }, day: { value: 1 }, wet: { value: 0 } };
export function bindCreatureEnv(U) { CENV.sunV = U.sunV; CENV.sunCol = U.sunCol; CENV.day = U.day; CENV.wet = U.wet; }
const blobTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'); const g = x.createRadialGradient(32, 32, 0, 32, 32, 32); g.addColorStop(0, 'rgba(0,0,0,0.75)'); g.addColorStop(0.55, 'rgba(0,0,0,0.35)'); g.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
const blobMat = new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, fog: true });
const blobGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
function furMaterial({ fur = 0.16, fuzz = 0x2a2724, scale = 1, sheen = 0.8, rough = 0.62, cloth = false, sleek = 0, shade = null } = {}) {
  const m = new THREE.MeshPhysicalMaterial({ color: 0xffffff, vertexColors: true, roughness: rough, metalness: 0, sheen: cloth ? 0.6 : sheen, sheenColor: new THREE.Color(cloth ? 0x9a9aa2 : 0x6a6560), sheenRoughness: cloth ? 0.5 : 0.4 });
  m.onBeforeCompile = sh => {
    sh.uniforms.uFur = { value: fur }; sh.uniforms.uFuzz = { value: new THREE.Color(fuzz) }; sh.uniforms.uS = { value: 1 / scale };
    Object.assign(sh.uniforms, { uSunV: CENV.sunV, uSunCol: CENV.sunCol, uDay: CENV.day, uWet: CENV.wet, uRim: { value: (cloth ? 0.3 : 0.65) * (CQ.painted ? 1.8 : 1) }, uCloth: { value: cloth ? 1 : 0 }, uSleek: { value: sleek }, uShade: { value: new THREE.Vector3(shade ? 1 : 0, shade ? shade[0] : 0, shade ? shade[1] : 1) }, uSkyRim: { value: cloth ? 0.16 : 0.1 } });
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vRest;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvRest = position;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float uFur, uS, uDay, uWet, uRim, uCloth, uSleek, uSkyRim; uniform vec3 uFuzz, uSunV, uSunCol, uShade; float gSkin, gFold;' + NOISE + `
      // cloth folds (rest pose, metres): fabric bunches at the elbows, knees, waist and cuffs, fine wrinkles everywhere else
      float clothFold(vec3 r){
        float elbow = smoothstep(0.16, 0.2, abs(r.z)) * exp(-pow((r.y - 1.16) / 0.075, 2.0));
        float knee = (1.0 - smoothstep(0.9, 0.95, r.y)) * exp(-pow((r.y - 0.56) / 0.09, 2.0));
        float waist = exp(-pow((r.y - 0.99) / 0.035, 2.0)), cuff = (1.0 - smoothstep(0.25, 0.3, r.y)) * exp(-pow((r.y - 0.19) / 0.06, 2.0));
        float bunch = elbow + knee * 1.2 + waist * 0.6 + cuff * 1.1;
        float ph = r.y * 150.0 + vnoise(r * vec3(38.0, 5.0, 38.0)) * 7.0 + (r.x + r.z) * 22.0;
        return sin(ph) * bunch + (vnoise(r * vec3(26.0, 95.0, 26.0)) - 0.5) * 0.35;
      }`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        gSkin = uCloth * smoothstep(0.07, 0.16, diffuseColor.r - diffuseColor.b) * smoothstep(0.02, 0.06, diffuseColor.r);
        gFold = uCloth > 0.5 ? clothFold(vRest) * (1.0 - gSkin) : 0.0; diffuseColor.rgb *= 1.0 - 0.14 * max(0.0, -gFold); // folds hold a little shade
        { vec3 r = vRest * uS;
          // fur: strands run along the body (x); two scales of streaky variation plus sparse lighter guard hairs
          float st = vnoise(r * vec3(38.0, 640.0, 640.0)) * 0.65 + vnoise(r * vec3(14.0, 190.0, 190.0)) * 0.35;
          float guard = smoothstep(0.82, 0.95, vnoise(r * vec3(60.0, 900.0, 900.0)));
          vec3 furC = diffuseColor.rgb * mix(mix(0.8, 0.93, uSleek), mix(1.14, 1.05, uSleek), st) + guard * 0.06 * (1.0 - uSleek) * (0.3 + diffuseColor.rgb);
          // sleek coats (horse): faint dapples and a lighter flank, like a groomed summer coat
          furC *= 1.0 + uSleek * (0.07 * (vnoise(r * 9.0) - 0.5) + 0.05 * smoothstep(0.2, 0.9, vnoise(r * 3.1 + 7.0)));
          // natural shading: darker belly, inner legs and lower legs, sun-faded back; fine short-hair grain along the body
          furC *= mix(1.0, mix(0.74, 1.06, smoothstep(0.6, 1.12, r.y)) * mix(0.9, 1.04, vnoise(r * vec3(30.0, 260.0, 260.0))), uSleek);
          // cloth: fine knit + seams of slight darkening; skin: soft pores
          vec2 w = r.xz * 1100.0 + r.y * 700.0; float knit = 0.5 + 0.5 * sin(w.x) * sin(w.y + r.x * 900.0);
          vec3 clothC = diffuseColor.rgb * mix(0.9, 1.06, knit) * mix(0.94, 1.0, vnoise(r * 90.0));
          vec3 skinC = diffuseColor.rgb * mix(0.93, 1.04, vnoise(r * 520.0)) * mix(0.96, 1.03, vnoise(r * 60.0));
          vec3 detailC = uCloth > 0.5 ? mix(clothC, skinC, gSkin) : furC;
          detailC *= mix(1.0, mix(0.78, 1.05, smoothstep(uShade.y, uShade.z, r.y)) * mix(0.92, 1.05, vnoise(r * vec3(22.0, 210.0, 210.0))), uShade.x); // muscle-like value breakup + countershading
          #ifdef PAINTED
          detailC = mix(diffuseColor.rgb * 1.04, detailC, 0.35);
          #endif
          diffuseColor.rgb = detailC; }
        diffuseColor.rgb *= 1.0 - 0.25 * uWet;`)
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(roughnessFactor, roughnessFactor * 0.55, uWet); roughnessFactor = mix(roughnessFactor, 0.6, gSkin);')
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        { vec3 r = vRest * uS; vec3 q = r * vec3(55., 120., 120.);
          vec3 nn = 0.35 * (vec3(vnoise(q), vnoise(q + 19.1), vnoise(q + 37.7)) - 0.5);
          vec3 q2 = r * vec3(28., 520., 520.); nn += (vec3(vnoise(q2), vnoise(q2 + 7.3), vnoise(q2 + 3.1)) - 0.5);
          normal = normalize(normal + uFur * nn);
          if (uCloth > 0.5) { vec3 upV = normalize((viewMatrix * vec4(0.0, 1.0, 0.0, 0.0)).xyz); normal = normalize(normal + upV * gFold * 0.42);
            vec3 pq = vRest * 1400.0; normal = normalize(normal + gSkin * 0.12 * (vec3(vnoise(pq), vnoise(pq + 3.7), vnoise(pq + 9.1)) - 0.5)); } }`)  // skin: fine pores
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        { float fr = 1.0 - abs(dot(normal, normalize(vViewPosition))); totalEmissiveRadiance += uFuzz * pow(fr, 2.6) * diffuseColor.rgb * 3.0;
          // back-lit fur halo: hairs at the silhouette scatter sunlight toward the camera when the sun is behind the subject
          float back = pow(max(dot(normalize(-vViewPosition), uSunV), 0.0), 2.0);
          totalEmissiveRadiance += uSunCol * pow(fr, 3.2) * (0.12 + 1.5 * back) * uDay * uRim * (1.0 - 0.6 * uWet);
          // skin: light scattering under the surface warms the shadow side
          totalEmissiveRadiance += diffuseColor.rgb * vec3(0.9, 0.5, 0.38) * gSkin * (0.035 + 0.12 * back) * (0.3 + 0.7 * uDay);
          // character lighting (as games do): a soft camera-side fill on skin and a cool rim that keeps black clothing readable
          float facing = max(normal.z, 0.0);
          totalEmissiveRadiance += diffuseColor.rgb * vec3(1.0, 0.92, 0.85) * gSkin * 0.32 * facing * facing * (0.35 + 0.65 * uDay);
          totalEmissiveRadiance += vec3(0.045, 0.05, 0.058) * pow(fr, 3.0) * uCloth * (1.0 - gSkin) * (0.3 + 0.7 * uDay);
          // sky rim (from the stylized test): a cool edge light so dark coats, the rider and black clothing read against grass at any distance
          totalEmissiveRadiance += vec3(0.42, 0.52, 0.7) * pow(fr, 2.6) * uSkyRim * (0.25 + 0.75 * uDay) * (1.0 - 0.5 * uWet) * (1.0 - gSkin * 0.7);
          #ifdef PAINTED
          totalEmissiveRadiance += vec3(0.05, 0.065, 0.09) * pow(fr, 1.6) * (0.3 + 0.7 * uDay); // painted: sky-blue edge light so dark coats and clothes read
          #endif
          }`);
  };
  if (CQ.painted) m.defines = { PAINTED: '' };
  m.userData.env = cloth ? 0.15 : 0.35;
  return m;
}
// premium fur (method from the Plush skill): every shell layer in ONE instanced, skinned draw. Strands on a skewed grid, gathered into tufts,
// per-strand length with ~10% longer pale guard hairs, tapered tips, root-to-tip shading, frosted tips and Kajiya-Kay strand highlights.
export const CQ = { shells: matchMedia('(pointer: coarse)').matches ? 7 : 14, furDist: matchMedia('(pointer: coarse)').matches ? 6 : 11, hi: 15, mid: 38, a2c: false };
const furMats = {};
function furShellMat(len, S, kind) {
  const shY = SHADE_Y[kind];
  const k = len.toFixed(4) + '|' + S.toFixed(2) + '|' + kind; if (furMats[k]) return furMats[k];
  // sheen gives the coat its velvet value range (black coats stay readable); phones use the cheaper standard model plus the edge term below
  const m = matchMedia('(pointer: coarse)').matches ? new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8, metalness: 0 })
    : new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.75, metalness: 0, sheen: 0.85, sheenColor: new THREE.Color(0x6e6a64), sheenRoughness: 0.45 });
  const den = { deer: 330, elk: 260, wolf: 210, rabbit: 420, horse: 520 }[kind] || 300;
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, { uShY: { value: new THREE.Vector3(shY ? 1 : 0, (shY ? shY[0] : 0) * S, (shY ? shY[1] : 1) * S) }, uLen: { value: len }, uDen: { value: den / S }, uSunV: CENV.sunV, uSunCol: CENV.sunCol, uDay: CENV.day, uWet: CENV.wet, uTime: { value: 0 } });
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nattribute float aShell; uniform float uLen; varying vec3 vRestS; varying float vH; varying vec3 vComb;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        vRestS = position; vH = aShell;
        // push out along the bind-pose normal, droop with gravity and lie back along the body (+x is forward), more at the tips
        vec3 nb = normalize(normal); float hh = aShell * uLen;
        transformed += nb * hh + (vec3(-0.55, -0.45, 0.0) * hh * aShell);
        vComb = normalize(nb + vec3(-0.9, -0.5, 0.0) * aShell);`);
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
      uniform float uDen, uDay, uWet; uniform vec3 uSunV, uSunCol, uShY; varying vec3 vRestS; varying float vH; varying vec3 vComb; float gTipK, gGuard;
      float fh(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
      float fn3(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(mix(fh(i), fh(i + vec3(1,0,0)), f.x), mix(fh(i + vec3(0,1,0)), fh(i + vec3(1,1,0)), f.x), f.y), mix(mix(fh(i + vec3(0,0,1)), fh(i + vec3(1,0,1)), f.x), mix(fh(i + vec3(0,1,1)), fh(i + vec3(1,1,1)), f.x), f.y), f.z); }`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        { float h = vH;
          vec3 st = mat3(0.80, 0.36, -0.48, -0.48, 0.86, -0.17, 0.36, 0.36, 0.86) * vRestS * uDen;
          // tufts: strands lean toward the centre of a coarser clump cell (grid skewed against the strand grid so no rows show)
          vec3 cq = mat3(0.62, -0.55, 0.56, 0.71, 0.70, -0.02, -0.38, 0.45, 0.81) * vRestS * uDen * 0.22;
          vec3 cc = (floor(cq) + 0.5 + (vec3(fh(floor(cq)), fh(floor(cq) + 4.1), fh(floor(cq) + 8.7)) - 0.5) * 0.5);
          vec3 cw = transpose(mat3(0.62, -0.55, 0.56, 0.71, 0.70, -0.02, -0.38, 0.45, 0.81)) * cc / (uDen * 0.22);
          vec3 cs = mat3(0.80, 0.36, -0.48, -0.48, 0.86, -0.17, 0.36, 0.36, 0.86) * cw * uDen;
          float kc = 0.55 * h * h; st = (st - cs * kc) / (1.0 - kc);
          vec3 cell = floor(st), fq = fract(st) - 0.5; float r0 = fh(cell), r1 = fh(cell + 13.7);
          gGuard = step(0.9, r1); float lenK = gGuard > 0.5 ? 1.0 : mix(0.56, 0.82, r0);
          if (h > lenK) discard;
          float rad = (gGuard > 0.5 ? 0.3 : 0.46) * pow(1.0 - h / lenK, 0.55);
          float rr = length(fq.xz + (vec2(r0, r1) - 0.5) * 0.25);
          if (rr > rad) discard;
          gTipK = h / lenK;
          float lowf = fn3(vRestS * uDen * 0.035) * 0.6 + fn3(vRestS * uDen * 0.11) * 0.4;
          vec3 base = diffuseColor.rgb * mix(0.82, 1.15, lowf) * (0.9 + 0.2 * r0) * mix(1.0, mix(0.8, 1.05, smoothstep(uShY.y, uShY.z, vRestS.y)), uShY.x);
          vec3 tip = mix(base, base * 1.35 + 0.035, 0.55) ; // frosted tips
          diffuseColor.rgb = mix(base, tip, smoothstep(0.55, 1.0, gTipK)) * mix(0.55, 1.05, smoothstep(0.0, 0.85, h)) * (gGuard > 0.5 ? 1.12 : 1.0) * (1.0 - 0.3 * uWet); }`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        { // Kajiya-Kay: highlights run across the strand direction, not the surface
          vec3 T = normalize((viewMatrix * vec4(vComb, 0.0)).xyz), V = normalize(vViewPosition), L = uSunV, Hh = normalize(L + V);
          float th = dot(T, Hh), s1 = pow(sqrt(max(0.0, 1.0 - th * th)), 90.0), th2 = dot(T, normalize(Hh + T * 0.25)), s2 = pow(sqrt(max(0.0, 1.0 - th2 * th2)), 18.0);
          float dif = clamp(0.35 + 0.65 * sqrt(max(0.0, 1.0 - dot(T, L) * dot(T, L))), 0.0, 1.0);
          totalEmissiveRadiance += uSunCol * uDay * (s1 * 0.07 + s2 * 0.06 * (diffuseColor.rgb * 3.0 + 0.04)) * dif * smoothstep(0.3, 1.0, vH) * (1.0 - 0.6 * uWet);
          #ifndef USE_SHEEN
          totalEmissiveRadiance += (vec3(0.06, 0.058, 0.055) + diffuseColor.rgb * 0.5) * pow(1.0 - abs(dot(normalize(normal), V)), 1.2) * (0.35 + 0.65 * uDay); // phones: cheap velvet in place of sheen
          #endif
          totalEmissiveRadiance += vec3(0.05, 0.055, 0.065) * pow(1.0 - abs(dot(normalize(normal), V)), 1.6) * smoothstep(0.5, 1.0, vH) * (0.3 + 0.7 * uDay); // sky sheen on the coat edge
          float back = pow(max(dot(-V, L), 0.0), 3.0); totalEmissiveRadiance += uSunCol * back * uDay * smoothstep(0.6, 1.0, gTipK) * 0.35 * (0.2 + diffuseColor.rgb); }`);
  };
  m.userData.env = 0.2;
  return furMats[k] = m;
}
const SHADE_Y = { deer: [0.6, 1.12], elk: [0.6, 1.12], wolf: [0.38, 0.78] }; // countershading: darker belly and legs, sun-faded back
const FUR_K = 1.35; // the tufted coat is a little longer than the old shells
const FUR_LEN = { deer: 0.013, elk: 0.016, wolf: 0.026, rabbit: 0.018 }; // horses: sleek coat, no shell fur (their mane and tail get hair shells)
const MATS = {};
function matFor(kind, S) {
  const k = kind + S.toFixed(2);
  if (!MATS[k]) MATS[k] = kind === 'human' ? furMaterial({ fur: 0.05, cloth: true, rough: 0.62, scale: S }) : kind === 'horse' ? furMaterial({ scale: S, fur: 0.1, rough: 0.62, sheen: 0.55, sleek: 1 }) : furMaterial({ scale: S, fur: 0.16, shade: SHADE_Y[kind] });
  return MATS[k];
}
const eyeMat = new THREE.MeshPhysicalMaterial({ color: 0x030202, roughness: 0.03, clearcoat: 1, clearcoatRoughness: 0.02 });
eyeMat.userData.env = 1;
const scleraMat = new THREE.MeshPhysicalMaterial({ color: 0xd8d0c4, roughness: 0.15, clearcoat: 1 });
const hoofMat = new THREE.MeshPhysicalMaterial({ color: 0x0a0908, roughness: 0.3, clearcoat: 0.5 });
const noseMat = new THREE.MeshPhysicalMaterial({ color: 0x080706, roughness: 0.2, clearcoat: 0.8 });
function antlerMaterial(base, tip, rough) { // grooved, pearled bone that polishes to a pale tip
  const m = new THREE.MeshStandardMaterial({ color: base, roughness: rough });
  m.onBeforeCompile = sh => {
    sh.uniforms.uTip = { value: new THREE.Color(tip) };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nattribute float aU; varying float vU; varying vec3 vAP;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvU = aU; vAP = position;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 uTip; varying float vU; varying vec3 vAP;' + NOISE.replace('varying vec3 vRest;', ''))
      .replace('#include <color_fragment>', '#include <color_fragment>\n float pearl = vnoise(vAP * 420.0); diffuseColor.rgb = mix(diffuseColor.rgb * mix(0.75, 1.1, pearl), uTip, smoothstep(0.72, 0.97, vU));')
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor = mix(roughnessFactor + 0.15 * (1.0 - vU), 0.3, smoothstep(0.7, 1.0, vU));')
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        { vec3 q = vAP * vec3(260.0, 90.0, 260.0); vec3 g = vec3(vnoise(q), vnoise(q + 11.3), vnoise(q + 23.1)) - 0.5;
          vec3 q2 = vAP * 900.0; g += 0.5 * (vec3(vnoise(q2), vnoise(q2 + 5.1), vnoise(q2 + 9.7)) - 0.5);
          normal = normalize(normal + g * 0.55 * (1.0 - smoothstep(0.6, 0.95, vU))); }`);
  };
  return m;
}
const antlerMat = { black: antlerMaterial(0x1c1916, 0x5a5048, 0.45), natural: antlerMaterial(0x6e5a40, 0xe8dcc4, 0.55), elk: antlerMaterial(0x5a4632, 0xeadfca, 0.6) };
const unit = new THREE.SphereGeometry(1, 20, 14);

function taperTube(points, r0, r1, seg = 40, bumps = 0) {
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  const RS = 16, g = new THREE.TubeGeometry(curve, seg, 1, RS, false), P = g.attributes.position, c = new THREE.Vector3(), v = new THREE.Vector3(), au = new Float32Array(P.count);
  for (let i = 0; i <= seg; i++) { const u = i / seg; curve.getPointAt(u, c); let r = r0 + (r1 - r0) * Math.pow(u, 0.8); if (u > 0.85) r *= 0.25 + 0.75 * Math.sqrt((1 - u) / 0.15);
    for (let j = 0; j <= RS; j++) { const k = i * (RS + 1) + j, bump = bumps ? 1 + bumps * (1 - u) * Math.sin(j * 2.1 + i * 1.7) * Math.sin(i * 0.9) : 1; v.fromBufferAttribute(P, k).sub(c).multiplyScalar(r * bump).add(c); P.setXYZ(k, v.x, v.y, v.z); au[k] = u; } }
  g.setAttribute('aU', new THREE.BufferAttribute(au, 1)); g.computeVertexNormals(); return { g, curve };
}
function antlers(type, base, s, mat) {
  const grp = new THREE.Group(), off = (x, y, z) => [base[0] + x, base[1] + y, base[2] * s + z * s];
  if (type === 'whitetail') {
    const beam = taperTube([off(0, 0, 0), off(-0.045, 0.075, 0.055), off(-0.06, 0.17, 0.13), off(-0.01, 0.255, 0.195), off(0.1, 0.3, 0.21), off(0.21, 0.295, 0.165), off(0.285, 0.27, 0.095)], 0.02, 0.008, 48, 0.12);
    grp.add(new THREE.Mesh(beam.g, mat));
    [[0.1, 0.075, 0.03, 0.011], [0.4, 0.175, -0.012, 0.013], [0.6, 0.16, -0.008, 0.012], [0.79, 0.105, -0.004, 0.009]].forEach(([u, h, lean, r]) => {
      const p = beam.curve.getPointAt(u); grp.add(new THREE.Mesh(taperTube([[p.x, p.y - 0.004, p.z], [p.x + lean * 0.5 + 0.006, p.y + h * 0.5, p.z + 0.004 * s], [p.x + lean + 0.02, p.y + h, p.z - 0.004 * s]], r, 0.0045, 16).g, mat)); });
  } else {
    const k = 1.38;
    const beam = taperTube([off(0, 0, 0), off(-0.08 * k, 0.12 * k, 0.07 * k), off(-0.22 * k, 0.34 * k, 0.16 * k), off(-0.34 * k, 0.58 * k, 0.2 * k), off(-0.4 * k, 0.8 * k, 0.16 * k), off(-0.38 * k, 0.95 * k, 0.1 * k)], 0.034, 0.012, 56, 0.1);
    grp.add(new THREE.Mesh(beam.g, mat));
    [[0.08, 0.22, 0.24, 0.016], [0.16, 0.2, 0.22, 0.015], [0.38, 0.26, 0.12, 0.016], [0.55, 0.3, 0.08, 0.015], [0.72, 0.22, 0.05, 0.012], [0.86, 0.16, 0.06, 0.01]].forEach(([u, h, fwd, r]) => {
      const p = beam.curve.getPointAt(u); grp.add(new THREE.Mesh(taperTube([[p.x, p.y, p.z], [p.x + fwd * 0.6 * k, p.y + h * 0.45 * k, p.z], [p.x + fwd * k, p.y + h * k, p.z - 0.01 * s]], r, 0.006, 16).g, mat)); });
  }
  return grp;
}
function earMesh(len, wid, mat) {
  const g = new THREE.SphereGeometry(1, 18, 12, 0, Math.PI, 0, Math.PI), P = g.attributes.position;
  for (let i = 0; i < P.count; i++) { const u = (P.getY(i) + 1) / 2, k = 1 - Math.pow(u, 2.2) * 0.75; P.setX(i, P.getX(i) * k); P.setZ(i, P.getZ(i) * (0.6 + 0.4 * k)); }
  g.computeVertexNormals(); const m = new THREE.Mesh(g, mat); m.scale.set(wid, len, wid * 0.5); m.position.y = len * 0.9; return m;
}

// ---------- creature ----------
let UID = 1;
export class Creature {
  constructor(type, scene, opts = {}) {
    this.id = UID++; this.type = type; this.spec = CAT[type]; this.scene = scene;
    const sp = this.spec;
    this.size = (opts.size ?? sp.size) * (0.94 + rnd() * 0.12);
    this.pos = new THREE.Vector3(opts.x ?? 0, 0, opts.z ?? 0); this.yaw = opts.yaw ?? rnd() * TAU;
    this.speed = 0; this.wantSpeed = 0; this.wantYaw = this.yaw; this.vy = 0; this.air = 0; this.state = 'idle'; this.timer = rnd() * 4; this.phase = rnd();
    this.gait = 0; this.gaitPrev = 0; this.gaitBlend = 1; this.idleW = 1; this.graze = 0; this.alertW = 0; this.leapW = 0; this.photoW = 0; this.tilt = 0;
    this.group = new THREE.Group(); scene.add(this.group);
    if (sp.kind === 'bird') { this.initBird(); return; }
    const { D, lods } = decodeSpecies(sp.mesh); this.D = D; this.S = D.S || 1;
    // bones
    this.bones = D.bones.map(b => { const o = new THREE.Bone(); o.name = b.name; return o; });
    D.bones.forEach((b, i) => { const ph = b.parent >= 0 ? D.bones[b.parent].head : [0, 0, 0]; this.bones[i].position.set(b.head[0] - ph[0], b.head[1] - ph[1], b.head[2] - ph[2]); if (b.parent >= 0) this.bones[b.parent].add(this.bones[i]); });
    this.b = Object.fromEntries(this.bones.map(o => [o.name, o])); this.rest = Object.fromEntries(D.bones.map(b => [b.name, b.head]));
    this.rootY = D.bones[0].head[1];
    this.rig = new THREE.Group(); this.group.add(this.rig); this.rig.scale.setScalar(this.size);
    // coat colors per LOD
    let variant = opts.variant;
    if (sp.coat === 'human') variant = { skin: pick(HUMAN.skin), hair: pick(HUMAN.hair), shirt: pick(HUMAN.shirt), pants: pick(HUMAN.pants), boots: pick(HUMAN.boots), pack: pick(HUMAN.pack) }, variant.pack2 = new THREE.Color(variant.pack).multiplyScalar(0.6).getHex();
    if (sp.coat === 'horse' && !variant) variant = { c: (rnd() * HORSE_COATS.length) | 0, blaze: rnd() < 0.5, socks: [rnd() < 0.3, rnd() < 0.3, rnd() < 0.4, rnd() < 0.4].map(Number) };
    this.coat = opts.coat || sp.coat;
    if (!variant && ['whitetail', 'fawn', 'elk', 'wolf'].includes(this.coat)) variant = { t: (rnd() * 4) | 0 }; // four natural coat tones per species
    this.variant = variant;
    const ck = sp.mesh + '|' + this.coat + '|' + JSON.stringify(variant ?? null) + '|' + (this.coatKey ?? '');
    let fn = null;
    this.meshes = lods.map((L, li) => {
      const g = new THREE.BufferGeometry(); for (const [k, a] of Object.entries(L.attrs)) g.setAttribute(k, a); g.setIndex(L.index);
      const key = ck + '|' + li;
      let col = COLOR_CACHE.get(key);
      if (!col) {
        fn = fn || coatFn(this.coat, D, variant); const TINT = [[1, 1, 1], [0.9, 0.9, 0.92], [1.08, 1.03, 0.95], [1.02, 0.95, 0.86]][variant?.t ?? 0];
        col = new Float32Array(L.n * 3); const p = [0, 0, 0], nn = [0, 0, 0], cA = new THREE.Color();
        for (let i = 0; i < L.n; i++) {
          p[0] = L.pos[i * 3]; p[1] = L.pos[i * 3 + 1]; p[2] = L.pos[i * 3 + 2]; nn[0] = L.nor[i * 3]; nn[1] = L.nor[i * 3 + 1]; nn[2] = L.nor[i * 3 + 2];
          const sA = D.slots[L.SL[i * 3]], sB = D.slots[L.SL[i * 3 + 1]], mix = L.SL[i * 3 + 2] / 255;
          cA.copy(fn(p, nn, sA)); if (mix > 0.004 && sA !== sB) cA.lerp(fn(p, nn, sB), mix); col[i * 3] = cA.r * TINT[0]; col[i * 3 + 1] = cA.g * TINT[1]; col[i * 3 + 2] = cA.b * TINT[2];
        }
        COLOR_CACHE.set(key, col);
      }
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      g.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, this.rootY, 0), 2.5 * this.S);
      const m = new THREE.SkinnedMesh(g, matFor(sp.kind === 'human' ? 'human' : sp.mesh, this.S));
      m.castShadow = true; m.receiveShadow = true; m.boundingSphere = g.boundingSphere.clone(); m.frustumCulled = true; // cull creatures behind the camera
      if (li === 0) m.add(this.bones[0]);
      if (D.lods[li].part) { // high-detail head piece: drawn over the hero body, wins the overlap band at the neck
        const hm = m.material.clone(); hm.onBeforeCompile = m.material.onBeforeCompile; hm.customProgramCacheKey = () => 'headpart'; hm.polygonOffset = true; hm.polygonOffsetFactor = -1; hm.polygonOffsetUnits = -2; m.material = hm;
        m.userData.part = D.lods[li].part;
      }
      this.rig.add(m); m.visible = li === 0 || !!D.lods[li].part; return m;
    });
    this.parts = this.meshes.filter(m => m.userData.part); this.meshes = this.meshes.filter(m => !m.userData.part);
    this.group.updateMatrixWorld(true);
    this.skel = new THREE.Skeleton(this.bones);
    for (const m of this.meshes) m.bind(this.skel);
    for (const m of this.parts) m.bind(this.skel, this.meshes[0].bindMatrix);
    if (this.parts.length) this.addHairShells(this.parts[0], D);
    if (sp.mesh === 'horse') { this.addManeShells(D); this.addTack(); } // tack built hidden up front so its shaders warm with the rest
    // fur shells on the detailed mesh (animals only)
    this.shells = [];
    const furLen = FUR_LEN[sp.mesh];
    if (furLen && opts.shells !== false) {
      const base = this.meshes[0], sg = (/shellhi/.test(location.search) || !this.meshes[1]) ? base.geometry : this.meshes[1].geometry; // shells ride the mid mesh: same look, a sixth of the triangles
      const ig = new THREE.InstancedBufferGeometry(); for (const [k, a] of Object.entries(sg.attributes)) ig.setAttribute(k, a); ig.setIndex(sg.index);
      const N = CQ.shells, hs = new Float32Array(N); for (let i = 0; i < N; i++) hs[i] = (i + 1) / N;
      ig.setAttribute('aShell', new THREE.InstancedBufferAttribute(hs, 1)); ig.instanceCount = N; ig.boundingSphere = base.boundingSphere;
      const sm = new THREE.SkinnedMesh(ig, furShellMat(furLen * this.S * FUR_K, this.S, sp.mesh)); sm.boundingSphere = base.boundingSphere; sm.frustumCulled = true; sm.castShadow = false; sm.receiveShadow = !matchMedia('(pointer: coarse)').matches;
      this.rig.add(sm); sm.bind(this.skel, base.bindMatrix); this.shells.push(sm);
    }
    this.addAccessories(D);
    this.blob = new THREE.Mesh(blobGeo, blobMat); this.blob.layers.set(1); this.blob.renderOrder = 1;
    { const L = sp.kind === 'human' ? 0.55 : sp.kind === 'rabbit' ? 0.3 : 1.25 * this.S, W = sp.kind === 'human' ? 0.45 : sp.kind === 'rabbit' ? 0.2 : 0.55 * this.S; this.blob.scale.set(L * this.size, 1, W * this.size); }
    this.group.add(this.blob);
    this.tips = [];
    const feet = sp.kind === 'human' ? ['footL', 'footR'] : ['pasFL', 'pasFR', 'pasHL', 'pasHR'];
    for (const f of feet) for (const dx of sp.kind === 'human' ? [0.14, -0.06] : sp.kind === 'hoofed' ? [0.056 * this.S, 0.014 * this.S] : [0.07, 0.0]) {
      const h = this.rest[f], m = new THREE.Object3D();
      const tipY = sp.kind === 'human' ? 0.0 : sp.kind === 'hoofed' ? 0 : 0.0;
      m.position.set(dx + (sp.kind === 'human' ? 0 : sp.kind === 'hoofed' ? 0.035 * this.S - 0.035 * this.S : 0), tipY - h[1], 0); this.b[f].add(m); this.tips.push(m);
    }
    if (this.blob) this.blob.position.x = feet.reduce((t, f) => t + this.rest[f][0], 0) / feet.length * this.size;
    this.place(0);
  }
  addAccessories(D) {
    const sp = this.spec, A = D.attach, S = this.S, head = this.b.head;
    const attach = (bn, obj, w) => { const h = this.rest[bn]; obj.position.set(w[0] - h[0], w[1] - h[1], w[2] - h[2]); obj.traverse(o => { if (o.isMesh) { o.castShadow = true; } }); this.b[bn].add(obj); return obj; };
    const eyeS = { hoofed: 0.019, canine: 0.014, rabbit: 0.009, human: 0.011 }[sp.kind] * S;
    if (A.eye && A.eyeC) { const ec = A.eyeC || [A.eye[0], A.eye[1], A.eye[2] - 0.012];
      for (const s of [1, -1]) { const e = new THREE.Mesh(eyeballGeo(), eyeballMat); e.scale.setScalar(0.0118); e.rotation.y = -0.12 * s; attach('head', e, [ec[0], ec[1], ec[2] * s]); e.castShadow = false; } }
    else if (A.eye) for (const s of [1, -1]) { const e = new THREE.Mesh(unit, eyeMat); e.scale.set(eyeS, eyeS * 0.85, eyeS * 0.65); attach('head', e, [A.eye[0], A.eye[1], (A.eye[2] - eyeS * 0.25) * s]); }
    const coatMid = new THREE.MeshStandardMaterial({ roughness: 0.8, side: THREE.DoubleSide });
    if (sp.kind === 'hoofed') {
      const earCol = { black: 0x0b0a0a, whitetail: 0x7a5a3c, fawn: 0x96562a, elk: 0x4b3424, horse: 0x3a2618 }[sp.coat];
      coatMid.color.set(earCol);
      if (sp.coat === 'horse') coatMid.color.copy(this.meshes[0].geometry.attributes.color ? new THREE.Color().fromBufferAttribute(this.meshes[0].geometry.attributes.color, 10) : coatMid.color);
      this.ears = [];
      for (const s of [1, -1]) {
        const piv = new THREE.Group(), turn = new THREE.Group(); turn.rotation.y = -Math.PI / 2 * s;
        const L = sp.mesh === 'horse' ? 0.085 * S / 1.55 * 1.3 : 0.1 * S, W = sp.mesh === 'horse' ? 0.032 * S / 1.55 * 1.3 : 0.043 * S;
        turn.add(earMesh(L, W, coatMid)); piv.add(turn); piv.userData.s = s;
        attach('head', piv, [A.ear[0] - 0.01 * S, A.ear[1] - 0.012 * S, A.ear[2] * s]); this.ears.push(piv);
      }
      if (sp.antlers) { const mat = sp.coat === 'black' ? antlerMat.black : sp.antlers === 'elk' ? antlerMat.elk : antlerMat.natural;
        for (const s of [1, -1]) { const g = antlers(sp.antlers, [A.antler[0], A.antler[1] - 0.006 * S, A.antler[2]], s, mat); g.position.set(-this.rest.head[0], -this.rest.head[1], -this.rest.head[2]); g.traverse(o => o.isMesh && (o.castShadow = true)); head.add(g); } }
      if (A.nose) { const n = new THREE.Mesh(unit, noseMat); n.scale.set(0.016 * S, 0.02 * S, 0.026 * S); attach('head', n, [A.nose[0] - 0.012 * S, A.nose[1] + 0.004 * S, 0]); }
      // hooves
      const toe = new THREE.CylinderGeometry(0.0115, 0.0175, 0.052, 14, 1); toe.translate(0, 0.026, 0);
      for (const f of ['pasFL', 'pasFR', 'pasHL', 'pasHR']) {
        const h = this.rest[f], grp = new THREE.Group();
        if (sp.solidHoof) { const t = new THREE.Mesh(toe, hoofMat); t.rotation.z = 0.3; t.scale.set(2.3, 1.12, 2.05); grp.add(t); }
        else for (const dz of [0.0095, -0.0095]) { const t = new THREE.Mesh(toe, hoofMat); t.position.set(0.004, 0, dz); t.rotation.z = 0.42; t.scale.set(1.25, 1, 0.92); grp.add(t); }
        grp.scale.setScalar(S); attach(f, grp, [h[0] + 0.035 * S, 0.0, h[2]]);
      }
    } else if (sp.kind === 'rabbit') {
      coatMid.color.set(0x7a6652); this.ears = [];
      for (const s of [1, -1]) { const piv = new THREE.Group(), turn = new THREE.Group(); turn.rotation.y = -Math.PI / 2 * s; turn.add(earMesh(0.05, 0.016, coatMid)); piv.add(turn); piv.userData.s = s; attach('head', piv, [A.ear[0], A.ear[1] - 0.005, A.ear[2] * s * 0.7]); this.ears.push(piv); }
    } else if (this.type === 'athlete') {
      this.addAthleteGear(A);
    } else if (sp.kind === 'human') {
      const hatT = (rnd() * 4) | 0;
      if (hatT < 3) {
        const hm = new THREE.MeshStandardMaterial({ color: pick([0x3b4a2f, 0xc2a36b, 0x2c3e50, 0x8b2e2e, 0x222222]), roughness: 0.9 });
        const hat = new THREE.Group();
        if (hatT === 0) { const cap = new THREE.Mesh(new THREE.SphereGeometry(0.105, 18, 10, 0, TAU, 0, Math.PI / 2), hm); const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.008, 16, 1, false, -Math.PI / 2, Math.PI), hm); brim.position.set(0.08, 0.0, 0); brim.scale.set(1.3, 1, 1.1); hat.add(cap, brim); }
        if (hatT === 1) { const top = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.1, 0.08, 18), hm); top.position.y = 0.035; const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.008, 22), hm); hat.add(top, brim); }
        if (hatT === 2) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.108, 18, 10, 0, TAU, 0, Math.PI / 1.8), hm); b.scale.y = 1.15; hat.add(b); }
        attach('head', hat, [0.012, 1.715, 0]);
      }
      const cam = new THREE.Group(), cm = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.4 });
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.12), cm); const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.03, 0.07, 16).rotateZ(Math.PI / 2), cm); lens.position.x = 0.07;
      cam.add(body, lens); attach('handR', cam, [0.035, 0.81, -0.19]); this.camProp = cam;
    }
  }
  initBird() {
    const G = birdParts();
    const body = new THREE.Mesh(G.body, G.bodyMat); body.castShadow = true;
    const eyes = [1, -1].map(s => { const e = new THREE.Mesh(unit, eyeMat); e.scale.setScalar(0.0042); e.position.set(0.081, 0.009, 0.0125 * s); return e; });
    this.wings = [1, -1].map(s => {
      const root = new THREE.Group(); root.position.set(0.018, 0.012, 0.016 * s); root.scale.z = s; root.userData.s = s;
      const arm = new THREE.Mesh(G.arm, G.wingMat), hand = new THREE.Group(), prim = new THREE.Mesh(G.hand, G.wingMat);
      hand.position.set(-0.004, 0, 0.088); hand.add(prim); root.add(arm, hand); root.userData.hand = hand;
      arm.castShadow = prim.castShadow = true; return root;
    });
    const tail = new THREE.Group(); tail.position.set(-0.066, 0.004, 0); tail.add(new THREE.Mesh(G.tail, G.wingMat)); this.tail = tail;
    this.group.add(body, ...eyes, ...this.wings, tail); this.group.scale.setScalar(1.5);
    this.pos.y = 14; this.vel = new THREE.Vector3(Math.cos(this.yaw) * 9, 0, -Math.sin(this.yaw) * 9); this.flap = rnd() * TAU; this.fold = 0;
  }
  setLOD(dist, LITE) {
    if (this.spec.kind === 'bird') { this.group.visible = dist < 220; return; }
    const hi = dist < (LITE ? 9 : CQ.hi) * this.S;
    const M = this.meshes, mid = !hi && (M.length < 3 || dist < (LITE ? 22 : CQ.mid) * this.S);
    M[0].visible = hi; M[1].visible = mid; if (M[2]) M[2].visible = !hi && !mid;
    for (const p of this.parts) p.visible = hi; // the hero body has its head cut out for this piece, so they must always show together
    const hairOn = hi && dist < (LITE ? 2.5 : CQ.furDist * 0.5); for (const sm of this.hairShells || []) sm.visible = hairOn;
    if (this.maneShells) { const on = hi && dist < (LITE ? 6 : CQ.furDist * 1.6) * this.S; for (const sm of this.maneShells) sm.visible = on; }
    const furOn = hi && dist < (LITE ? 0 : CQ.furDist) * this.S; for (const sm of this.shells || []) sm.visible = furOn;
    this.group.visible = dist < 125;
    this.meshes[1].castShadow = dist < 32; if (this.meshes[2]) this.meshes[2].castShadow = false;
  }
  get height() { return (this.spec.kind === 'human' ? 1.75 : this.spec.kind === 'rabbit' ? 0.25 : this.rootY * 1.3) * this.size; }
  get center() { return this._c = (this._c || new THREE.Vector3()).set(this.pos.x, this.pos.y + this.height * 0.55, this.pos.z); }
  forward(out = new THREE.Vector3()) { return out.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw)); }

  // ---- locomotion integrate + animate ----
  step(dt, time, world) {
    const sp = this.spec;
    if (sp.kind === 'bird') return this.stepBird(dt, time);
    // turn + accelerate
    let dy = ((this.wantYaw - this.yaw + Math.PI * 3) % TAU) - Math.PI;
    const turnRate = (2.6 + 2.5 / (1 + this.speed * 0.4)) * (sp.kind === 'rabbit' ? 2 : 1);
    this.yaw += clamp(dy, -turnRate * dt, turnRate * dt);
    const acc = (this.wantSpeed > this.speed ? 6 : 9) * (sp.kind === 'rabbit' ? 2 : 1) * Math.sqrt(this.S * this.size);
    this.speed += clamp(this.wantSpeed - this.speed, -acc * dt, acc * dt);
    const f = this.forward(_v1);
    this.pos.addScaledVector(f, this.speed * dt);
    // obstacles: trees + world bounds + pond
    for (const t of world.nearTrees(this.pos.x, this.pos.z)) { const dx = this.pos.x - t.x, dz = this.pos.z - t.z, d = Math.hypot(dx, dz), R = t.r + 0.35 * this.size * this.S; if (d < R && d > 1e-4) { this.pos.x += dx / d * (R - d); this.pos.z += dz / d * (R - d); } }
    const r = Math.hypot(this.pos.x, this.pos.z); if (r > 175) { this.pos.x *= 175 / r; this.pos.z *= 175 / r; }
    // vertical: jump arc
    const gH = terrainH(this.pos.x, this.pos.z);
    if (this.air > 0 || this.vy > 0) { this.vy -= 22 * dt; this.air += this.vy * dt; if (this.air <= 0) { this.air = 0; this.vy = 0; } }
    this.pos.y = gH + this.air;
    if (this.ko) { this.koPose(dt); this.place(dt); return; }
    this.animate(dt, time);
    if (this.overlay(dt, time)) this.groundContact(this._lift || 0);
    if (this.onAnim) this.onAnim(dt, time);
    this.place(dt);
  }
  jump() { if (this.air > 0 || this.spec.kind === 'bird') return; const k = this.spec.kind; this.vy = k === 'hoofed' ? 7.2 : k === 'canine' ? 6.2 : k === 'rabbit' ? 4.2 : 3.6; this.air = 0.001; }
  place(dt) {
    const L = 0.55 * this.S * this.size;
    const f = this.forward(_v1), hF = terrainH(this.pos.x + f.x * L, this.pos.z + f.z * L), hB = terrainH(this.pos.x - f.x * L, this.pos.z - f.z * L);
    const pitch = this.spec.kind === 'human' ? 0 : Math.atan2(hF - hB, 2 * L);
    this.tilt = dt ? lerp(this.tilt, pitch, 1 - Math.exp(-8 * dt)) : pitch;
    this.group.position.copy(this.pos);
    this.group.rotation.set(0, this.yaw, this.tilt, 'YXZ');
    if (this.blob) { this.blob.position.y = 0.03 - (this.air || 0); this.blob.material.opacity = 1; this.blob.scale.y = 1; this.blob.visible = (this.air || 0) < 2.5; }
  }
  animate(dt, time) {
    const k = this.spec.kind;
    if (k === 'human') return this.animHuman(dt, time);
    if (k === 'rabbit') return this.animRabbit(dt, time);
    return this.animQuad(dt, time);
  }
  // measure how far a planted foot travels backward per gait cycle (rig-local units, cached per species)
  calibrateStrides() {
    const key = this.spec.mesh + '|' + this.spec.kind; if (STRIDE_CACHE[key]) return this.strideCal = STRIDE_CACHE[key];
    const B = this.b, v = new THREE.Vector3(), tipX = i => { this.tips[i].getWorldPosition(v); this.rig.worldToLocal(v); return v; };
    const out = [];
    if (this.spec.kind === 'human') {
      for (const run of [0, 1]) { // support = lower foot; integrate its backward travel over one cycle
        let travel = 0, prev = null; const N = 48;
        for (let k = 0; k <= N; k++) { const p = k / N * TAU, amp = lerp(1, 1.5, run);
          for (const [s, o] of [['L', 0], ['R', Math.PI]]) { const q = p + o; B['thigh' + s].rotation.set(0, 0, 0.42 * Math.sin(q) * amp); B['shin' + s].rotation.set(0, 0, -(0.08 + lerp(0.9, 1.5, run) * Math.pow(Math.max(0, Math.sin(q + 1.15)), 1.6))); B['foot' + s].rotation.set(0, 0, 0.22 * Math.sin(q - 0.6) * amp); }
          B.root.rotation.set(0, 0, 0); B.spine.rotation.set(0, 0, 0); this.rig.updateMatrixWorld(true);
          const L = (tipX(0).y + tipX(1).y) / 2, Lx = (tipX(0).x + tipX(1).x) / 2, R = (tipX(2).y + tipX(3).y) / 2, Rx = (tipX(2).x + tipX(3).x) / 2;
          const cur = L < R ? { s: 'L', x: Lx } : { s: 'R', x: Rx };
          if (prev && prev.s === cur.s) travel += Math.max(0, prev.x - cur.x); prev = cur; }
        out.push(Math.max(0.6, travel)); }
    } else {
      GAITS.forEach((G, gi) => { // the left hind's sweep while it is planted (duty part of the cycle)
        const N = 24, xs = [];
        for (let k = 0; k <= N; k++) { const t = (G.ph.HL + k / N * G.duty) % 1, P = quadPose(G, t, this.spec.kind === 'canine');
          for (const S2 of ['L', 'R']) for (const j of ['scap', 'hum', 'rad', 'canF', 'pasF', 'fem', 'tib', 'canH', 'pasH']) B[j + S2].rotation.z = P[j + S2];
          B.chest.rotation.z = P.chest; B.hips.rotation.z = P.hips; B.root.rotation.set(0, 0, P.pitch); this.rig.updateMatrixWorld(true);
          xs.push((tipX(4).x + tipX(5).x) / 2); }
        out[gi] = Math.max(0.3 * this.S, (xs[0] - xs[N]) / G.duty); });
    }
    return this.strideCal = STRIDE_CACHE[key] = out;
  }
  groundContact(extra = 0) {
    this._lift = extra;
    const R = this.b.root; R.position.y = this.rootY;
    this.rig.updateMatrixWorld(true);
    let minY = Infinity; for (const m of this.tips) { m.getWorldPosition(_v2); this.rig.worldToLocal(_v2); minY = Math.min(minY, _v2.y); }
    R.position.y = this.rootY - minY + extra;
  }
  animQuad(dt, time) {
    const S = this.S * this.size, v = this.speed, sp = this.spec, canine = sp.kind === 'canine';
    const thr = [1.9 * Math.sqrt(S), 4.4 * Math.sqrt(S)];
    const g = v < thr[0] ? 0 : v < thr[1] ? 1 : 2;
    if (g !== this.gait) { this.gaitPrev = this.gait; this.gait = g; this.gaitBlend = 0; }
    this.gaitBlend = Math.min(1, this.gaitBlend + dt / 0.35);
    const G = GAITS[this.gait], CAL = this.strideCal || this.calibrateStrides();
    // planted feet: phase advances so a stance hoof's backward sweep exactly matches ground speed
    const strideLen = lerp(CAL[this.gaitPrev], CAL[this.gait], this.gaitBlend) * this.size;
    this.phase = (this.phase + dt * Math.max(v, 0.0) / strideLen) % 1;
    const moving = sstep(0.05, 0.5, v);
    this.idleW = lerp(this.idleW, 1 - moving, 1 - Math.exp(-6 * dt));
    this.graze = lerp(this.graze, this.state === 'graze' ? 1 : 0, 1 - Math.exp(-2.5 * dt));
    this.alertW = lerp(this.alertW, this.state === 'alert' ? 1 : 0, 1 - Math.exp(-5 * dt));
    this.leapW = lerp(this.leapW, this.air > 0.05 ? 1 : 0, 1 - Math.exp(-10 * dt));
    const pA = quadPose(GAITS[this.gait], this.phase, canine), pB = this.gaitBlend < 1 ? quadPose(GAITS[this.gaitPrev], this.phase, canine) : null;
    const t = this.phase, W = 1 - this.idleW, B = this.b;
    const mixv = (name) => { let a = pA[name]; if (pB) a = lerp(pB[name], a, this.gaitBlend); a = a * W; if (this.leapW > 0.01) a = lerp(a, LEAP[name] ?? 0, this.leapW); return a; };
    for (const S2 of ['L', 'R']) for (const j of ['scap', 'hum', 'rad', 'canF', 'pasF', 'fem', 'tib', 'canH', 'pasH']) B[j + S2].rotation.z = mixv(j + S2);
    B.chest.rotation.z = mixv('chest'); B.hips.rotation.z = mixv('hips');
    const pitch = mixv('pitch') + this.leapW * 0.08 * Math.sign(this.vy);
    { const dyaw = ((this.yaw - (this._py ?? this.yaw) + Math.PI * 3) % TAU) - Math.PI; this._py = this.yaw; this._turn = lerp(this._turn || 0, dt > 0 ? dyaw / dt : 0, 1 - Math.exp(-5 * dt)); }
    const bank = clamp(-this._turn * v * 0.035, -0.28, 0.28);
    const breath = Math.sin(time * (1.3 + 1.6 * (1 - this.idleW) + (this.state === 'flee' ? 1.2 : 0)) + this.id) * (0.012 + 0.01 * this.idleW);
    B.root.rotation.set(0.02 * Math.sin(TAU * t) * W + bank + 0.015 * Math.sin(time * 0.35 + this.id) * this.idleW, 0, pitch);
    B.chest.rotation.z += breath;
    // head & neck: run posture, grazing, alert
    const run = this.gait === 2 ? W : 0;
    const graze = this.graze * this.idleW, alert = this.alertW;
    const nod = (pB ? lerp(pB.nod, pA.nod, this.gaitBlend) : pA.nod) * W;
    B.neck1.rotation.z = -0.2 * run - pitch * 0.7 - (B.chest.rotation.z) * 0.6 + nod - graze * (canine ? 0.7 : 1.05) + alert * 0.15;
    B.neck2.rotation.z = -0.05 * run - graze * 0.25 + alert * 0.1;
    B.head.rotation.z = 0.18 * run - pitch * 0.35 + graze * (canine ? 0.3 : 0.65) - alert * 0.05 + 0.04 * Math.sin(time * 1.3 + this.id) * this.idleW * (1 - graze);
    B.head.rotation.y = (this.lookYaw || 0) * alert + (0.35 * Math.sin(time * 0.23 + this.id * 1.7) + 0.15 * Math.sin(time * 0.61 + this.id)) * this.idleW * (1 - graze) * (1 - alert) - bank * 0.6;
    B.neck1.rotation.x = -bank * 0.5;
    if (this.ears) this.ears.forEach((e, i) => { const s = e.userData.s; const fk = Math.max(0, Math.sin(time * 0.9 + this.id * 3.1 + i * 2.2)); const flick = Math.pow(fk, 40) * 0.6; e.rotation.set(0.62 * s + flick * s, flick * 0.8, 0.3 + 0.35 * run - 0.2 * alert + 0.08 * Math.sin(time * (2 + i) + this.id) - flick * 0.4); });
    const flag = this.state === 'flee' || alert > 0.5 ? 1 : 0;
    this._tail = lerp(this._tail || 0, flag, 1 - Math.exp(-6 * dt));
    if (sp.mesh === 'deer') { const sw = Math.pow(Math.max(0, Math.sin(time * 0.7 + this.id * 2.3)), 12); B.tail1.rotation.z = lerp(1.3, -0.15, this._tail) + 0.1 * Math.sin(time * 3 + this.id); B.tail1.rotation.x = sw * 0.35 * Math.sin(time * 14); B.tail2.rotation.z = lerp(0.3, -0.1, this._tail); }
    else if (canine) { B.tail1.rotation.z = lerp(0.1, 0.55, run) + 0.12 * Math.sin(time * 2 + this.id); B.tail1.rotation.x = 0.15 * Math.sin(time * 2.4 + this.id) * this.idleW; B.tail2.rotation.z = 0.2 * Math.sin(time * 2 + 0.6); }
    else { B.tail1.rotation.z = -0.25 * run + 0.06 * Math.sin(time * 2 + this.id); B.tail1.rotation.x = 0.12 * Math.sin(time * 1.1 + this.id) * this.idleW; B.tail2.rotation.z = -0.15 * run; }
    const susp = (pB ? lerp(pB.lift, pA.lift, this.gaitBlend) : pA.lift) * W;
    this.groundContact(susp * S);
    this.hoofIK(dt);
  }
  // planted hooves/paws: a foot on the ground is pinned; the two upper joints of that leg re-solve so the lower leg keeps its FK shape
  hoofIK(dt) {
    if (this.act || this.air > 0.02 || this.ko || this.remote || window.__noIK || !this.tips || this.tips.length < 8) return;
    const B = this.b, legs = this._legs || (this._legs = [['hum', 'rad', 'canF', 0], ['hum', 'rad', 'canF', 1], ['fem', 'tib', 'canH', 2], ['fem', 'tib', 'canH', 3]].map(([a, b, c, i]) => ({ a, b, c, i, lock: null })));
    this.rig.updateMatrixWorld(true);
    const tip = i => this.tips[i * 2].getWorldPosition(new THREE.Vector3()).add(this.tips[i * 2 + 1].getWorldPosition(_v2)).multiplyScalar(0.5);
    const tips = [0, 1, 2, 3].map(tip), low = Math.min(...tips.map(t => t.y));
    for (const L of legs) {
      const side = L.i % 2 ? 'R' : 'L', A = B[L.a + side], Bb = B[L.b + side], C = B[L.c + side], t = tips[L.i];
      const planted = t.y < low + 0.012 * this.S;
      if (planted && !L.lock) L.lock = t.clone();
      if (!planted && L.lock && t.y > low + 0.03 * this.S) L.lock = null;
      if (!L.lock) continue;
      L.lock.y = t.y; // keep the FK height (ground contact already set it); pin x/z only
      if (L.lock.distanceTo(t) > 0.35 * this.S) { L.lock = null; continue; }
      // target for joint C = lock - (tip - C) offset, expressed in A's parent space
      const cW = C.getWorldPosition(new THREE.Vector3()), tgt = L.lock.clone().sub(t).add(cW);
      const P = A.parent; P.worldToLocal(tgt); tgt.sub(A.position);
      const r1 = Bb.position, r2 = C.position, l1 = Math.hypot(r1.x, r1.y), l2 = Math.hypot(r2.x, r2.y), d = clamp(Math.hypot(tgt.x, tgt.y), Math.abs(l1 - l2) + 1e-3, l1 + l2 - 1e-3);
      const a1 = Math.atan2(r1.y, r1.x), a2 = Math.atan2(r2.y, r2.x);
      const cg = clamp((d * d - l1 * l1 - l2 * l2) / (2 * l1 * l2), -1, 1), g = Math.acos(cg); // angle between r1 and rotated r2
      const cands = [g, -g].map(x => x - (a2 - a1)); const cur = Bb.rotation.z; const th2 = Math.abs(angWrap(cands[0] - cur)) < Math.abs(angWrap(cands[1] - cur)) ? cands[0] : cands[1];
      const ex = r1.x + Math.cos(a2 + th2) * l2, ey = r1.y + Math.sin(a2 + th2) * l2; // end point with A unrotated
      const th1 = Math.atan2(tgt.y, tgt.x) - Math.atan2(ey, ex);
      A.rotation.z = th1; Bb.rotation.z = th2;
    }
  }
  animRabbit(dt, time) {
    const v = this.speed, B = this.b;
    this.phase = (this.phase + dt * v / 0.42) % 1;
    const moving = sstep(0.05, 0.3, v); this.idleW = lerp(this.idleW, 1 - moving, 1 - Math.exp(-8 * dt));
    const p = this.phase, W = 1 - this.idleW;
    const push = sstep(0.0, 0.3, p) * (1 - sstep(0.45, 0.7, p)), fold = sstep(0.35, 0.6, p) * (1 - sstep(0.85, 1.0, p));
    for (const s of ['L', 'R']) {
      B['fem' + s].rotation.z = (-0.7 * push + 0.6 * fold) * W; B['tib' + s].rotation.z = (0.5 * push - 0.6 * fold) * W; B['canH' + s].rotation.z = (-0.5 * push + 0.5 * fold) * W;
      B['hum' + s].rotation.z = (0.7 * push - 0.4 * fold) * W; B['rad' + s].rotation.z = (0.3 * push) * W; B['canF' + s].rotation.z = (-0.6 * fold) * W;
    }
    B.root.rotation.z = (0.25 * push - 0.2 * fold) * W;
    B.neck1.rotation.z = -0.1 * W + 0.06 * Math.sin(time * 9 + this.id) * this.idleW * (this.state === 'graze' ? 1 : 0);
    if (this.ears) this.ears.forEach((e, i) => { const s = e.userData.s; e.rotation.set(0.25 * s, 0, -0.1 + 0.5 * W + 0.1 * Math.sin(time * (3 + i) + this.id)); });
    const lift = p < 0.8 ? Math.sin(Math.PI * p / 0.8) * 0.09 * W * Math.min(1, v / 2) : 0;
    this.groundContact(lift);
  }
  animHuman(dt, time) {
    const v = this.speed, B = this.b;
    const run = sstep(2.0, 3.2, v);
    const CAL = this.strideCal || this.calibrateStrides();
    const stride = lerp(CAL[0], CAL[1], run) * this.size; // measured: support foot travel per cycle
    this.phase = (this.phase + dt * v / stride) % 1;
    const moving = sstep(0.05, 0.4, v); this.idleW = lerp(this.idleW, 1 - moving, 1 - Math.exp(-6 * dt));
    this.photoW = lerp(this.photoW, this.state === 'photo' ? 1 : 0, 1 - Math.exp(-4 * dt));
    const p = this.phase * TAU, W = 1 - this.idleW, amp = lerp(1, 1.5, run) * W, ph = this.photoW;
    const legs = { L: 0, R: Math.PI };
    for (const [s, o] of Object.entries(legs)) {
      const q = p + o;
      B['thigh' + s].rotation.z = 0.42 * Math.sin(q) * amp;
      B['shin' + s].rotation.z = -(0.08 + lerp(0.9, 1.5, run) * Math.pow(Math.max(0, Math.sin(q + 1.15)), 1.6)) * W;
      B['foot' + s].rotation.z = 0.22 * Math.sin(q - 0.6) * amp;
      const swing = -0.38 * Math.sin(q) * amp;
      B['arm' + s].rotation.set(lerp(0, s === 'L' ? 0.42 : -0.42, ph), 0, lerp(swing + 0.04, 1.2, ph));
      B['fore' + s].rotation.z = lerp(0.18 + lerp(0.15, 1.1, run) * W + 0.1 * Math.max(0, Math.sin(q)), 1.85, ph);
      B['clav' + s].rotation.z = 0;
    }
    { const dyaw = ((this.yaw - (this._py ?? this.yaw) + Math.PI * 3) % TAU) - Math.PI; this._py = this.yaw; this._turn = lerp(this._turn || 0, dt > 0 ? dyaw / dt : 0, 1 - Math.exp(-5 * dt)); }
    const bank = clamp(-this._turn * v * 0.03, -0.22, 0.22), I = this.idleW;
    const breath = Math.sin(time * (1.4 + 1.8 * W) + this.id) * (0.02 + 0.015 * W), shift = Math.sin(time * 0.31 + this.id);
    B.spine.rotation.set(-shift * 0.025 * I, 0.07 * Math.sin(p) * amp, (0.05 + 0.09 * run) * W + breath * 0.5);
    B.chest.rotation.set(0, -0.12 * Math.sin(p) * amp, 0.04 * run * W + breath);
    B.root.rotation.set(0.03 * Math.sin(p) * amp + bank + shift * 0.035 * I, -0.08 * Math.sin(p) * amp, 0);
    for (const s of ['L', 'R']) { B['clav' + s].rotation.z = breath * 0.6; if (I > 0.01 && ph < 0.5) { B['arm' + s].rotation.x += (s === 'L' ? 0.08 : -0.08) * I; B['arm' + s].rotation.z += 0.04 * Math.sin(time * 0.8 + (s === 'L' ? 0 : 1.3)) * I; B['fore' + s].rotation.z += 0.12 * I; } }
    B.head.rotation.set(-bank * 0.5, (this.lookYaw || 0) * 0.5 * (1 - ph) + (0.3 * Math.sin(time * 0.21 + this.id) + 0.1 * Math.sin(time * 0.57)) * this.idleW * (1 - ph), -0.06 * ph + 0.03 * Math.sin(time * 0.7 + this.id) * this.idleW + 0.05 * run * W);
    if (this.camProp) this.camProp.visible = ph > 0.15 || this.type === 'hiker';
    const bob = Math.abs(Math.cos(p)) * 0.025 * amp;
    this.groundContact(bob * 0 + (run > 0.5 ? Math.max(0, Math.sin(p * 2)) * 0.04 * W : 0));
    this.legIK(dt);
  }
  // planted feet for people: a stance ankle is pinned in the world (and to the ground under it); a two-bone solve bends hip and knee to reach it
  legIK(dt) {
    const B = this.b, root = B.root, F = this._feet || (this._feet = { L: { lock: null, w: 0 }, R: { lock: null, w: 0 } });
    if (this.act || this.air > 0.02 || this.ko || this.remote || window.__noIK) { F.L.lock = F.R.lock = null; F.L.w = F.R.w = 0; return; }
    this.rig.updateMatrixWorld(true);
    const ank = {}, wv = new THREE.Vector3();
    for (const s of ['L', 'R']) ank[s] = B['foot' + s].getWorldPosition(new THREE.Vector3());
    const low = Math.min(ank.L.y, ank.R.y);
    for (const s of ['L', 'R']) {
      const f = F[s], a = ank[s], gy = terrainH(a.x, a.z), planted = a.y < low + 0.02;
      if (planted && !f.lock) f.lock = { x: a.x, z: a.z, h: a.y - gy };
      if (!planted && f.lock && a.y > low + 0.035) f.lock = null;
      f.w = f.lock ? 1 : lerp(f.w, 0, 1 - Math.exp(-14 * dt)); // the lock starts exactly where the foot is, so it can engage at full weight
      if (f.w < 0.02) continue;
      const tgt = f.lock ? wv.set(f.lock.x, terrainH(f.lock.x, f.lock.z) + f.lock.h, f.lock.z) : wv.copy(a);
      if (f.lock && Math.hypot(tgt.x - a.x, tgt.z - a.z) > 0.45) { f.lock = null; continue; } // over-stretched: let the stride re-plant
      tgt.lerp(a, 1 - f.w); root.worldToLocal(tgt);
      const H = B['thigh' + s].position, dx = tgt.x - H.x, dy = tgt.y - H.y, L1 = 0.43, L2 = 0.435;
      const d = clamp(Math.hypot(dx, dy), 0.12, L1 + L2 - 0.004);
      const A = Math.acos(clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1)), K = Math.acos(clamp((L1 * L1 + L2 * L2 - d * d) / (2 * L1 * L2), -1, 1));
      const th = Math.atan2(dx, -dy) + A, kn = -(Math.PI - K);
      const t0 = B['thigh' + s].rotation.z, k0 = B['shin' + s].rotation.z;
      B['thigh' + s].rotation.z = lerp(t0, th, f.w); B['shin' + s].rotation.z = lerp(k0, kn, f.w);
      if (f.lock) B['foot' + s].rotation.z = lerp(B['foot' + s].rotation.z, -(th + kn) - root.rotation.z, f.w * 0.7); // keep the sole flat while planted
    }
  }
  stepBird(dt, time) {
    const ground = this.pos.y - terrainH(this.pos.x, this.pos.z) < 0.35;
    this.fold += ((ground ? 1 : 0) - this.fold) * Math.min(1, dt * 6);
    if (!this.gliding && !ground) this.flap += dt * 17;
    // swallow wingbeat: deep downstroke with the hand extended, quick upstroke with the hand swept back
    const ph = this.flap, beat = this.gliding || ground ? 0 : 1, down = Math.sin(ph), f = this.fold;
    for (const w of this.wings) {
      const hand = w.userData.hand, s = w.userData.s; // root angles flip per side; the hand sits inside the mirror, so it doesn't
      w.rotation.x = s * ((beat * (0.15 + 0.85 * down) - (1 - beat) * 0.06) * (1 - f) + f * 0.2);
      w.rotation.y = -s * ((beat * (0.12 + 0.35 * Math.max(0, -Math.cos(ph))) + (1 - beat) * 0.12) * (1 - f) + f * 1.25);
      hand.rotation.x = beat * 0.35 * Math.sin(ph - 0.7) * (1 - f);
      hand.rotation.y = -((beat * 0.55 * Math.max(0, Math.cos(ph)) + (1 - beat) * 0.18) * (1 - f) + f * 1.75);
    }
    this.tail.scale.z = 1 + 0.5 * (1 - beat) * (1 - f); this.tail.rotation.z = f * 0.25;
    this.pos.addScaledVector(this.vel, dt);
    this.yaw = Math.atan2(-this.vel.z, this.vel.x);
    this.group.position.copy(this.pos); this.group.rotation.set(0, this.yaw, Math.atan2(this.vel.y, Math.hypot(this.vel.x, this.vel.z)), 'YXZ');
    this.group.rotation.x = -clamp((this._yawRate || 0) * 0.4, -0.7, 0.7);
  }
  dispose() { this.scene.remove(this.group); }
}
const _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3();
const STRIDE_CACHE = {};
const angWrap = a => ((a + Math.PI * 3) % TAU) - Math.PI;

// ---------- barn swallow: lathed body with plumage zones, two-part feathered wings, forked tail ----------
let BIRD = null, EYEBALL = null;
// eyeball: sclera, brown iris with radial fibres and a dark limbal ring, pupil, glossy cornea (vertex colours on a dense sphere, +x = gaze)
function eyeballGeo() {
  if (EYEBALL) return EYEBALL;
  const g = new THREE.SphereGeometry(1, 48, 36), P = g.attributes.position, col = new Float32Array(P.count * 3), c = new THREE.Color();
  const sclera = new THREE.Color(0xc8bcae), vein = new THREE.Color(0xa8807a), irisA = new THREE.Color(0x3b2214), irisB = new THREE.Color(0x6a4024), limb = new THREE.Color(0x140b07), pupil = new THREE.Color(0x020101);
  for (let i = 0; i < P.count; i++) { const x = P.getX(i), y = P.getY(i), z = P.getZ(i), a = Math.acos(Math.max(-1, Math.min(1, x))), th = Math.atan2(y, z);
    if (a < 0.2) c.copy(pupil);
    else if (a < 0.47) { const f = (a - 0.2) / 0.27, fib = 0.5 + 0.5 * Math.sin(th * 37) * Math.sin(th * 11 + a * 20); c.copy(irisA).lerp(irisB, f * 0.6 + fib * 0.4); if (a > 0.43) c.lerp(limb, (a - 0.43) / 0.04); }
    else { c.copy(sclera).lerp(vein, Math.max(0, (a - 1.2) / 1.6) * 0.5); }
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3)); return EYEBALL = g;
}
const eyeballMat = new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.03 });
eyeballMat.userData.env = 0.45;
// hair + beard shells: grown only where the sculpt's hair/beard/brow slots are, short and dense, coiled for the curly top
const hairShellMats = {};
function hairShellMat(i, N) {
  if (hairShellMats[i + '|' + N]) return hairShellMats[i + '|' + N];
  const f = (i + 1) / N, m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, metalness: 0 });
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, { uK: { value: f }, uSunV: CENV.sunV, uSunCol: CENV.sunCol, uDay: CENV.day, uWet: CENV.wet });
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nattribute vec2 aFur; uniform float uK; varying vec3 vRestS; varying float vFur;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n vRestS = position; vFur = aFur.x; transformed += objectNormal * aFur.y * uK; transformed.y -= aFur.y * uK * uK * 0.5 * (1.0 - aFur.x * 0.0);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float uK, uDay, uWet; uniform vec3 uSunV, uSunCol; varying vec3 vRestS; varying float vFur;\nfloat hs2(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }')
      .replace('#include <color_fragment>', `#include <color_fragment>
        { if (vFur < 0.5) discard;
          vec3 q = mat3(0.8, 0.36, -0.48, -0.48, 0.86, -0.17, 0.36, 0.36, 0.86) * vRestS * 1500.0;
          // coils: offset each strand cell in a small circle as the layer rises
          q.xz += vec2(cos(uK * 9.0 + hs2(floor(q)) * 6.28), sin(uK * 9.0 + hs2(floor(q)) * 6.28)) * 0.25;
          vec3 cell = floor(q), fq = fract(q) - 0.5; float h = hs2(cell);
          if (h < uK * 0.85 || length(fq) > 0.48 * (1.0 - uK * 0.55)) discard;
          diffuseColor.rgb *= mix(0.55, 1.15, uK) * (0.85 + 0.3 * hs2(cell + 3.1)) * (1.0 - 0.3 * uWet); }`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        { vec3 vv = normalize(vViewPosition); float back = pow(max(dot(-vv, uSunV), 0.0), 2.0); float rim = pow(1.0 - abs(dot(normal, vv)), 2.0);
          totalEmissiveRadiance += uSunCol * (0.05 + back) * rim * uK * 0.6 * uDay * (0.3 + diffuseColor.rgb * 4.0); }`);
  };
  m.userData.env = 0.25; return hairShellMats[i + '|' + N] = m;
}
function mergeGeos(gs) { // position/normal/index merge for simple accessory parts
  let n = 0, m = 0; for (const g of gs) { n += g.attributes.position.count; m += g.index.count; }
  const P = new Float32Array(n * 3), N = new Float32Array(n * 3), I = new Uint32Array(m); let o = 0, k = 0;
  for (const g of gs) { P.set(g.attributes.position.array, o * 3); N.set(g.attributes.normal.array, o * 3); for (const i of g.index.array) I[k++] = i + o; o += g.attributes.position.count; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(P, 3)); g.setAttribute('normal', new THREE.BufferAttribute(N, 3)); g.setIndex(new THREE.BufferAttribute(I, 1)); return g;
}
function featherTex() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
  x.fillStyle = '#fff'; x.fillRect(0, 0, 256, 256);
  // vanes: feather shafts run along u (chord); each feather is a soft band with a darker shaft and fine barbs
  for (let i = 0; i < 18; i++) { const v = i / 18 * 256; const g = x.createLinearGradient(0, v, 0, v + 14); g.addColorStop(0, 'rgba(0,0,0,0.0)'); g.addColorStop(0.75, 'rgba(0,0,0,0.06)'); g.addColorStop(1, 'rgba(0,0,0,0.18)'); x.fillStyle = g; x.fillRect(0, v, 256, 14.2);
    x.strokeStyle = 'rgba(255,255,255,0.18)'; x.lineWidth = 1; x.beginPath(); x.moveTo(0, v + 7); x.lineTo(256, v + 7); x.stroke();
    x.strokeStyle = 'rgba(0,0,0,0.07)'; for (let b = 0; b < 256; b += 3) { x.beginPath(); x.moveTo(b, v + 7); x.lineTo(b - 5, v + 1); x.stroke(); } }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
function panel(outline, uvK) { // flat polygon (x,z) fan from the first point, with UVs from position
  const pos = [], uv = [], idx = [];
  for (const [x, z] of outline) { pos.push(x, 0, z); uv.push(x * uvK, z * uvK); }
  for (let i = 1; i < outline.length - 1; i++) idx.push(0, i, i + 1);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
  g.computeVertexNormals(); return g;
}
function birdParts() {
  if (BIRD) return BIRD;
  // body: lathe along +x with an elliptical section; head lifted, beak tapered
  const prof = [[-0.078, 0.004], [-0.06, 0.012], [-0.035, 0.022], [-0.005, 0.029], [0.022, 0.028], [0.042, 0.022], [0.054, 0.019], [0.068, 0.02], [0.08, 0.017], [0.089, 0.011], [0.095, 0.006], [0.104, 0.0015]];
  const NS = 22, NL = 44, pos = [], col = [], idx = [];
  const blue = new THREE.Color(0x15264a), rust = new THREE.Color(0x8e3519), cream = new THREE.Color(0xe6cfb0), black = new THREE.Color(0x0c0c0e), c = new THREE.Color();
  const rAt = x => { for (let i = 1; i < prof.length; i++) if (x <= prof[i][0]) { const [x0, r0] = prof[i - 1], [x1, r1] = prof[i]; const t = (x - x0) / (x1 - x0); return r0 + (r1 - r0) * (t * t * (3 - 2 * t)); } return 0.001; };
  for (let i = 0; i <= NL; i++) { const x = prof[0][0] + (prof[prof.length - 1][0] - prof[0][0]) * i / NL, r = rAt(x), lift = sstep(0.035, 0.07, x) * 0.008;
    for (let j = 0; j <= NS; j++) { const a = j / NS * TAU, cy = Math.cos(a), cz = Math.sin(a); const y = cy * r * (cy > 0 ? 0.92 : 1.0) + lift, z = cz * r * 1.06;
      pos.push(x, y, z);
      c.copy(cream);
      if (cy > -0.25) c.copy(blue);
      if (x > 0.056 && cy < 0.35) c.copy(rust);
      if (x > 0.082 && cy > 0.2 && cy < 0.8) c.copy(rust);
      if (x > 0.093) c.copy(black);
      if (x < 0.056 && x > 0.04 && cy < -0.1) c.copy(blue).lerp(black, 0.4); // dark breast band
      col.push(c.r, c.g, c.b); } }
  for (let i = 0; i < NL; i++) for (let j = 0; j < NS; j++) { const a = i * (NS + 1) + j, b = a + NS + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const body = new THREE.BufferGeometry(); body.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); body.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); body.setIndex(idx); body.computeVertexNormals();
  const bodyMat = new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.42, sheen: 0.6, sheenColor: new THREE.Color(0x4466aa), sheenRoughness: 0.35, clearcoat: 0.25, clearcoatRoughness: 0.5 });
  bodyMat.userData.env = 0.6;
  // arm (secondaries) and hand (long pointed primaries) with a scalloped trailing edge
  const arm = panel([[0.02, 0], [0.012, 0.03], [0.0, 0.09], [-0.03, 0.09], [-0.037, 0.075], [-0.031, 0.06], [-0.038, 0.045], [-0.032, 0.03], [-0.039, 0.015], [-0.032, 0]], 9);
  const handPts = [[0, 0], [-0.012, 0.045], [-0.03, 0.095], [-0.052, 0.14], [-0.056, 0.132], [-0.05, 0.11], [-0.054, 0.1], [-0.046, 0.075], [-0.049, 0.065], [-0.04, 0.04], [-0.042, 0.028], [-0.03, 0.002]];
  const hand = panel(handPts, 9);
  const tail = panel([[0, 0.016], [-0.035, 0.022], [-0.115, 0.04], [-0.122, 0.036], [-0.05, 0.01], [-0.045, 0], [-0.05, -0.01], [-0.122, -0.036], [-0.115, -0.04], [-0.035, -0.022], [0, -0.016]], 9);
  const wingMat = new THREE.MeshStandardMaterial({ color: 0xffffff, map: featherTex(), roughness: 0.5, side: THREE.DoubleSide });
  wingMat.onBeforeCompile = sh => { sh.fragmentShader = sh.fragmentShader.replace('#include <map_fragment>', '#include <map_fragment>\n diffuseColor.rgb *= gl_FrontFacing ? vec3(0.36, 0.33, 0.3) : vec3(0.07, 0.1, 0.19);'); };
  wingMat.userData.env = 0.5;
  return BIRD = { body, bodyMat, arm, hand, tail, wingMat };
}

// ---------- quadruped gaits ----------
const ease = w => 0.5 - 0.5 * Math.cos(Math.PI * w);
export const GAITS = [
  { name: 'walk', ph: { HL: 0, FL: 0.25, HR: 0.5, FR: 0.75 }, duty: 0.62, stride: 1.0, sweep: 0.5, fold: 0.5, flex: 0.015, pitch: 0.012, nod: 0.06, lift: 0 },
  { name: 'trot', ph: { HL: 0, FR: 0.0, HR: 0.5, FL: 0.5 }, duty: 0.42, stride: 1.75, sweep: 0.72, fold: 0.8, flex: 0.03, pitch: 0.02, nod: 0.03, lift: 0.025 },
  { name: 'gallop', ph: { HL: 0, HR: 0.08, FL: 0.34, FR: 0.42 }, duty: 0.3, stride: 3.0, sweep: 1, fold: 1, flex: 0.12, pitch: 0.055, nod: 0.04, lift: 0.045, susp: true },
];
function frontPose(p, D, Sw, F) {
  if (p < D) { const s = p / D; return [lerp(0.36, -0.44, s) * Sw, (0.04 - 0.12 * s) * Sw, 0.02, 0.04 * Math.sin(Math.PI * s) * F, 0.42 * Math.sin(Math.PI * s) * F]; }
  const w = (p - D) / (1 - D), fold = Math.sin(Math.PI * Math.min(1, w / 0.78)), reach = sstep(0.35, 0.8, w) * (1 - sstep(0.9, 1.0, w) * 0.5);
  return [(lerp(-0.44, 0.36, ease(w)) + 0.08 * Math.sin(Math.PI * w)) * Sw, (0.42 * fold - 0.08 * reach) * F, (-0.25 * fold + 0.55 * reach) * F, -1.85 * Math.pow(fold, 1.25) * (1 - 0.6 * reach) * F, -0.85 * fold * F];
}
function hindPose(p, D, Sw, F) {
  if (p < D) { const s = p / D; return [lerp(0.34, -0.52, s) * Sw, lerp(0.05, -0.08, s) * Sw, lerp(0.02, -0.32, s) * Sw, 0.42 * Math.sin(Math.PI * s) * F]; }
  const w = (p - D) / (1 - D), b = Math.sin(Math.PI * w), e = ease(w);
  return [(lerp(-0.52, 0.34, e) + 0.05 * b) * Sw, (lerp(-0.08, 0.05, e) * Sw - 0.7 * b * F), (lerp(-0.32, 0.02, e) * Sw + 1.25 * b * F), -0.9 * b * F];
}
const _pose = {};
function quadPose(G, t, canine) {
  const o = {};
  for (const S of ['L', 'R']) {
    const f = frontPose(((t - G.ph['F' + S]) % 1 + 1) % 1, G.duty, G.sweep, G.fold * (canine ? 0.85 : 1));
    o['scap' + S] = f[0]; o['hum' + S] = f[1]; o['rad' + S] = f[2]; o['canF' + S] = f[3]; o['pasF' + S] = f[4] * (canine ? 0.5 : 1);
    const h = hindPose(((t - G.ph['H' + S]) % 1 + 1) % 1, G.duty, G.sweep, G.fold);
    o['fem' + S] = h[0]; o['tib' + S] = h[1]; o['canH' + S] = h[2]; o['pasH' + S] = h[3] * (canine ? 0.5 : 1);
  }
  const flex = G.flex * Math.cos(TAU * (t - 0.3));
  o.chest = flex * 0.55; o.hips = -flex * 0.55; o.pitch = G.pitch * Math.cos(TAU * (t - 0.2));
  o.nod = G.nod * Math.cos(TAU * 2 * t);
  o.lift = G.susp ? (t > 0.7 ? Math.sin(Math.PI * (t - 0.7) / 0.3) * G.lift : 0) : Math.max(0, Math.sin(TAU * 2 * t)) * G.lift;
  return o;
}
const LEAP = { scapL: 0.55, scapR: 0.5, humL: 0.4, humR: 0.42, radL: -0.25, radR: -0.2, canFL: -1.75, canFR: -1.65, pasFL: -0.8, pasFR: -0.8, femL: -0.62, femR: -0.6, tibL: 0.0, tibR: 0.02, canHL: -0.3, canHR: -0.28, pasHL: 0.1, pasHR: 0.1, chest: 0.06, hips: -0.06, pitch: 0 };


// ================= combat, stats, actions =================
export const BASE_HP = { athlete: 125, buck: 130, wbuck: 120, doe: 90, fawn: 50, elk: 220, cow: 170, horse: 240, wolf: 115, fox: 60, rabbit: 26, hiker: 100, bird: 14 };
const M = (id, label, o) => ({ id, label, cd: 1, sta: 10, dur: 0.6, hitAt: 0.45, range: 1.4, arc: 1.0, dmg: 10, kb: 4, ...o });
const DEER_BUCK = [M('charge', 'Antler charge', { cd: 1.4, sta: 22, dur: 0.75, hitAt: 0.5, range: 1.7, dmg: 30, kb: 8, lunge: 7.5 }), M('kick', 'Rear kick', { cd: 1.1, sta: 14, dur: 0.55, hitAt: 0.42, range: 1.7, arc: 1.2, dmg: 22, kb: 7, back: true }), M('snort', 'Snort', { cd: 5, sta: 4, dur: 0.9, hitAt: 0.4, scare: 14, dmg: 0 })];
const DEER_DOE = [M('butt', 'Headbutt', { cd: 1.1, sta: 14, dur: 0.6, hitAt: 0.5, range: 1.4, dmg: 14, kb: 5, lunge: 5 }), M('kick', 'Rear kick', { cd: 1.1, sta: 14, dur: 0.55, hitAt: 0.42, range: 1.6, arc: 1.2, dmg: 18, kb: 6, back: true }), M('snort', 'Snort', { cd: 5, sta: 4, dur: 0.9, scare: 12, dmg: 0 })];
export const MOVES = {
  buck: DEER_BUCK, wbuck: DEER_BUCK, doe: DEER_DOE, fawn: DEER_DOE,
  elk: [M('charge', 'Antler charge', { cd: 1.6, sta: 24, dur: 0.85, hitAt: 0.55, range: 2.3, dmg: 42, kb: 10, lunge: 7 }), M('kick', 'Rear kick', { cd: 1.3, sta: 16, dur: 0.6, hitAt: 0.45, range: 2.2, arc: 1.2, dmg: 28, kb: 8, back: true }), M('bugle', 'Bugle', { cd: 6, sta: 5, dur: 1.4, hitAt: 0.3, scare: 22, dmg: 0 })],
  cow: [M('butt', 'Headbutt', { cd: 1.2, sta: 14, dur: 0.65, range: 2, dmg: 20, kb: 7, lunge: 5 }), M('kick', 'Rear kick', { cd: 1.3, sta: 16, dur: 0.6, range: 2.1, arc: 1.2, dmg: 24, kb: 8, back: true }), M('bugle', 'Call', { cd: 6, sta: 5, dur: 1.2, scare: 14, dmg: 0 })],
  horse: [M('buck', 'Buck kick', { cd: 1.3, sta: 18, dur: 0.7, hitAt: 0.45, range: 2.4, arc: 1.3, dmg: 38, kb: 11, back: true }), M('rear', 'Rear up', { cd: 2, sta: 20, dur: 1.1, hitAt: 0.72, range: 2.1, dmg: 32, kb: 9 }), M('whinny', 'Whinny', { cd: 5, sta: 4, dur: 1.0, scare: 16, dmg: 0 })],
  wolf: [M('bite', 'Bite', { cd: 0.7, sta: 9, dur: 0.42, hitAt: 0.55, range: 1.35, dmg: 18, kb: 3, lunge: 4 }), M('pounce', 'Pounce', { cd: 2.2, sta: 22, dur: 0.9, hitAt: 0.75, range: 1.7, dmg: 32, kb: 8, lunge: 9, jump: 4.6 }), M('howl', 'Howl', { cd: 8, sta: 6, dur: 2.0, hitAt: 0.3, rally: 40, dmg: 0 })],
  fox: [M('bite', 'Bite', { cd: 0.6, sta: 8, dur: 0.38, hitAt: 0.55, range: 0.95, dmg: 10, kb: 2, lunge: 3 }), M('pounce', 'Pounce', { cd: 1.8, sta: 16, dur: 0.8, hitAt: 0.75, range: 1.2, dmg: 18, kb: 4, lunge: 7, jump: 4.2 }), M('yip', 'Yip', { cd: 4, sta: 3, dur: 0.6, scare: 8, dmg: 0 })],
  rabbit: [M('kick', 'Hind kick', { cd: 0.8, sta: 8, dur: 0.4, range: 0.6, dmg: 5, kb: 2, back: true }), M('dash', 'Dash', { cd: 2.5, sta: 18, dur: 0.6, hitAt: 2, lunge: 14, dmg: 0 }), M('thump', 'Thump', { cd: 4, sta: 3, dur: 0.6, scare: 6, dmg: 0 })],
  hiker: [M('punch', 'Punch', { cd: 0.45, sta: 7, dur: 0.38, hitAt: 0.45, range: 1.1, arc: 0.9, dmg: 11, kb: 4, lunge: 2 }), M('lowkick', 'Low kick', { cd: 0.9, sta: 12, dur: 0.55, hitAt: 0.5, range: 1.25, arc: 0.9, dmg: 16, kb: 6 }), M('pole', 'Pole jab', { cd: 1.1, sta: 12, dur: 0.6, hitAt: 0.5, range: 2.1, arc: 0.6, dmg: 20, kb: 7, lunge: 3 })],
  athlete: [M('punch', 'Jab-cross', { cd: 0.42, sta: 6, dur: 0.4, hitAt: 0.45, range: 1.15, arc: 0.9, dmg: 13, kb: 4.5, lunge: 2.4 }), M('lowkick', 'Low kick', { cd: 0.85, sta: 11, dur: 0.52, hitAt: 0.5, range: 1.3, arc: 0.9, dmg: 18, kb: 6.5 }), M('knee', 'Flying knee', { cd: 1.6, sta: 18, dur: 0.7, hitAt: 0.55, range: 1.25, arc: 0.8, dmg: 26, kb: 8, lunge: 6.5, jump: 3.3 })],
  bird: [M('peck', 'Dive peck', { cd: 1.5, sta: 10, dur: 0.6, range: 1.2, dmg: 3, kb: 1 }), M('peck', 'Dive peck', { cd: 1.5, sta: 10, dur: 0.6, range: 1.2, dmg: 3, kb: 1 }), M('peck', 'Dive peck', { cd: 1.5, sta: 10, dur: 0.6, range: 1.2, dmg: 3, kb: 1 })],
};
Creature.prototype.initStats = function () {
  this.maxHp = Math.round(BASE_HP[this.type] * (0.9 + 0.2 * this.size / (this.spec.size || 1)));
  this.hp = this.maxHp; this.sta = 100; this.hunger = 100; this.ko = false; this.koT = 0;
  this.kv = new THREE.Vector3(); this.cds = [0, 0, 0]; this.flinch = 0; this.act = null; this.lastHit = -99;
};
Creature.prototype.startAction = function (i, isPlayer, override) {
  const m = override || MOVES[this.type]?.[i];
  if (!m || this.ko || this.act || this.cds[i] > 0) return null;
  if (isPlayer && this.sta < m.sta * 0.5) return null;
  this.sta = Math.max(0, this.sta - m.sta); this.cds[i] = m.cd; this.act = { m, t: 0, hit: false };
  if (m.jump && this.air === 0) { this.vy = m.jump; this.air = 0.001; }
  return m;
};
const _f = new THREE.Vector3();
Creature.prototype.tickCombat = function (dt, onHit) {
  for (let i = 0; i < 3; i++) this.cds[i] = Math.max(0, this.cds[i] - dt);
  this.flinch = Math.max(0, this.flinch - dt * 4);
  if (this.kv.lengthSq() > 0.001) { this.pos.addScaledVector(this.kv, dt); this.kv.multiplyScalar(Math.exp(-6 * dt)); }
  const a = this.act; if (!a) return;
  a.t += dt; const u = a.t / a.m.dur;
  if (a.m.lunge && u > 0.18 && u < 0.62) this.pos.addScaledVector(this.forward(_f), a.m.lunge * dt * Math.sqrt(this.size * this.S));
  if (!a.hit && u >= a.m.hitAt) { a.hit = true; onHit(this, a.m); }
  if (u >= 1) this.act = null;
};
const bump = (u, a = 0.2, b = 0.5, c = 1) => sstep(0, a, u) * (1 - sstep(b, c, u));
// additive bone offsets on top of locomotion
Creature.prototype.overlay = function (dt, time) {
  const B = this.b, a = this.act, k = this.spec.kind, f = this.flinch;
  let any = false;
  if (f > 0) { any = true; if (B.chest) B.chest.rotation.x += 0.18 * f * Math.sin(time * 40); if (B.neck1) B.neck1.rotation.z += 0.25 * f; else if (B.neck) B.neck.rotation.z -= 0.3 * f; }
  if (!a) return any;
  const u = clamp(a.t / a.m.dur, 0, 1), id = a.m.id, w = bump(u, 0.25, 0.6, 1);
  const L = ['L', 'R'];
  switch (id) {
    case 'charge': case 'butt': B.neck1.rotation.z -= 0.75 * w; B.head.rotation.z += 0.6 * w; B.root.rotation.z -= 0.12 * w; break;
    case 'kick': if (k === 'rabbit') { for (const s of L) { B['fem' + s].rotation.z -= 1.0 * w; B['canH' + s].rotation.z -= 0.6 * w; } break; }
      B.root.rotation.z -= 0.22 * w; for (const s of L) { B['fem' + s].rotation.z -= 1.05 * w; B['tib' + s].rotation.z += 0.35 * w; B['canH' + s].rotation.z -= 0.55 * w; } break;
    case 'buck': B.root.rotation.z -= 0.32 * w; B.neck1.rotation.z -= 0.5 * w; for (const s of L) { B['fem' + s].rotation.z -= 1.15 * w; B['tib' + s].rotation.z += 0.4 * w; B['canH' + s].rotation.z -= 0.6 * w; } break;
    case 'rear': { const r = bump(u, 0.35, 0.65, 0.85); B.root.rotation.z += 0.85 * r; B.neck1.rotation.z += 0.3 * r; for (const s of L) { B['hum' + s].rotation.z += 0.7 * r; B['canF' + s].rotation.z -= 1.3 * r; B['fem' + s].rotation.z -= 0.55 * r; B['canH' + s].rotation.z += 0.35 * r; } break; }
    case 'snort': case 'whinny': case 'yip': case 'thump': B.neck1 && (B.neck1.rotation.z += 0.35 * w); B.head && (B.head.rotation.z -= 0.3 * w * Math.abs(Math.sin(u * 18))); break;
    case 'bugle': B.neck1.rotation.z += 0.75 * w; B.head.rotation.z -= 0.75 * w; break;
    case 'howl': { const h = bump(u, 0.15, 0.8, 1); B.neck1.rotation.z += 0.95 * h; B.neck2.rotation.z += 0.3 * h; B.head.rotation.z += 0.25 * h; for (const s of L) { B['fem' + s].rotation.z += 0.6 * h; B['tib' + s].rotation.z -= 0.9 * h; B['canH' + s].rotation.z += 1.0 * h; } B.root.rotation.z += 0.25 * h; break; }
    case 'bite': B.neck1.rotation.z -= 0.25 * w; B.head.rotation.z -= 0.35 * w; break;
    case 'pounce': { const r = bump(u, 0.15, 0.75, 1); for (const s of L) { B['scap' + s].rotation.z += 0.6 * r; B['rad' + s].rotation.z += 0.5 * r; B['canF' + s].rotation.z -= 0.2 * r; B['fem' + s].rotation.z -= 0.6 * r; } B.neck1.rotation.z += 0.15 * r; break; }
    case 'dash': break;
    case 'punch': { const p = bump(u, 0.35, 0.55, 1); B.armR.rotation.z += 1.45 * p; B.armR.rotation.x -= 0.25 * p; B.foreR.rotation.z = lerp(B.foreR.rotation.z, 0.1, p); B.chest.rotation.y -= 0.45 * p; B.armL.rotation.z += 0.6 * w; B.foreL.rotation.z = lerp(B.foreL.rotation.z, 1.9, w); break; }
    case 'lowkick': { const p = bump(u, 0.35, 0.6, 1); B.thighR.rotation.z += 1.2 * p; B.shinR.rotation.z = lerp(B.shinR.rotation.z, -0.05, p); B.spine.rotation.z -= 0.25 * p; B.armL.rotation.z += 0.5 * w; B.armR.rotation.z -= 0.3 * w; break; }
    case 'pole': { const p = bump(u, 0.35, 0.6, 1); for (const s of L) { B['arm' + s].rotation.z += 1.1 * p; B['arm' + s].rotation.x += (s === 'L' ? 0.35 : -0.35) * p; B['fore' + s].rotation.z = lerp(B['fore' + s].rotation.z, 0.35, p); } B.chest.rotation.y += 0.2 * p; break; }
  }
  if (this.pole) this.pole.visible = true;
  return true;
};
Creature.prototype.knockOut = function () {
  if (this.ko) return; this.ko = true; this.koT = 0; this.act = null; this.speed = 0; this.wantSpeed = 0; this.state = 'down'; this.koSide = rnd() < 0.5 ? 1 : -1;
};
Creature.prototype.revive = function () { this.ko = false; this.hp = this.maxHp; this.sta = 100; this.rig.rotation.set(0, 0, 0); this.rig.position.set(0, 0, 0); this.state = 'idle'; };
Creature.prototype.koPose = function (dt) {
  this.koT += dt; const u = sstep(0, 0.7, this.koT), B = this.b, k = this.spec.kind;
  if (k === 'bird') return;
  if (k === 'human') { const a = 1.5 * u; this.rig.rotation.set(0, 0, a); this.rig.position.set(-Math.sin(a) * 0.9 * this.size + 0.0, 0.12 * u * this.size - (1 - Math.cos(a)) * 0.0, 0); for (const s of ['L', 'R']) { B['thigh' + s].rotation.z = 0.2 * u; B['shin' + s].rotation.z = -0.4 * u; B['arm' + s].rotation.z = 0.9 * u; } return; }
  const a = 1.42 * u * this.koSide, Y = this.rootY * this.size, h = (k === 'rabbit' ? 0.07 : k === 'canine' ? 0.12 : 0.19) * this.S * this.size;
  this.rig.rotation.set(a, 0, 0); this.rig.position.set(0, h * u + (Y - h) * (1 - u) - Y * Math.cos(a) * (1 - u) * 0 - (Y * Math.cos(a) - Y) * 0, 0);
  this.rig.position.set(0, lerp(0, h - Y * Math.cos(a), u), -Y * Math.sin(a) * u);
  for (const s of ['L', 'R']) for (const j of ['scap', 'hum', 'rad', 'canF', 'fem', 'tib', 'canH']) if (B[j + s]) B[j + s].rotation.z = lerp(B[j + s].rotation.z, (j === 'canF' ? -0.5 : j === 'canH' ? 0.4 : j === 'rad' ? 0.2 : 0.1), u * 0.2);
  if (B.neck1) B.neck1.rotation.z = lerp(B.neck1.rotation.z, -0.5, 0.05);
};

export const SPEAR_MOVE = M('pole', 'Spear thrust', { cd: 1.0, sta: 12, dur: 0.6, hitAt: 0.5, range: 2.4, arc: 0.55, dmg: 34, kb: 8, lunge: 3 });
// extra overlay pose for the flying knee
const _ov = Creature.prototype.overlay;
Creature.prototype.overlay = function (dt, time) {
  const r = _ov.call(this, dt, time), a = this.act;
  if (a && a.m.id === 'knee') { const B = this.b, u = clamp(a.t / a.m.dur, 0, 1), w = sstep(0.15, 0.45, u) * (1 - sstep(0.7, 1, u));
    B.thighR.rotation.z += 1.55 * w; B.shinR.rotation.z = lerp(B.shinR.rotation.z, -1.9, w); B.thighL.rotation.z -= 0.35 * w; B.shinL.rotation.z -= 0.6 * w;
    B.armL.rotation.z -= 0.6 * w; B.armR.rotation.z -= 0.5 * w; B.spine.rotation.z += 0.2 * w; return true; }
  return r;
};
const CFG_EARRINGS = false; // the v0.7 hiking design has none
// locs (half-up with a top knot, the rest hanging and swaying), camera
Creature.prototype.addHairShells = function (part, D) {
  const g0 = part.geometry, n = g0.attributes.position.count, L = D.lods.findIndex(l => l.part), raw = decodeSpecies(this.spec.mesh).lods[L];
  const fur = new Float32Array(n * 2), LEN = { hair: 0.009, beard: 0.0055, brow: 0.0018 };
  let any = false;
  for (let i = 0; i < n; i++) { const sA = D.slots[raw.SL[i * 3]], sB = D.slots[raw.SL[i * 3 + 1]], mix = raw.SL[i * 3 + 2] / 255;
    const la = LEN[sA] || 0, lb = LEN[sB] || 0, l = la * (1 - mix) + lb * mix; if (l > 0.001) { fur[i * 2] = 1; fur[i * 2 + 1] = l; any = true; } }
  if (!any) return;
  // shells only need the hair/beard triangles: share the head's vertex buffers, keep a smaller index
  const I = g0.index.array, keep = []; for (let t = 0; t < I.length; t += 3) if (fur[I[t] * 2] + fur[I[t + 1] * 2] + fur[I[t + 2] * 2] > 0) keep.push(I[t], I[t + 1], I[t + 2]);
  const g = new THREE.BufferGeometry(); for (const [k, v] of Object.entries(g0.attributes)) g.setAttribute(k, v); g.setAttribute('aFur', new THREE.BufferAttribute(fur, 2));
  g.setIndex(new THREE.BufferAttribute(n > 65535 ? new Uint32Array(keep) : new Uint16Array(keep), 1));
  const N = matchMedia('(pointer: coarse)').matches ? 3 : 5;
  this.hairShells = [];
  for (let i = 0; i < N; i++) { const sm = new THREE.SkinnedMesh(g, hairShellMat(i, N)); sm.boundingSphere = part.boundingSphere; sm.frustumCulled = true; sm.castShadow = false; this.rig.add(sm); sm.bind(this.skel, this.meshes[0].bindMatrix); this.hairShells.push(sm); }
};
Creature.prototype.addAthleteGear = function (A) {
  const head = this.b.head, H = this.rest.head, rel = (x, y, z) => new THREE.Vector3(x - H[0], y - H[1], z - H[2]);
  const locMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 });
  const base = new THREE.Color(0x1f140d), tip = new THREE.Color(0x6e4626);
  function tubes(paths, r0) {
    const pos = [], col = [], idx = []; let off = 0;
    for (const pts of paths) {
      const curve = new THREE.CatmullRomCurve3(pts), seg = 18, RS = 5, g = new THREE.TubeGeometry(curve, seg, 1, RS, false), P = g.attributes.position, c = new THREE.Vector3(), v = new THREE.Vector3(), cc = new THREE.Color();
      for (let i = 0; i <= seg; i++) { const u = i / seg; curve.getPointAt(u, c); const rr = r0 * (1 - 0.25 * u); for (let j = 0; j <= RS; j++) { const k = i * (RS + 1) + j; v.fromBufferAttribute(P, k).sub(c).multiplyScalar(rr).add(c); pos.push(v.x, v.y, v.z); cc.copy(base).lerp(tip, Math.pow(u, 2.2) * (pts.tipK ?? 1)); col.push(cc.r, cc.g, cc.b); } }
      for (const k of g.index.array) idx.push(k + off); off += (seg + 1) * (RS + 1);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
  }
  const tie = rel(-0.075, 1.735, 0);
  // scalp locs: from hairline over the crown to the tie
  const scalp = [];
  for (let i = 0; i < 16; i++) { const a = (i / 15 - 0.5) * 2.4, cz = Math.sin(a) * 0.088, cx = 0.075 * Math.cos(a) - 0.005, cy = 1.745 + 0.02 * Math.cos(a);
    const p0 = rel(cx, cy - 0.01, cz), p1 = rel(0.03, 1.79, cz * 0.7), p2 = rel(-0.05, 1.77, cz * 0.35); scalp.push([p0, p1, p2, tie.clone().add(new THREE.Vector3(0, 0, cz * 0.12))]); scalp[i].tipK = 0.1; }
  const sm = new THREE.Group(); head.add(sm); // the curly top is sculpted + fur-shelled now; only the tied-back locs stay as tubes
  // half-up: the top section is twisted into a knot on the crown; the rest hangs loose to the shoulders on a swaying pivot
  const knotC = rel(-0.03, 1.818, 0), knot = new THREE.Group(); knot.position.copy(knotC); head.add(knot);
  { const coils = [];
    for (let k = 0; k < 10; k++) { const a0 = k * 0.75, rr = 0.024 + (k % 3) * 0.006, h = (k - 3) * 0.006, pts = [];
      for (let t = 0; t <= 10; t++) { const a = a0 + t / 10 * Math.PI * 1.7; pts.push(new THREE.Vector3(Math.cos(a) * rr, h + 0.012 * Math.sin(t / 10 * Math.PI), Math.sin(a) * rr)); }
      coils.push(pts); }
    for (let k = 0; k < 5; k++) { const a = k * 1.3, pts = [new THREE.Vector3(Math.cos(a) * 0.02, 0.01, Math.sin(a) * 0.02), new THREE.Vector3(Math.cos(a) * 0.032, 0.022, Math.sin(a) * 0.032), new THREE.Vector3(Math.cos(a) * 0.045 - 0.006, 0.018 + rnd() * 0.01, Math.sin(a) * 0.045)]; coils.push(pts); } // loose ends out of the knot
    knot.add(new THREE.Mesh(tubes(coils, 0.0105), locMat)); }
  // locs from the hairline sweeping up into the knot
  { const up = [];
    for (let i = 0; i < 14; i++) { const a = (i / 13 - 0.5) * 2.6, cz = Math.sin(a) * 0.086, cx = 0.07 * Math.cos(a) - 0.01;
      up.push([rel(cx, 1.752, cz), rel(cx * 0.6 - 0.005, 1.8, cz * 0.75), rel(-0.03 + cx * 0.15, 1.818, cz * 0.25)]); }
    sm.add(new THREE.Mesh(tubes(up, 0.0085), locMat)); }
  const pony = new THREE.Group(); pony.position.copy(rel(-0.06, 1.725, 0)); head.add(pony);
  const hang = [];
  for (let i = 0; i < 22; i++) { const a = (i / 21 - 0.5) * 3.3, side = Math.sin(a), back = Math.cos(a); // across the back and both sides
    const len = 0.2 + rnd() * 0.08 - Math.abs(side) * 0.04, out = 0.012 + rnd() * 0.02;
    const o = new THREE.Vector3(-back * 0.088 + 0.06 - Math.abs(side) * 0.015, -0.01 + Math.abs(side) * 0.012, side * 0.09);
    hang.push([o, o.clone().add(new THREE.Vector3(-back * out - 0.01, -0.06, side * out)), o.clone().add(new THREE.Vector3(-back * (out + 0.025) - 0.03, -len * 0.6, side * (out + 0.03))), o.clone().add(new THREE.Vector3(-back * (out + 0.035) - 0.035 + (rnd() - 0.5) * 0.02, -len, side * (out + 0.04) + (rnd() - 0.5) * 0.02))]); }
  pony.add(new THREE.Mesh(tubes(hang, 0.0098), locMat));
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.028, 0.006, 6, 14), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.6 })); band.position.y = -0.004; knot.add(band);
  this.pony = pony;
  // gold earrings
  const gold = new THREE.MeshStandardMaterial({ color: 0xd8a640, metalness: 1, roughness: 0.28 }); gold.userData.env = 1.2;
  if (CFG_EARRINGS) for (const s of [1, -1]) { const e = new THREE.Group(); const stud = new THREE.Mesh(new THREE.SphereGeometry(0.011, 10, 8), gold); const drop = new THREE.Mesh(new THREE.SphereGeometry(0.013, 10, 8), gold); drop.position.y = -0.018; drop.scale.set(0.8, 1.2, 0.8); e.add(stud, drop); e.position.copy(rel(0.024, 1.652, 0.094 * s)); head.add(e); }
  // hands: fingers and thumb (relaxed curl) so the hands read up close; same skin shading as the body
  { const skin = new THREE.Color(0x8c5838), parts = [];
    const cap = (r, len, x, y, z, rx, rz) => { const g = new THREE.CapsuleGeometry(r, len, 4, 10); g.rotateZ(rz); g.rotateX(rx); g.translate(x, y, z); parts.push(g); };
    for (const s of [1, -1]) {
      const hr = this.rest['hand' + (s > 0 ? 'L' : 'R')], z0 = 0.24 * s, base = parts.length;
      // index .. pinky along x (front to back); tips curl slightly toward the palm (inward, -z*s) and forward
      [[0.018, 0.034, 0.0072], [0.006, 0.038, 0.0075], [-0.006, 0.036, 0.0072], [-0.017, 0.029, 0.0064]].forEach(([fx, L, r]) => {
        cap(r, L * 0.55, fx, 0.795 - L * 0.28, z0 - 0.004 * s, -0.12 * s, -0.12); cap(r * 0.9, L * 0.35, fx + 0.006, 0.795 - L * 0.78, z0 - 0.01 * s, -0.35 * s, -0.25); });
      cap(0.0085, 0.022, 0.027, 0.818, z0 - 0.008 * s, -0.35 * s, 0.55); // thumb
      const g = mergeGeos(parts.splice(base)); g.translate(-hr[0], -hr[1], -hr[2]);
      const n = g.attributes.position.count, col = new Float32Array(n * 3); for (let i = 0; i < n; i++) { col[i * 3] = skin.r; col[i * 3 + 1] = skin.g; col[i * 3 + 2] = skin.b; }
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      const m = new THREE.Mesh(g, this.meshes[0].material); m.castShadow = true; this.b['hand' + (s > 0 ? 'L' : 'R')].add(m);
    } }
  // chest "A" logo
  const lg = new THREE.Group(), lm = new THREE.MeshStandardMaterial({ color: 0x6c6c6e, roughness: 0.6 });
  for (const s of [1, -1]) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.003, 0.034, 0.005), lm); b.rotation.x = 0.38 * s; b.position.z = 0.0065 * s; lg.add(b); }
  // (no chest logo: the vest covers the shirt)
  // camera for the Photo action
  const cam = new THREE.Group(), cm = new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.12), cm), lens = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.03, 0.07, 16).rotateZ(Math.PI / 2), cm); lens.position.x = 0.07; cam.add(body, lens);
  const hr = this.rest.handR; cam.position.set(0.035 - hr[0], 0.83 - hr[1], -0.21 - hr[2]); this.b.handR.add(cam); this.camProp = cam;
  for (const o of [...sm.children, ...knot.children, ...pony.children]) { o.castShadow = true; }
  this.onAnim = (dt, time) => { const sp = this.speed, f = this.flinch || 0; this.ponyT = (this.ponyT || 0) + dt * (2 + sp * 1.5);
    pony.rotation.z = 0.08 * sp / 3 + 0.05 * Math.sin(this.ponyT * 2.2) * Math.min(1, sp / 2 + 0.2) + 0.2 * f;
    pony.rotation.x = 0.06 * Math.sin(this.ponyT * 1.7) * Math.min(1, sp / 2 + 0.2); };
};

// ================= riding: saddle tack on the horse, seated rider with legs in the stirrups =================
// the horse's body around its centre line, measured from the sculpt: radius per angle at a given x (rig units)
const BARREL = {};
function barrelAt(mesh, x0) {
  const key = mesh + '|' + x0.toFixed(3); if (BARREL[key]) return BARREL[key];
  const P = decodeSpecies(mesh).lods[0].pos; let top = -1e9, bot = 1e9;
  for (let i = 0; i < P.length; i += 3) if (Math.abs(P[i] - x0) < 0.03 && Math.abs(P[i + 2]) < 0.05) { top = Math.max(top, P[i + 1]); bot = Math.min(bot, P[i + 1]); }
  const cy = (top + bot) / 2, NB = 48, R = new Float32Array(NB);
  for (let i = 0; i < P.length; i += 3) { if (Math.abs(P[i] - x0) > 0.03) continue; const dy = P[i + 1] - cy, dz = P[i + 2];
    const b = Math.round((Math.atan2(dy, dz) + Math.PI) / TAU * NB) % NB; R[b] = Math.max(R[b], Math.hypot(dy, dz)); }
  for (let k = 0; k < 3; k++) for (let b = 0; b < NB; b++) if (!R[b]) R[b] = Math.max(R[(b + 1) % NB], R[(b + NB - 1) % NB]);
  const r = phi => { const f = ((phi + Math.PI) / TAU * NB + NB) % NB, b0 = Math.floor(f) % NB, b1 = (b0 + 1) % NB, t = f - Math.floor(f); return R[b0] * (1 - t) + R[b1] * t; };
  return BARREL[key] = { top, bot, cy, r, half: r(0) };
}
function shellGeo(mesh, x0, x1, nx, ph0, ph1, nph, off, col) { // a sheet that hugs the barrel (blanket, saddle)
  const pos = [], cols = [], idx = [], c = new THREE.Color();
  for (let i = 0; i <= nx; i++) { const u = i / nx, x = lerp(x0, x1, u), B = barrelAt(mesh, x);
    for (let j = 0; j <= nph; j++) { const v = j / nph, ph = lerp(ph0, ph1, v), rr = B.r(ph) + off(u, v); pos.push(x, B.cy + Math.sin(ph) * rr, Math.cos(ph) * rr); col(c, u, v); cols.push(c.r, c.g, c.b); } }
  for (let i = 0; i < nx; i++) for (let j = 0; j < nph; j++) { const a = i * (nph + 1) + j, b = a + nph + 1; idx.push(a, a + 1, b, b, a + 1, b + 1); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
const TACK_X = 0.2; // saddle centre (rig units): just behind the withers
const leatherMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5, metalness: 0, side: THREE.DoubleSide }); leatherMat.userData.env = 0.6;
const woolMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, side: THREE.DoubleSide });
const ironMat = new THREE.MeshStandardMaterial({ color: 0x3a3632, roughness: 0.35, metalness: 0.8 }); ironMat.userData.env = 1;
const reinMat = new THREE.LineBasicMaterial({ color: 0x2a1a10 });
Creature.prototype.addTack = function () {
  if (this.tack) return this.tack;
  const m = this.spec.mesh, S = this.S, root = this.b.root, rY = this.rest.root[1], g = new THREE.Group();
  const B0 = barrelAt(m, TACK_X), top = B0.top, half = B0.half;
  const blanket = shellGeo(m, TACK_X - 0.36, TACK_X + 0.3, 10, Math.PI / 2 - 1.0, Math.PI / 2 + 1.0, 28, (u, v) => 0.012 + 0.004 * Math.sin(v * 40), (c, u, v) => {
    const e = Math.min(u, 1 - u, v, 1 - v); c.setHex(0x5e1f16); if (e < 0.035) c.setHex(0x2a1712); else if (e < 0.07) c.setHex(0xa8946c); else if (e < 0.1) c.setHex(0x1c2438); else if (Math.abs(v - 0.5) > 0.3 && Math.abs(v - 0.5) < 0.33) c.setHex(0x1c2438); c.multiplyScalar(0.8 + 0.12 * Math.sin(u * 70) * Math.sin(v * 60)); });
  const seat = shellGeo(m, TACK_X - 0.24, TACK_X + 0.2, 14, Math.PI / 2 - 0.78, Math.PI / 2 + 0.78, 24, (u, v) => { const t = Math.sin(v * Math.PI); return 0.03 + t * (0.11 * Math.pow(Math.max(0, 1 - u * 1.6), 3) + 0.08 * Math.pow(Math.max(0, u * 1.5 - 0.62), 2.2) * 2.5) + t * 0.018; },
    (c, u, v) => { c.setHex(0x5b3820); const e = Math.min(u, 1 - u, v, 1 - v); if (e < 0.05) c.setHex(0x3a2212); c.multiplyScalar(0.9 + 0.1 * Math.sin(u * 30 + v * 7)); });
  const meshB = new THREE.Mesh(blanket, woolMat), meshS = new THREE.Mesh(seat, leatherMat);
  g.add(meshB, meshS);
  // horn on the pommel
  const horn = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.03, 0.08, 10), leatherMat.clone()); horn.material.vertexColors = false; horn.material.color.setHex(0x4a2c18);
  const B1 = barrelAt(m, TACK_X + 0.17); horn.position.set(TACK_X + 0.17, B1.top + 0.13, 0); g.add(horn);
  // stirrup leathers + irons
  const stirY = top - 0.5 * S / 1.55, stirX = TACK_X + 0.02, Bs = barrelAt(m, stirX), sideZ = ph => Math.cos(ph) * (Bs.r(ph) + 0.035);
  const marks = {};
  for (const s of [1, -1]) {
    const ph = Math.PI / 2 - 0.86 * s, zTop = sideZ(ph), yTop = Bs.cy + Math.sin(ph) * (Bs.r(ph) + 0.035), zBot = s * (Math.max(half, Math.abs(zTop)) + 0.06);
    const len = Math.hypot(yTop - stirY, zTop - zBot), strap = new THREE.Mesh(new THREE.BoxGeometry(0.04, len, 0.006), ironMat.clone()); strap.material.color.setHex(0x4a2c18); strap.material.metalness = 0; strap.material.roughness = 0.6;
    strap.position.set(stirX, (yTop + stirY) / 2, (zTop + zBot) / 2); strap.rotation.x = Math.atan2(zTop - zBot, yTop - stirY) * -1; g.add(strap);
    const iron = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.008, 6, 16), ironMat); iron.position.set(stirX, stirY - 0.03, zBot); iron.rotation.y = Math.PI / 2; iron.scale.set(1, 0.85, 1); g.add(iron);
    const mk = new THREE.Object3D(); mk.position.set(stirX - 0.03, stirY + 0.035, zBot); marks[s > 0 ? 'L' : 'R'] = mk; g.add(mk);
  }
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  g.position.set(0, -rY, 0); root.add(g); g.visible = false;
  // the seat point (rider's pelvis) and the bit (rein ends) ride on the skeleton
  const seatM = new THREE.Object3D(); seatM.position.set(TACK_X - 0.01, B0.top + 0.035 + 0.15, 0); g.add(seatM);
  const H = this.rest.head, A = this.D.attach, bit = new THREE.Group(); bit.position.set(A.nose[0] - 0.16 * S / 1.55 - H[0], A.nose[1] - 0.06 * S / 1.55 - H[1], -H[2]); this.b.head.add(bit);
  const bitL = new THREE.Object3D(), bitR = new THREE.Object3D(); bitL.position.z = 0.055 * S / 1.55; bitR.position.z = -0.055 * S / 1.55; bit.add(bitL, bitR);
  return this.tack = { g, seat: seatM, stirL: marks.L, stirR: marks.R, bitL, bitR, reins: null };
};
Creature.prototype.showTack = function (on) { this.addTack().g.visible = on; };
const _sp = new THREE.Vector3(), _sq = new THREE.Quaternion(), _so = new THREE.Vector3(), _t = new THREE.Vector3(), _k = new THREE.Vector3(), _u = new THREE.Vector3(), _w = new THREE.Vector3();
const _bx = new THREE.Vector3(), _by = new THREE.Vector3(), _bz = new THREE.Vector3(), _bm = new THREE.Matrix4(), _q1 = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _pole = new THREE.Vector3();
// sit this person in horse h's saddle. w: 0..1 vault-in progress (from this._rideFrom)
Creature.prototype.seatOn = function (h, dt, time, w = 1) {
  const T = h.addTack(), B = this.b, v = h.speed;
  this._rg = this._rg || [1, 0, 0]; const tw = [1 - sstep(0.6, 2.6, v), sstep(1.6, 3.6, v) * (1 - sstep(6, 8.5, v)), sstep(6, 8.5, v)];
  for (let i = 0; i < 3; i++) this._rg[i] = lerp(this._rg[i], tw[i], 1 - Math.exp(-5 * dt)); const [walkW, trotW, galW] = this._rg;
  h.group.updateMatrixWorld(true);
  T.seat.getWorldPosition(_sp); T.seat.getWorldQuaternion(_sq);
  // trot: posting rise twice a stride; gallop: half seat, out of the saddle
  const ph = h.phase * TAU, post = Math.max(0, Math.sin(ph * 2)) * 0.045 * trotW, half = 0.045 * galW + 0.012 * Math.sin(ph * 2 + 0.8) * galW;
  _so.set(0, this.rootY * this.size, 0).applyQuaternion(_sq); _sp.sub(_so); _sp.addScaledVector(_w.set(0, 1, 0).applyQuaternion(_sq), post + half);
  if (w < 1 && this._rideFrom) { const e = w * w * (3 - 2 * w); _sp.lerpVectors(this._rideFrom, _sp, e).y += Math.sin(Math.PI * w) * 0.5; }
  this.group.position.copy(_sp); this.group.quaternion.copy(_sq); this.pos.copy(_sp); this.yaw = h.yaw; this.speed = 0; this.air = 0;
  if (this.blob) this.blob.visible = false;
  // upper body: tall at a walk, folded forward at a gallop, hands low and forward on the reins
  const bob = Math.sin(ph * 2) * (0.02 * walkW + 0.03 * trotW + 0.02 * galW);
  // (+z tips a human torso back, so forward lean is negative)
  const lean = 0.05 + 0.1 * trotW + 0.42 * galW;
  B.root.position.set(0, this.rootY, 0); B.root.rotation.set(0, 0, -lean * 0.35);
  B.spine.rotation.set(0, 0, -lean * 0.4 - bob);
  B.chest.rotation.set(0, 0, -lean * 0.25 + bob * 0.5);
  B.neck && B.neck.rotation.set(0, 0, lean * 0.35);
  B.head.rotation.set(0, (this.lookYaw || 0) * 0.3, lean * 0.5 - bob * 0.4);
  for (const s of ['L', 'R']) { const sg = s === 'L' ? 1 : -1;
    B['clav' + s].rotation.set(0, 0, 0);
    B['arm' + s].rotation.set(0.22 * sg, 0, 0.5 + 0.35 * galW);
    B['fore' + s].rotation.set(0, 0, 1.15 - 0.25 * galW + 0.05 * Math.sin(ph * 2));
    if (B['hand' + s]) B['hand' + s].rotation.set(0, 0, -0.2); }
  this.group.updateMatrixWorld(true);
  // legs: two-bone IK so each foot rests in its stirrup, knee pointing forward and out
  for (const s of ['L', 'R']) { const sg = s === 'L' ? 1 : -1, th = B['thigh' + s], sh = B['shin' + s], ft = B['foot' + s];
    (s === 'L' ? T.stirL : T.stirR).getWorldPosition(_t); B.root.worldToLocal(_t);
    const Hh = th.position, L1 = 0.43, L2 = 0.435;
    _u.subVectors(_t, Hh); const dist = clamp(_u.length(), 0.2, L1 + L2 - 0.006); _u.normalize(); _t.copy(Hh).addScaledVector(_u, dist);
    _pole.set(1, 0.15, 0.55 * sg).normalize(); _pole.addScaledVector(_u, -_pole.dot(_u)).normalize();
    const cA = clamp((L1 * L1 + dist * dist - L2 * L2) / (2 * L1 * dist), -1, 1), sA = Math.sqrt(1 - cA * cA);
    _k.copy(Hh).addScaledVector(_u, cA * L1).addScaledVector(_pole, sA * L1);
    const ud = _w.subVectors(_k, Hh).normalize(), td = _so.subVectors(_t, _k).normalize();
    _by.copy(ud).negate(); _bz.crossVectors(ud, td); if (_bz.lengthSq() < 1e-6) _bz.set(0, 0, 1); _bz.normalize(); _bx.crossVectors(_by, _bz); if (_bx.x < 0) { _bz.negate(); _bx.crossVectors(_by, _bz); }
    _bm.makeBasis(_bx, _by, _bz); th.quaternion.setFromRotationMatrix(_bm);
    _q1.copy(th.quaternion).invert(); _w.copy(td).applyQuaternion(_q1); sh.rotation.set(0, 0, Math.atan2(_w.x, -_w.y));
    _q2.copy(th.quaternion).multiply(sh.quaternion).invert(); ft.quaternion.copy(_q2); ft.rotation.z += 0.12; ft.rotation.y += 0.25 * sg;
  }
  if (this.onAnim) this.onAnim(dt, time);
  this.rig.updateMatrixWorld(true);
  // reins: hands to the bit, with a little sag
  if (!T.reins) { const gm = new THREE.BufferGeometry(); gm.setAttribute('position', new THREE.BufferAttribute(new Float32Array(2 * 8 * 3), 3)); const idx = []; for (let i = 0; i < 7; i++) idx.push(i, i + 1, 8 + i, 9 + i); gm.setIndex(idx); T.reins = new THREE.LineSegments(gm, reinMat); T.reins.frustumCulled = false; this.scene.add(T.reins); }
  const P = T.reins.geometry.attributes.position;
  for (const [k, s] of [[0, 'L'], [8, 'R']]) { B['hand' + s].getWorldPosition(_t); (s === 'L' ? T.bitL : T.bitR).getWorldPosition(_k);
    for (let i = 0; i < 8; i++) { const u = i / 7; _w.lerpVectors(_t, _k, u); _w.y -= Math.sin(Math.PI * u) * 0.09; P.setXYZ(k + i, _w.x, _w.y, _w.z); } }
  P.needsUpdate = true; T.reins.visible = true;
};
Creature.prototype.unseat = function (h) { if (h?.tack?.reins) h.tack.reins.visible = false; this._rg = null; this._rideFrom = null; this.group.quaternion.identity(); for (const b of this.bones) b.quaternion.identity(); this.b.root.position.y = this.rootY; if (this._feet) this._feet.L.lock = this._feet.R.lock = null; };

// horse mane + tail: long strands as a few shell layers over the mane/tail triangles only; strands run down (y), fine across (x, z)
const maneMats = {};
function maneShellMat(i, N, len) {
  const key = i + '|' + N; if (maneMats[key]) return maneMats[key];
  const f = (i + 1) / N, m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55, metalness: 0, side: THREE.DoubleSide });
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, { uK: { value: f }, uLen: { value: len }, uSunV: CENV.sunV, uSunCol: CENV.sunCol, uDay: CENV.day, uWet: CENV.wet });
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nattribute float aMane; uniform float uK, uLen; varying vec3 vRestS; varying float vM;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n vRestS = position; vM = aMane; transformed += objectNormal * uLen * uK * aMane; transformed.y -= uLen * uK * uK * 1.4 * aMane;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform float uK, uDay, uWet; uniform vec3 uSunV, uSunCol; varying vec3 vRestS; varying float vM;\nfloat mh(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }')
      .replace('#include <color_fragment>', `#include <color_fragment>
        { if (vM < 0.5) discard;
          vec2 q = vec2(vRestS.x * 260.0 + vRestS.z * 190.0, vRestS.z * 260.0 - vRestS.x * 120.0); vec2 cell = floor(q); float h = mh(cell), wob = sin(vRestS.y * 34.0 + h * 6.28) * 0.18;
          if (h < uK * 0.75 || abs(fract(q.x + wob) - 0.5) > 0.42 * (1.0 - uK * 0.6)) discard;
          diffuseColor.rgb *= mix(0.6, 1.2, uK) * (0.82 + 0.36 * mh(cell + 5.3)) * (1.0 - 0.3 * uWet); }`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        { vec3 vv = normalize(vViewPosition); float back = pow(max(dot(-vv, uSunV), 0.0), 2.0); float rim = pow(1.0 - abs(dot(normal, vv)), 2.0);
          totalEmissiveRadiance += uSunCol * (0.06 + 0.9 * back) * rim * uK * uDay * (0.25 + diffuseColor.rgb * 3.0) * 0.5; }`);
  };
  m.userData.env = 0.3; return maneMats[key] = m;
}
Creature.prototype.addManeShells = function (D) {
  const base = this.meshes[0], g0 = base.geometry, n = g0.attributes.position.count, raw = decodeSpecies(this.spec.mesh).lods[0];
  const w = new Float32Array(n); let any = false;
  for (let i = 0; i < n; i++) { const a = D.slots[raw.SL[i * 3]], b = D.slots[raw.SL[i * 3 + 1]], mix = raw.SL[i * 3 + 2] / 255, v = (a === 'mane' ? 1 - mix : 0) + (b === 'mane' ? mix : 0); if (v > 0.35) { w[i] = 1; any = true; } }
  if (!any) return;
  const I = g0.index.array, keep = []; for (let t = 0; t < I.length; t += 3) if (w[I[t]] + w[I[t + 1]] + w[I[t + 2]] > 0) keep.push(I[t], I[t + 1], I[t + 2]);
  const g = new THREE.BufferGeometry(); for (const [k, v] of Object.entries(g0.attributes)) g.setAttribute(k, v); g.setAttribute('aMane', new THREE.BufferAttribute(w, 1));
  g.setIndex(new THREE.BufferAttribute(n > 65535 ? new Uint32Array(keep) : new Uint16Array(keep), 1));
  const N = matchMedia('(pointer: coarse)').matches ? 3 : 6, len = 0.03 * this.S / 1.55;
  this.maneShells = [];
  for (let i = 0; i < N; i++) { const sm = new THREE.SkinnedMesh(g, maneShellMat(i, N, len)); sm.boundingSphere = base.boundingSphere; sm.frustumCulled = true; sm.castShadow = false; this.rig.add(sm); sm.bind(this.skel, base.bindMatrix); this.maneShells.push(sm); }
};
