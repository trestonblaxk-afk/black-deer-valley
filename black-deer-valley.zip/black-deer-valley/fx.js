// Particle puffs: dust, hit sparks, wood chips, splashes, rain/snow handled separately
import * as THREE from 'three';
import { rnd, TAU, GLSL_TERRAIN, POND } from './world.js';

export function createFX(scene, N = 600) {
  const g = new THREE.BufferGeometry();
  const pos = new Float32Array(N * 3), col = new Float32Array(N * 3), size = new Float32Array(N), alpha = new Float32Array(N);
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
  g.setAttribute('aSize', new THREE.BufferAttribute(size, 1)); g.setAttribute('aAlpha', new THREE.BufferAttribute(alpha, 1));
  const m = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, uniforms: { uScale: { value: 600 } },
    vertexShader: `attribute vec3 aColor; attribute float aSize, aAlpha; uniform float uScale; varying vec3 vC; varying float vA;
      void main(){ vC = aColor; vA = aAlpha; vec4 mv = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = aSize * uScale / max(-mv.z, 0.1); }`,
    fragmentShader: `varying vec3 vC; varying float vA; void main(){ vec2 d = gl_PointCoord - 0.5; float r = length(d); if (r > 0.5) discard; gl_FragColor = vec4(vC, vA * smoothstep(0.5, 0.1, r)); }`,
  });
  const pts = new THREE.Points(g, m); pts.frustumCulled = false; pts.renderOrder = 5; pts.layers.set(1); scene.add(pts);
  const P = []; for (let i = 0; i < N; i++) P.push({ life: 0, max: 1, v: new THREE.Vector3(), p: new THREE.Vector3(), c: new THREE.Color(), s0: 0.1, s1: 0.3, a: 1, g: 0 });
  let head = 0;
  const PRESET = {
    dust: { c: 0xb59d7a, n: 10, sp: 1.4, up: 0.8, life: 0.9, s0: 0.15, s1: 0.7, a: 0.45, g: -0.4 },
    hit: { c: 0xfff2c8, n: 9, sp: 4.5, up: 1.5, life: 0.28, s0: 0.08, s1: 0.02, a: 1, g: 6 },
    chips: { c: 0xc9a06a, n: 10, sp: 3.2, up: 3, life: 0.8, s0: 0.06, s1: 0.04, a: 1, g: 9 },
    leaves: { c: 0x7da24e, n: 12, sp: 1.5, up: 1, life: 1.6, s0: 0.1, s1: 0.08, a: 1, g: 1.2 },
    splash: { c: 0xd8e6f0, n: 14, sp: 2.4, up: 3.5, life: 0.6, s0: 0.07, s1: 0.03, a: 0.9, g: 9 },
    stone: { c: 0x8a8578, n: 8, sp: 3, up: 2.5, life: 0.6, s0: 0.06, s1: 0.04, a: 1, g: 9 },
    scan: { c: 0x9be8ff, n: 18, sp: 0.6, up: 1.2, life: 1.0, s0: 0.05, s1: 0.0, a: 1, g: -0.5 },
    berry: { c: 0x7a2a6a, n: 8, sp: 1.5, up: 2, life: 0.5, s0: 0.05, s1: 0.03, a: 1, g: 8 },
    smoke: { c: 0x8a8a8a, n: 1, sp: 0.2, up: 1.1, life: 3, s0: 0.3, s1: 1.4, a: 0.35, g: -0.2 },
    ember: { c: 0xffa040, n: 1, sp: 0.4, up: 1.6, life: 1.2, s0: 0.05, s1: 0.0, a: 1, g: -0.6 },
  };
  function burst(type, at, opts = {}) {
    const pr = PRESET[type], n = opts.n ?? pr.n;
    for (let i = 0; i < n; i++) {
      const q = P[head]; head = (head + 1) % N;
      const a = rnd() * TAU, s = pr.sp * (0.4 + rnd() * 0.8) * (opts.k || 1);
      q.p.copy(at); q.v.set(Math.cos(a) * s, pr.up * (0.5 + rnd() * 0.8), Math.sin(a) * s);
      if (opts.dir) q.v.addScaledVector(opts.dir, s * 0.8);
      q.c.set(opts.color ?? pr.c).multiplyScalar(0.85 + rnd() * 0.3); q.life = q.max = pr.life * (0.7 + rnd() * 0.6); q.s0 = pr.s0 * (opts.k || 1); q.s1 = pr.s1 * (opts.k || 1); q.a = pr.a; q.g = pr.g;
    }
  }
  function update(dt) {
    for (let i = 0; i < N; i++) {
      const q = P[i];
      if (q.life <= 0) { alpha[i] = 0; continue; }
      q.life -= dt; q.v.y -= q.g * dt; q.v.multiplyScalar(Math.exp(-1.8 * dt)); q.p.addScaledVector(q.v, dt);
      const u = 1 - q.life / q.max;
      pos[i * 3] = q.p.x; pos[i * 3 + 1] = q.p.y; pos[i * 3 + 2] = q.p.z;
      col[i * 3] = q.c.r; col[i * 3 + 1] = q.c.g; col[i * 3 + 2] = q.c.b;
      size[i] = q.s0 + (q.s1 - q.s0) * u; alpha[i] = q.a * (1 - u) * Math.min(1, u * 8);
    }
    for (const k of ['position', 'aColor', 'aSize', 'aAlpha']) g.attributes[k].needsUpdate = true;
  }
  function setScale(h) { m.uniforms.uScale.value = h; }
  return { burst, update, setScale };
}

// Rain + snow: camera-following field of lit streak quads (rain) or soft flakes (snow), plus ground splash rings
export function createWeather(scene, N = 4000) {
  const quad = new Float32Array([-1, 0, 1, 0, 1, 1, -1, 1]);
  const g = new THREE.InstancedBufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 3));
  g.setAttribute('aCorner', new THREE.Float32BufferAttribute(quad, 2)); g.setIndex([0, 1, 2, 0, 2, 3]);
  const drop = new Float32Array(N * 4);
  for (let i = 0; i < N; i++) drop.set([(rnd() - 0.5) * 40, rnd() * 24, (rnd() - 0.5) * 40, rnd()], i * 4);
  g.setAttribute('aDrop', new THREE.InstancedBufferAttribute(drop, 4)); g.instanceCount = N; g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
  const U = { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uSnow: { value: 0 }, uAmt: { value: 0 }, uWind: { value: 0.5 }, uLight: { value: new THREE.Color(0.7, 0.74, 0.8) }, uFlash: { value: 0 } };
  const m = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, uniforms: U,
    vertexShader: `attribute vec2 aCorner; attribute vec4 aDrop; uniform float uTime, uSnow, uAmt, uWind; uniform vec3 uCam; varying float vA; varying vec2 vC; varying float vD;
      void main(){ float speed = mix(18.0, 1.5, uSnow); vec3 p = aDrop.xyz;
        p.y = mod(p.y - uTime * speed * (0.85 + aDrop.w * 0.3), 24.0);
        p.x += uWind * (24.0 - p.y) * mix(0.3, 0.6, uSnow) + uSnow * sin(uTime * 1.3 + aDrop.w * 30.0) * 0.6;
        p.z += uSnow * cos(uTime * 1.1 + aDrop.w * 21.0) * 0.4;
        p.xz = mod(p.xz - uCam.xz + 20.0, 40.0) - 20.0 + uCam.xz; p.y += uCam.y - 8.0;
        vA = step(aDrop.w, uAmt); vC = aCorner;
        vec3 vel = normalize(vec3(uWind * mix(5.0, 1.0, uSnow), -speed, 0.0));
        vec4 a = viewMatrix * vec4(p, 1.0);
        vec4 mv;
        if (uSnow > 0.5) { mv = a; mv.xy += (aCorner * vec2(1.0, 2.0) - vec2(0.0, 1.0)) * 0.022 * (0.7 + aDrop.w * 0.6); }
        else { float len = 0.55 + aDrop.w * 0.35; vec4 b = viewMatrix * vec4(p - vel * len, 1.0);
          vec2 dir = b.xy - a.xy; float dl = length(dir); dir = dl > 1e-5 ? dir / dl : vec2(0.0, 1.0);
          mv = mix(a, b, aCorner.y); mv.xy += vec2(-dir.y, dir.x) * aCorner.x * 0.011 * (1.0 + max(-a.z, 0.0) * 0.08); }
        vD = -mv.z;
        gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform float uSnow, uFlash; uniform vec3 uLight; varying float vA; varying vec2 vC; varying float vD;
      void main(){ if (vA < 0.5) discard;
        float a; vec3 col;
        if (uSnow > 0.5) { vec2 d = vec2(vC.x, vC.y * 2.0 - 1.0); a = smoothstep(1.0, 0.2, length(d)) * 0.85; col = vec3(0.95) * (0.55 + 0.45 * uLight.g); }
        else { a = (1.0 - abs(vC.x)) * smoothstep(0.0, 0.25, vC.y) * smoothstep(1.0, 0.55, vC.y) * 0.42; col = uLight * 1.4 + vec3(0.8, 0.85, 1.0) * uFlash; }
        a *= smoothstep(0.35, 1.2, vD) * smoothstep(26.0, 14.0, vD);
        gl_FragColor = vec4(col, a); }`,
  });
  const pts = new THREE.Mesh(g, m); pts.frustumCulled = false; pts.layers.set(1); scene.add(pts);
  // splash rings on the ground near the camera (rain only)
  const SN = Math.round(N / 10), sg = new THREE.InstancedBufferGeometry();
  sg.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 3));
  sg.setAttribute('aCorner', new THREE.Float32BufferAttribute(quad.map((v, i) => i % 2 ? v * 2 - 1 : v), 2)); sg.setIndex([0, 1, 2, 0, 2, 3]);
  const sd = new Float32Array(SN * 3); for (let i = 0; i < SN; i++) sd.set([(rnd() - 0.5) * 24, (rnd() - 0.5) * 24, rnd()], i * 3);
  sg.setAttribute('aS', new THREE.InstancedBufferAttribute(sd, 3)); sg.instanceCount = SN; sg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
  const sm = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, uniforms: U,
    vertexShader: `attribute vec2 aCorner; attribute vec3 aS; uniform float uTime, uAmt, uSnow; uniform vec3 uCam; varying vec2 vC; varying float vPh; varying float vOn;` + GLSL_TERRAIN + `
      void main(){ float ph = fract(uTime * 1.7 + aS.z * 13.0); float cyc = floor(uTime * 1.7 + aS.z * 13.0);
        vec2 jit = vec2(fract(sin(cyc * 12.9 + aS.z * 78.2) * 43758.5), fract(sin(cyc * 39.3 + aS.z * 11.1) * 24634.6)) * 3.0;
        vec2 q = mod(aS.xy + jit - uCam.xz + 12.0, 24.0) - 12.0 + uCam.xz;
        vOn = step(aS.z, uAmt) * (1.0 - uSnow) * step(${(POND.r + 1.0).toFixed(1)}, pondD(q));
        vC = aCorner; vPh = ph;
        vec3 wp = vec3(q.x + aCorner.x * 0.09, terrainH(q) + 0.03, q.y + aCorner.y * 0.09);
        gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0); }`,
    fragmentShader: `uniform vec3 uLight; varying vec2 vC; varying float vPh; varying float vOn;
      void main(){ if (vOn < 0.5) discard; float r = length(vC); float ring = smoothstep(0.12, 0.0, abs(r - vPh)) * (1.0 - vPh);
        gl_FragColor = vec4(uLight * 1.3, ring * 0.45); }` });
  const splash = new THREE.Mesh(sg, sm); splash.frustumCulled = false; splash.layers.set(1); scene.add(splash);
  return { U, pts, splash };
}
