// Live services: co-op presence (room), shared builds + feedback + stats (db), identity (user).
// Every piece degrades to single-player when the viewer can't connect.
export const VERSION = '0.6.3';
export const WHATS_NEW = [
  'New look for the hiker: charcoal hiking shirt, olive vest, tan hiking pants, black boots, daypack with a water bottle, locs up in a top knot',
  'Golden meadow: more sun-cured grass across the valley',
  'Music now plays through the whole game, blended over the wind, birds, insects, water and rain',
  'Red Dead pass: warm golden-hour light, dusty horizon, deeper contact shadows and a filmic grade',
  'Animals: countershaded coats, muscle shading, skin pores and four coat tones each for deer, elk and wolves',
  'A rebuilt horse with a slimmer mane, plus folded cloth on the hiker',
  'Sun-cured golden patches in the meadow, shadowed trail edges, weathered rock',
  'v0.6.0 Frontier: tame a wild horse. Walk up slowly and hold Calm; run or fight and the herd bolts',
  'Ride it: walk, trot and gallop (Shift or a full stick push). Your horse has its own stamina. Whistle from afar to call it',
  'Five Frontier quests with a tracker, map marker and waypoint, ending at the signal fire on the ridge camp',
  'Thirst: a new blue ring around the map. Drink at the pond',
  'XP and levels: every level brings a perk (more health, cheaper sprinting, more carry space)',
  'A short opening story on first start, replayable from the Kit. Knocked out? You now wake where you fell',
  'Graphics: clearer blue skies, softer shadows, richer greens, a sleek horse coat with a real mane and tail, edge light so riders read',
];

export async function createLive() {
  const live = { db: null, room: null, user: null, uid: null, canWrite: false, online: 0, ready: false };
  const use = n => (window.claude?.use ? window.claude.use(n).catch(() => null) : Promise.resolve(null));
  const [db, room, user] = await Promise.all([use('db'), use('room'), use('user')]);
  live.db = db; live.room = room; live.user = user;
  if (user) { try { live.uid = await user.id(); const w = await user.can('data.write'); live.canWrite = w !== false; } catch (e) {} }
  live.ready = true;

  // ---------- presence ----------
  let lastSent = 0, lastPatch = '';
  live.sendPresence = (state, now) => {
    if (!room || now - lastSent < 90) return;
    const s = JSON.stringify(state); if (s === lastPatch) return;
    lastSent = now; lastPatch = s;
    room.presence({ p: state, uid: live.uid }).catch(() => {});
  };
  live.onPeers = fn => room ? room.onPeers(ch => { live.online = ch.peers.filter(p => !p.isMe && p.kind === 'viewer').length; fn(ch); }, () => {}) : () => {};
  live.emit = (topic, data) => room ? room.emit(topic, data).catch(() => {}) : Promise.resolve();
  live.on = (topic, fn) => room ? room.on(topic, m => { if (!m.isMe) fn(m); }, () => {}) : () => {};
  live.names = async ids => { if (!user || !ids.length) return {}; try { return await user.profiles(ids); } catch (e) { return {}; } };
  live.myName = async () => { if (!user) return ''; try { return (await user.me()).name || ''; } catch (e) { return ''; } };

  // ---------- shared builds ----------
  live.watchBuilds = (onAdd, onRemove) => {
    if (!db) return false;
    try {
      db.collection('builds').limit(400).onSnapshot(snap => {
        for (const ch of snap.docChanges()) { const d = ch.doc.data(); if (!d) continue; if (ch.type === 'added') onAdd(ch.doc.id, d); if (ch.type === 'removed') onRemove(ch.doc.id); }
      }, () => {});
      return true;
    } catch (e) { return false; }
  };
  live.addBuild = async b => { if (!db || !live.canWrite) return null; try { const r = await db.collection('builds').add({ ...b, by: live.uid, ts: Date.now(), v: VERSION }); return r.id; } catch (e) { live.canWrite = false; return null; } };

  // ---------- feedback ----------
  live.sendFeedback = async report => {
    if (!db || !live.uid) return { ok: false, why: 'offline' };
    try { await db.doc('feedback/' + live.uid).collection('reports').add({ ...report, ts: Date.now(), v: VERSION }); return { ok: true }; }
    catch (e) { return { ok: false, why: e?.code || 'error' }; }
  };

  // ---------- stats (one doc per player, flushed about once a minute) ----------
  let stats = null, statsRef = null, dirty = false, writing = false;
  if (db && live.uid) {
    try {
      statsRef = db.doc('stats/' + live.uid);
      const snap = await statsRef.get();
      const prev = snap.exists ? snap.data() : {};
      stats = { firstSeen: prev.firstSeen || Date.now(), sessions: (prev.sessions || 0) + 1, minutes: prev.minutes || 0, species: { ...(prev.species || {}) }, scans: prev.scans || 0, builds: prev.builds || 0, kos: prev.kos || 0, knockedOut: prev.knockedOut || 0, crafted: prev.crafted || 0, feedback: prev.feedback || 0, fpsAvg: prev.fpsAvg || 0 };
      dirty = true;
    } catch (e) { stats = null; }
  }
  live.stat = (key, n = 1) => { if (!stats) return; stats[key] = (stats[key] || 0) + n; dirty = true; };
  live.statMinutes = (species, min, fps, quality, device) => { if (!stats) return; stats.minutes += min; stats.species[species] = +((stats.species[species] || 0) + min).toFixed(2); if (fps) stats.fpsAvg = Math.round(stats.fpsAvg ? stats.fpsAvg * 0.8 + fps * 0.2 : fps); stats.quality = quality; stats.device = device; dirty = true; };
  // performance + error log per version (borrowed from the godot-mcp idea): what a real device actually ran at, checked after each update
  live.statPerf = p => { if (!stats) return; const all = stats.perf = stats.perf || {}, k = VERSION.replace(/\./g, '_'), o = all[k] || {};
    const ema = (a, b) => a == null ? b : Math.round((a * 0.7 + b * 0.3) * 10) / 10;
    all[k] = { fps: ema(o.fps, p.fps), p95ms: ema(o.p95ms, p.p95ms), stutterPerMin: ema(o.stutterPerMin, p.stutterPerMin), tune: p.tune, cap: p.cap, res: p.res, dpr: p.dpr, gpu: p.gpu, quality: p.quality, device: p.device, minutes: +(((o.minutes || 0) + p.minutes)).toFixed(2) };
    dirty = true; };
  live.statError = msg => { if (!stats) return; const e = stats.errors = (stats.errors || []).slice(-4); e.push({ v: VERSION, at: Date.now(), msg: String(msg).slice(0, 180) }); dirty = true; };
  live.flushStats = async () => {
    if (!stats || !statsRef || !dirty || writing) return; writing = true; dirty = false;
    try { await statsRef.set({ ...stats, minutes: +stats.minutes.toFixed(2), lastSeen: Date.now(), lastVersion: VERSION }); } catch (e) { dirty = true; }
    writing = false;
  };
  return live;
}
